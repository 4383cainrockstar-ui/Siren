package app.siren.ui.screens

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import app.siren.ui.components.SirenLoader
import android.content.ActivityNotFoundException
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ThumbUpOffAlt
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material.icons.rounded.ThumbDownOffAlt
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.outlined.ArrowCircleDown
import androidx.compose.material.icons.rounded.ArrowCircleDown
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ClearAll
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Radio
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.zIndex
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import app.siren.core.Fmt
import app.siren.core.LyricLine
import app.siren.core.Lyrics as LyricsData
import app.siren.core.LyricsApi
import app.siren.core.Track
import app.siren.data.DownloadRecord
import app.siren.data.Library
import app.siren.data.Settings
import app.siren.player.PlayerController
import app.siren.ui.LocalActions
import app.siren.ui.Routes
import app.siren.ui.components.AddToPlaylistDialog
import app.siren.ui.components.Artwork
import app.siren.ui.components.fastScroll
import app.siren.ui.components.HoldNextButton
import app.siren.ui.UiState
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.VisibilityOff
import app.siren.ui.components.DeleteRow
import app.siren.ui.components.NameDialog
import app.siren.ui.components.PlayingBars
import app.siren.ui.components.LikeButton
import app.siren.ui.components.RippleIconButton
import app.siren.ui.components.rememberCompletionRipple
import app.siren.ui.components.rememberRippleState
import app.siren.ui.components.Wave
import app.siren.ui.components.waveSource
import app.siren.ui.components.SheetRow
import app.siren.ui.components.TrackActionsSheet
import app.siren.player.QueueItem
import app.siren.ui.components.rememberArtColor
import app.siren.ui.theme.Sc
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import kotlin.math.abs

@UnstableApi
@Composable
fun NowPlaying(onClose: () -> Unit) {
    val current by PlayerController.current.collectAsState()
    val t = current
    if (t != null) NowPlayingContent(t, onClose)
}

@UnstableApi
@Composable
private fun NowPlayingContent(track: Track, onClose: () -> Unit) {
    val actions = LocalActions.current
    val ctx = LocalContext.current
    val lib by Library.data.collectAsState()
    val playing by PlayerController.isPlaying.collectAsState()
    val buffering by PlayerController.buffering.collectAsState()
    val shuffle by PlayerController.shuffle.collectAsState()
    val smart by PlayerController.smart.collectAsState()
    val queue by PlayerController.queue.collectAsState()
    val repeat by PlayerController.repeat.collectAsState()
    val source by PlayerController.source.collectAsState()
    val sleepAt by PlayerController.sleepAt.collectAsState()
    val speed by PlayerController.speed.collectAsState()
    val station by PlayerController.station.collectAsState()
    val settings by Settings.state.collectAsState()
    val tint = rememberArtColor(track.thumbnail, Color(0xFF2A2A2A))

    var showLyrics by remember { mutableStateOf(Settings.current.showLyricsByDefault) }
    var sheet by remember { mutableStateOf<String?>(null) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var seeking by remember { mutableStateOf<Float?>(null) }

    // Skipping pushes the cover a little in the skip direction, then it settles back
    val scope = rememberCoroutineScope()
    val nudge = remember { Animatable(0f) }
    fun push(dir: Float) {
        if (!Settings.current.rippleEffects) return
        scope.launch {
            nudge.snapTo(0f)
            nudge.animateTo(dir * 26f, tween(90))
            nudge.animateTo(0f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMediumLow))
        }
    }
    val playRipple = rememberRippleState(560)
    val queueRipple = rememberRippleState(520)
    LaunchedEffect(Unit) { PlayerController.added.collect { queueRipple.fire() } }

    val liked = lib.liked.any { it.videoId == track.videoId }
    val download = lib.downloads.firstOrNull { it.track.videoId == track.videoId }
    val smartItem = queue.firstOrNull { it.smart && it.track.videoId == track.videoId }
    val smartPick = smartItem != null

    LaunchedEffect(track.videoId) {
        while (true) {
            val p = PlayerController.player
            pos = p.currentPosition.coerceAtLeast(0)
            val d = p.duration
            dur = if (d != C.TIME_UNSET && d > 0) d else (track.duration * 1000).coerceAtLeast(0)
            delay(200)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Sc.Bg)
            .background(
                Brush.verticalGradient(
                    0f to tint.copy(alpha = 1f).compositeOver(Color(0xFF101010)),
                    0.55f to tint.copy(alpha = 0.55f).compositeOver(Color(0xFF0A0A0A)),
                    1f to Color(0xFF060606)
                )
            )
            .clickable(enabled = false) {}
            .pointerInput(Unit) {
                // Pull down to close, like a sheet
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total > 220) onClose() },
                    onVerticalDrag = { _, d -> total += d }
                )
            }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 22.dp)
        ) {
            // Top bar
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Close", tint = Sc.Text, modifier = Modifier.size(32.dp)) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("PLAYING FROM", color = Sc.Text.copy(alpha = 0.75f), fontSize = 10.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
                    Text(source.ifBlank { "Siren" }, color = Sc.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { sheet = "more" }) { Icon(Icons.Rounded.MoreVert, "More", tint = Sc.Text) }
            }

            // Artwork or lyrics
            BoxWithConstraints(
                Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                val side = minOf(maxWidth, maxHeight - 8.dp)
                AnimatedContent(targetState = showLyrics, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "art") { lyrics ->
                    if (lyrics) {
                        LyricsView(track, pos, Modifier.fillMaxSize()) { PlayerController.seekTo(it) }
                    } else {
                        val scale by animateFloatAsState(if (playing) 1f else 0.94f, label = "scale")
                        var drag by remember { mutableFloatStateOf(0f) }
                        Box(
                            Modifier
                                .size(side)
                                .scale(scale)
                                .graphicsLayer { translationX = nudge.value }
                                .pointerInput(track.videoId) {
                                    detectHorizontalDragGestures(
                                        onDragStart = { drag = 0f },
                                        onDragEnd = {
                                            if (drag < -140) PlayerController.next()
                                            else if (drag > 140) PlayerController.previous()
                                            drag = 0f
                                        },
                                        onHorizontalDrag = { _, d -> drag += d }
                                    )
                                }
                                .shadow(30.dp, RoundedCornerShape(8.dp), ambientColor = Color.Black, spotColor = Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            Artwork(track.thumbnail, Modifier.fillMaxSize(), corner = 8.dp, big = true)
                        }
                    }
                }
            }

            Spacer(Modifier.height(22.dp))

            // Title, artist, like
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    if (smartPick) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 4.dp)) {
                            Icon(Icons.Rounded.AutoAwesome, null, tint = Sc.Accent, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(
                                smartItem?.why?.takeIf { it.isNotBlank() }?.let { "Because you played $it" } ?: "Smart shuffle pick",
                                color = Sc.Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Text(
                        track.title, color = Sc.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                        modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE)
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        track.artist.ifBlank { "Unknown artist" },
                        color = Sc.Text.copy(alpha = 0.7f), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.clickable(enabled = track.artistUrl.isNotBlank()) {
                            onClose()
                            actions.artist(track.artistUrl)
                        }
                    )
                }
                station?.let { st ->
                    // Station thumbs, Pandora style
                    val up = st.liked.any { it.videoId == track.videoId }
                    IconButton(onClick = { PlayerController.thumbDown() }) {
                        Icon(Icons.Rounded.ThumbDownOffAlt, "Thumbs down: skip, and play less like this", tint = Sc.Text.copy(alpha = 0.8f), modifier = Modifier.size(24.dp))
                    }
                    IconButton(onClick = { PlayerController.thumbUp() }) {
                        Icon(
                            if (up) Icons.Rounded.ThumbUp else Icons.Rounded.ThumbUpOffAlt,
                            if (up) "Thumbs up (tap to undo)" else "Thumbs up: more like this",
                            tint = if (up) Sc.Accent else Sc.Text.copy(alpha = 0.8f),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                LikeButton(liked, 30.dp, Sc.Text) { Library.toggleLike(track) }
            }

            Spacer(Modifier.height(14.dp))

            // Seek bar
            val fraction = if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
            SeekBar(
                value = seeking ?: fraction,
                dragging = seeking != null,
                onChange = { seeking = it },
                onDone = {
                    PlayerController.seekTo((it * dur).toLong())
                    seeking = null
                }
            )
            Row(Modifier.fillMaxWidth()) {
                val shownPos = seeking?.let { (it * dur).toLong() } ?: pos
                Text(Fmt.ms(shownPos), color = Sc.Text.copy(alpha = 0.7f), fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text(if (dur > 0) "-" + Fmt.ms((dur - shownPos).coerceAtLeast(0)) else "--:--", color = Sc.Text.copy(alpha = 0.7f), fontSize = 11.sp)
            }

            Spacer(Modifier.height(10.dp))

            // Transport
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ShuffleButton(shuffle, smart) { PlayerController.cycleShuffle() }
                RippleIconButton(
                    onClick = {
                        push(1f)
                        PlayerController.previous()
                    },
                    from = 28.dp, to = 50.dp, strength = 0.75f, durationMs = 460,
                    modifier = Modifier.size(60.dp),
                    buttonModifier = Modifier.size(60.dp)
                ) {
                    Icon(Icons.Rounded.SkipPrevious, "Previous", tint = Sc.Text, modifier = Modifier.size(44.dp))
                }
                // Rings sit on a wrapper so the round clip doesn't cut them off. Play spreads wide,
                // pause is a tighter ring.
                Box(Modifier.size(68.dp).waveSource(playRipple), contentAlignment = Alignment.Center) {
                    Box(
                        Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .clickable {
                                playRipple.fire(if (playing) 0.55f else 1f)
                                PlayerController.togglePlay()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (buffering && !playing) {
                            SirenLoader(size = 40.dp, color = Color.Black)
                        } else {
                            Icon(
                                if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                if (playing) "Pause" else "Play",
                                tint = Color.Black,
                                modifier = Modifier.size(40.dp)
                            )
                        }
                    }
                }
                HoldNextButton(
                    size = 60.dp,
                    iconSize = 44.dp,
                    onNext = {
                        push(-1f)
                        PlayerController.next()
                    },
                    onHold = if (settings.holdToHide) ({ actions.hideArtist(track) }) else null
                )
                ToggleIcon(
                    if (repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    when (repeat) {
                        Player.REPEAT_MODE_ONE -> "Repeat this song"
                        Player.REPEAT_MODE_ALL -> "Repeat all"
                        else -> "Repeat off"
                    },
                    repeat != Player.REPEAT_MODE_OFF
                ) { PlayerController.cycleRepeat() }
            }

            Spacer(Modifier.height(10.dp))

            // Bottom actions
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ToggleIcon(Icons.Rounded.Lyrics, if (showLyrics) "Hide lyrics" else "Lyrics", showLyrics, dot = false) { showLyrics = !showLyrics }
                val dl = download?.status
                // A ring closes in around the icon when the download finishes
                val dlDone = rememberCompletionRipple(
                    track.videoId,
                    running = dl == DownloadRecord.STATUS_RUNNING || dl == DownloadRecord.STATUS_QUEUED,
                    done = dl == DownloadRecord.STATUS_DONE
                )
                Box(Modifier.waveSource(dlDone), contentAlignment = Alignment.Center) {
                    IconButton(onClick = {
                        when (dl) {
                            null, DownloadRecord.STATUS_FAILED -> actions.download(listOf(track))
                            DownloadRecord.STATUS_DONE -> actions.message("Downloaded. Plays offline.")
                            else -> actions.message("Downloading " + ((download?.progress ?: 0f) * 100).toInt() + "%")
                        }
                    }) {
                        when (dl) {
                            DownloadRecord.STATUS_DONE -> Icon(Icons.Rounded.ArrowCircleDown, "Downloaded", tint = Sc.Accent, modifier = Modifier.size(26.dp))
                            DownloadRecord.STATUS_RUNNING, DownloadRecord.STATUS_QUEUED -> CircularProgressIndicator(
                                progress = { (download?.progress ?: 0f).coerceIn(0.02f, 1f) },
                                color = Sc.Accent, trackColor = Color.White.copy(alpha = 0.2f), strokeWidth = 2.dp,
                                modifier = Modifier.size(22.dp)
                            )
                            else -> Icon(Icons.Outlined.ArrowCircleDown, "Download", tint = Sc.Text, modifier = Modifier.size(26.dp))
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                if (sleepAt != null) {
                    Text(sleepLabel(sleepAt), color = Sc.Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                ToggleIcon(Icons.Rounded.Bedtime, "Sleep timer", sleepAt != null, dot = false) { sheet = "sleep" }
                // Pulses when songs land in the queue
                Box(Modifier.waveSource(queueRipple), contentAlignment = Alignment.Center) {
                    IconButton(onClick = { sheet = "queue" }) {
                        Icon(Icons.AutoMirrored.Rounded.QueueMusic, "Queue", tint = Sc.Text, modifier = Modifier.size(24.dp))
                    }
                }
            }
        }
    }

    when (sheet) {
        "queue" -> QueueSheet(onDismiss = { sheet = null })
        "sleep" -> SleepSheet(sleepAt, onDismiss = { sheet = null })
        "more" -> MoreSheet(
            track = track,
            speed = speed,
            onDismiss = { sheet = null },
            onAddToPlaylist = { sheet = "add" },
            onSpeed = { sheet = "speed" },
            onArtist = {
                sheet = null
                onClose()
                actions.artist(track.artistUrl)
            },
            onEqualizer = {
                sheet = null
                onClose()
                actions.open(Routes.EQUALIZER)
            }
        )
        "add" -> AddToPlaylistDialog(listOf(track), onDone = { sheet = null })
        "speed" -> SpeedDialog(speed, onDismiss = { sheet = null })
    }
}

/** Icon that's white when off and accent (with a dot under it) when on. */
@Composable
private fun ToggleIcon(icon: ImageVector, label: String, on: Boolean, dot: Boolean = true, onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (dot) Spacer(Modifier.height(6.dp))
            Icon(icon, label, tint = if (on) Sc.Accent else Sc.Text, modifier = Modifier.size(24.dp))
            if (dot) {
                Spacer(Modifier.height(2.dp))
                Box(Modifier.size(4.dp).background(if (on) Sc.Accent else Color.Transparent, CircleShape))
            }
        }
    }
}

/** Shuffle with a sparkle when smart shuffle is on. Taps go off → shuffle → smart shuffle → off. */
@Composable
private fun ShuffleButton(shuffle: Boolean, smart: Boolean, onClick: () -> Unit) {
    val on = shuffle || smart
    val label = when {
        smart && shuffle -> "Smart shuffle on"
        smart -> "Smart picks on"
        shuffle -> "Shuffle on"
        else -> "Shuffle off"
    }
    IconButton(onClick = onClick) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(6.dp))
            Box {
                Icon(Icons.Rounded.Shuffle, label, tint = if (on) Sc.Accent else Sc.Text, modifier = Modifier.size(24.dp))
                if (smart) {
                    Icon(
                        Icons.Rounded.AutoAwesome, null, tint = Sc.Accent,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .offset(x = 6.dp, y = (-6).dp)
                            .size(12.dp)
                    )
                }
            }
            Spacer(Modifier.height(2.dp))
            Box(Modifier.size(4.dp).background(if (on) Sc.Accent else Color.Transparent, CircleShape))
        }
    }
}

/** Thin Spotify-style seek bar: tap or drag anywhere on it. */
@Composable
private fun SeekBar(value: Float, dragging: Boolean, onChange: (Float) -> Unit, onDone: (Float) -> Unit) {
    var last by remember { mutableFloatStateOf(value) }
    // Where the bar is on screen, so letting go can send a wave out from the thumb
    var barLeft by remember { mutableFloatStateOf(0f) }
    var barWidth by remember { mutableFloatStateOf(1f) }
    var barY by remember { mutableFloatStateOf(0f) }
    fun land(f: Float) {
        Wave.fire(Offset(barLeft + barWidth * f, barY), 0.6f)
        onDone(f)
    }
    Box(
        Modifier
            .fillMaxWidth()
            .height(28.dp)
            .onGloballyPositioned {
                val r = it.boundsInWindow()
                barLeft = r.left
                barWidth = r.width.coerceAtLeast(1f)
                barY = r.center.y
            }
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    val f = (o.x / size.width).coerceIn(0f, 1f)
                    land(f)
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        last = (o.x / size.width).coerceIn(0f, 1f)
                        onChange(last)
                    },
                    onDragEnd = { land(last) },
                    onDragCancel = { onDone(last) },
                    onHorizontalDrag = { change, _ ->
                        last = (change.position.x / size.width).coerceIn(0f, 1f)
                        onChange(last)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxWidth().height(14.dp)) {
            val h = 4.dp.toPx()
            val y = size.height / 2
            val w = size.width
            drawRoundRect(Color.White.copy(alpha = 0.25f), topLeft = Offset(0f, y - h / 2), size = Size(w, h), cornerRadius = CornerRadius(h / 2))
            drawRoundRect(if (dragging) Sc.Accent else Color.White, topLeft = Offset(0f, y - h / 2), size = Size(w * value, h), cornerRadius = CornerRadius(h / 2))
            drawCircle(Color.White, radius = if (dragging) 8.dp.toPx() else 6.dp.toPx(), center = Offset(w * value, y))
        }
    }
}

private fun sleepLabel(sleepAt: Long?): String = when {
    sleepAt == null -> ""
    sleepAt == PlayerController.SLEEP_END_OF_SONG -> "End of song"
    else -> {
        val left = ((sleepAt - System.currentTimeMillis()) / 60_000L).coerceAtLeast(0) + 1
        "$left min"
    }
}

// =============================================================================================
// Lyrics
// =============================================================================================

@Composable
private fun LyricsView(track: Track, positionMs: Long, modifier: Modifier, onSeek: (Long) -> Unit) {
    var lyrics by remember(track.videoId) { mutableStateOf<LyricsData?>(null) }
    var loading by remember(track.videoId) { mutableStateOf(true) }

    LaunchedEffect(track.videoId) {
        loading = true
        lyrics = LyricsApi.fetch(track)
        loading = false
    }

    val l = lyrics
    Box(modifier, contentAlignment = Alignment.Center) {
        when {
            loading -> SirenLoader(size = 52.dp, color = Sc.Text)
            l == null || l.isEmpty -> Text("No lyrics for this one", color = Sc.Text.copy(alpha = 0.7f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
            l.instrumental && l.synced.isEmpty() && l.plain.isBlank() -> Text("♪ Instrumental ♪", color = Sc.Text.copy(alpha = 0.7f), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            l.synced.isNotEmpty() -> SyncedLyrics(track, l.synced, positionMs, onSeek, synced = true)
            else -> SyncedLyrics(
                track,
                l.plain.lines().map { LyricLine(-1L, it) },
                positionMs, onSeek, synced = false
            )
        }
    }
}

/**
 * Lyrics list. Synced lyrics follow the song and tap-to-seek. Long-press any line to pick lines
 * (up to 4) and share them as a lyric card.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SyncedLyrics(track: Track, lines: List<LyricLine>, positionMs: Long, onSeek: (Long) -> Unit, synced: Boolean) {
    val actions = LocalActions.current
    val state = rememberLazyListState()
    val picked = remember(track.videoId) { mutableStateListOf<Int>() }
    val picking = picked.isNotEmpty()
    // Show a line a touch early so it feels in time
    val active = if (synced) lines.indexOfLast { it.timeMs <= positionMs + 300 }.coerceAtLeast(0) else -1
    LaunchedEffect(active, picking) {
        if (!synced || picking) return@LaunchedEffect
        val target = (active - 2).coerceAtLeast(0)
        if (abs(state.firstVisibleItemIndex - target) > 12) state.scrollToItem(target)
        else state.animateScrollToItem(target)
    }
    fun toggle(i: Int) {
        if (lines[i].text.isBlank()) return
        if (i in picked) picked.remove(i)
        else if (picked.size < 4) picked.add(i)
        else actions.message("Up to 4 lines")
    }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 40.dp, bottom = if (picking) 96.dp else 40.dp)
        ) {
            itemsIndexed(lines) { i, line ->
                val isActive = i == active
                val past = synced && i < active
                val sel = i in picked
                Text(
                    line.text.ifBlank { "♪" },
                    color = when {
                        picking && sel -> Color.Black
                        picking -> Color.White.copy(alpha = 0.5f)
                        !synced -> Color.White
                        isActive -> Color.White
                        past -> Color.White.copy(alpha = 0.55f)
                        else -> Color.Black.copy(alpha = 0.55f)
                    },
                    fontSize = 24.sp,
                    lineHeight = 32.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (sel) Color.White else Color.Transparent)
                        .combinedClickable(
                            onClick = {
                                when {
                                    picking -> toggle(i)
                                    synced -> onSeek(line.timeMs)
                                }
                            },
                            onLongClick = { toggle(i) }
                        )
                        .padding(vertical = 8.dp, horizontal = 6.dp)
                )
            }
        }
        if (picking) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally)
            ) {
                Text(
                    "Cancel",
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.Black.copy(alpha = 0.45f))
                        .clickable { picked.clear() }
                        .padding(horizontal = 22.dp, vertical = 12.dp)
                )
                Text(
                    if (picked.size == 1) "Share 1 line" else "Share ${picked.size} lines",
                    color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color.White)
                        .clickable {
                            val chosen = picked.sorted().map { lines[it].text.trim() }
                            picked.clear()
                            actions.shareLyrics(track, chosen)
                        }
                        .padding(horizontal = 22.dp, vertical = 12.dp)
                )
            }
        }
    }
}

// =============================================================================================
// Sheets
// =============================================================================================

@UnstableApi
@Composable
private fun QueueSheet(onDismiss: () -> Unit) {
    val queue by PlayerController.queue.collectAsState()
    val index by PlayerController.index.collectAsState()
    val playing by PlayerController.isPlaying.collectAsState()
    val loadingRadio by PlayerController.loadingRadio.collectAsState()
    val radio by PlayerController.radio.collectAsState()
    val source by PlayerController.source.collectAsState()
    val smart by PlayerController.smart.collectAsState()
    val state = rememberLazyListState()
    val pos = queue.indexOfFirst { it.index == index }.coerceAtLeast(0)
    // Keys that survive reordering: the song plus which copy of it this is
    val keys = remember(queue) {
        val seen = HashMap<String, Int>()
        queue.map { q ->
            val n = (seen[q.track.videoId] ?: 0) + 1
            seen[q.track.videoId] = n
            q.track.videoId + "#" + n
        }
    }
    val keysNow by rememberUpdatedState(keys)
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    var rowH by remember { mutableFloatStateOf(1f) }
    var menuFor by remember { mutableStateOf<QueueItem?>(null) }
    var saveAs by remember { mutableStateOf(false) }
    val qActions = LocalActions.current

    if (saveAs) {
        NameDialog("Save queue as playlist", source.ifBlank { "My queue" }, onDismiss = { saveAs = false }) { name ->
            val tracks = queue.map { it.track }
            Library.createPlaylist(name, tracks)
            qActions.message("Saved ${tracks.size} songs to \"${name.ifBlank { "My playlist" }}\"")
            saveAs = false
        }
    }

    menuFor?.let { q ->
        val isCur = q.index == index
        TrackActionsSheet(
            q.track,
            onDismiss = { menuFor = null },
            onPlayNext = if (isCur) ({ }) else ({ PlayerController.moveNextInQueue(q.index) }),
            extra = { close ->
                if (!isCur) DeleteRow("Remove from queue", close) { PlayerController.removeAt(q.index) }
            }
        )
    }

    LaunchedEffect(Unit) { if (pos > 0) state.scrollToItem(pos) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Sc.Sheet
    ) {
        Row(Modifier.padding(start = 20.dp, end = 8.dp, top = 2.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Queue", color = Sc.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    listOf(
                        source.ifBlank { "" },
                        "${(queue.size - pos - 1).coerceAtLeast(0)} up next",
                        if (radio) "radio keeps going" else "",
                        if (smart && !radio) "smart shuffle on" else ""
                    ).filter { it.isNotBlank() }.joinToString(" • "),
                    color = Sc.TextDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = { saveAs = true }) {
                Icon(Icons.AutoMirrored.Rounded.PlaylistAdd, "Save queue as playlist", tint = Sc.Text, modifier = Modifier.size(22.dp))
            }
            if (!radio) {
                TextButton(onClick = { PlayerController.startRadioFromCurrent() }) {
                    Icon(Icons.Rounded.Radio, null, tint = Sc.Text, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Radio", color = Sc.Text, fontWeight = FontWeight.Bold)
                }
            }
            if (queue.size - pos > 1) {
                TextButton(onClick = { PlayerController.clearUpcoming() }) {
                    Icon(Icons.Rounded.ClearAll, null, tint = Sc.Text, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Clear", color = Sc.Text, fontWeight = FontWeight.Bold)
                }
            }
        }
        HorizontalDivider(color = Sc.Outline, modifier = Modifier.padding(top = 6.dp))
        LazyColumn(state = state, modifier = Modifier.heightIn(max = 560.dp).fastScroll(state, minItems = 20)) {
            itemsIndexed(queue, key = { i, _ -> keys.getOrElse(i) { "q$i" } }) { i, q ->
                val isCurrent = q.index == index
                val key = keys.getOrElse(i) { "q$i" }
                val dragging = dragKey == key
                Row(
                    Modifier
                        // Other rows slide out of the way; the one under your finger follows it directly
                        .then(if (dragging) Modifier else Modifier.animateItem())
                        .zIndex(if (dragging) 1f else 0f)
                        .graphicsLayer { translationY = if (dragging) dragOffset else 0f }
                        .onSizeChanged { rowH = it.height.toFloat().coerceAtLeast(1f) }
                        .fillMaxWidth()
                        .background(
                            when {
                                dragging -> Sc.SurfaceHighest
                                isCurrent -> Color.White.copy(alpha = 0.06f)
                                else -> Sc.Sheet
                            }
                        )
                        .clickable { PlayerController.skipTo(q.index) }
                        .padding(start = 4.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Drag handle: hold and move up / down to reorder
                    Box(
                        Modifier
                            .size(width = 40.dp, height = 46.dp)
                            .pointerInput(key) {
                                var at = -1
                                detectVerticalDragGestures(
                                    onDragStart = {
                                        at = keysNow.indexOf(key)
                                        dragKey = key
                                        dragOffset = 0f
                                    },
                                    onDragEnd = { dragKey = null; dragOffset = 0f },
                                    onDragCancel = { dragKey = null; dragOffset = 0f }
                                ) { change, dy ->
                                    change.consume()
                                    if (at < 0) return@detectVerticalDragGestures
                                    dragOffset += dy
                                    val last = keysNow.size - 1
                                    if (dragOffset > rowH / 2 && at < last) {
                                        PlayerController.moveInQueue(at, at + 1)
                                        at++
                                        dragOffset -= rowH
                                    } else if (dragOffset < -rowH / 2 && at > 0) {
                                        PlayerController.moveInQueue(at, at - 1)
                                        at--
                                        dragOffset += rowH
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.DragHandle, "Drag to reorder", tint = if (dragging) Sc.Text else Sc.TextFaint, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.width(4.dp))
                    Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
                        Artwork(q.track.thumbnail, Modifier.fillMaxSize())
                        if (isCurrent) {
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.55f)),
                                contentAlignment = Alignment.Center
                            ) { PlayingBars(playing = playing) }
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            q.track.title,
                            color = if (isCurrent) Sc.Accent else if (i < pos) Sc.TextFaint else Sc.Text,
                            fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (q.smart) {
                                Icon(Icons.Rounded.AutoAwesome, "Smart shuffle pick", tint = Sc.Accent, modifier = Modifier.size(13.dp))
                                Spacer(Modifier.width(4.dp))
                            }
                            Text(Fmt.subtitle(q.track), color = Sc.TextDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    IconButton(onClick = { menuFor = q }) {
                        Icon(Icons.Rounded.MoreVert, "Song options", tint = Sc.TextDim, modifier = Modifier.size(22.dp))
                    }
                }
            }
            if (loadingRadio) {
                item {
                    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        SirenLoader(size = 24.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Finding similar songs…", color = Sc.TextDim, fontSize = 13.sp)
                    }
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

@UnstableApi
@Composable
private fun SleepSheet(sleepAt: Long?, onDismiss: () -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Sc.Sheet
    ) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Text("Sleep timer", color = Sc.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            listOf(5, 10, 15, 30, 45, 60, 90).forEach { m ->
                SheetRow(Icons.Rounded.Timer, "$m minutes") { PlayerController.setSleepMinutes(m); onDismiss() }
            }
            SheetRow(Icons.Rounded.Bedtime, "End of this song") { PlayerController.sleepEndOfSong(); onDismiss() }
            if (sleepAt != null) {
                SheetRow(Icons.Rounded.Close, "Turn off timer", tint = Sc.Error) { PlayerController.cancelSleep(); onDismiss() }
            }
        }
    }
}

@UnstableApi
@Composable
private fun MoreSheet(
    track: Track,
    speed: Float,
    onDismiss: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onSpeed: () -> Unit,
    onArtist: () -> Unit,
    onEqualizer: () -> Unit
) {
    val actions = LocalActions.current
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Sc.Sheet
    ) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Artwork(track.thumbnail, Modifier.size(52.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(track.title, color = Sc.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(track.artist, color = Sc.TextDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            HorizontalDivider(color = Sc.Outline, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
            SheetRow(Icons.AutoMirrored.Rounded.PlaylistAdd, "Add to playlist") { onAddToPlaylist() }
            SheetRow(Icons.Rounded.Radio, "Go to song radio") { PlayerController.startRadioFromCurrent(); onDismiss() }
            if (track.artistUrl.isNotBlank()) SheetRow(Icons.Rounded.Person, "Go to artist") { onArtist() }
            SheetRow(Icons.Rounded.Speed, "Playback speed (${trimSpeed(speed)}x)") { onSpeed() }
            SheetRow(Icons.Rounded.Equalizer, "Equalizer") { onEqualizer() }
            SheetRow(Icons.Rounded.Share, "Share") { actions.share(track); onDismiss() }
            if (track.artist.isNotBlank()) {
                SheetRow(Icons.Rounded.VisibilityOff, "Hide this artist") { onDismiss(); actions.hideArtist(track) }
            }
            SheetRow(Icons.Rounded.DirectionsCar, "Car mode") { UiState.carMode.value = true; onDismiss() }
        }
    }
}

private fun trimSpeed(s: Float): String {
    val r = (s * 100).toInt() / 100f
    return if (r == r.toInt().toFloat()) r.toInt().toString() else r.toString()
}

@UnstableApi
@Composable
private fun SpeedDialog(speed: Float, onDismiss: () -> Unit) {
    val options = listOf(0.5f, 0.75f, 0.9f, 1f, 1.1f, 1.25f, 1.5f, 2f)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Sc.Sheet,
        title = { Text("Playback speed", color = Sc.Text, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                options.forEach { o ->
                    val on = abs(o - speed) < 0.01f
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { PlayerController.setSpeed(o); onDismiss() }
                            .padding(vertical = 11.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            trimSpeed(o) + "x" + if (o == 1f) "  (normal)" else "",
                            color = if (on) Sc.Accent else Sc.Text,
                            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.weight(1f)
                        )
                        if (on) Icon(Icons.Rounded.CheckCircle, null, tint = Sc.Accent, modifier = Modifier.size(18.dp))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Sc.TextDim) } }
    )
}
