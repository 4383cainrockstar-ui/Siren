package app.siren.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable

@Serializable
data class SirenBackup(
    val app: String = "Siren",
    val version: Int = 1,
    val createdAt: Long = 0,
    val library: LibraryData = LibraryData(),
    val settings: AppSettings = AppSettings()
)

object ImportExport {

    // ---------------- Backup ----------------

    suspend fun exportBackup(ctx: Context, uri: Uri) = withContext(Dispatchers.IO) {
        val b = SirenBackup(createdAt = System.currentTimeMillis(), library = Library.value, settings = Settings.current)
        ctx.contentResolver.openOutputStream(uri, "wt")?.use {
            it.write(LibraryJson.json.encodeToString(SirenBackup.serializer(), b).toByteArray())
        } ?: throw IllegalStateException("Couldn't write the backup file")
    }

    suspend fun importBackup(ctx: Context, uri: Uri) = withContext(Dispatchers.IO) {
        val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            ?: throw IllegalStateException("Couldn't read that file")
        val trimmed = text.trimStart('\uFEFF', ' ', '\n', '\r', '\t')
        if (!trimmed.startsWith("{")) {
            throw IllegalStateException(
                "That's a song list, not a Siren backup. To bring in a playlist go to Your Library, tap + and choose Import playlist."
            )
        }
        val b = try {
            LibraryJson.json.decodeFromString(SirenBackup.serializer(), trimmed)
        } catch (e: Exception) {
            throw IllegalStateException("That file isn't a Siren backup")
        }
        // Backups made by Pulse (Siren's old name) restore too
        if (b.app != "Siren" && b.app != "Pulse") throw IllegalStateException("That file isn't a Siren backup")
        // Downloads point at files on the old phone, keep the ones that are still here
        val keep = Library.value.downloads
        Library.replaceAll(b.library.copy(downloads = keep))
        Settings.update { b.settings }
    }

    /** Exports a local playlist as CSV that Exportify-style tools (and Siren) understand. */
    suspend fun exportPlaylistCsv(ctx: Context, playlist: LocalPlaylist, uri: Uri) = withContext(Dispatchers.IO) {
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val sb = StringBuilder("Track Name,Artist Name(s),Duration (s),URL\n")
        playlist.tracks.forEach { t ->
            sb.append(q(t.title)).append(',').append(q(t.artist)).append(',').append(t.duration.coerceAtLeast(0)).append(',').append(q(t.url)).append('\n')
        }
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(sb.toString().toByteArray()) }
            ?: throw IllegalStateException("Couldn't write the file")
    }
}
