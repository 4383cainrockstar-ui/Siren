package app.siren.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import app.siren.data.Settings
import app.siren.player.Eq
import app.siren.player.EqInfo
import app.siren.player.PlayerController
import app.siren.ui.LocalActions
import app.siren.ui.components.Chip
import app.siren.ui.components.EmptyState
import app.siren.ui.components.TopBar
import app.siren.ui.theme.Sc
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.roundToInt

/** Siren's presets, as dB at a few frequencies. They're stretched to fit whatever bands the phone has. */
private val presets: List<Pair<String, List<Pair<Int, Float>>>> = listOf(
    "Flat" to listOf(60 to 0f, 14000 to 0f),
    "Bass boost" to listOf(60 to 6f, 230 to 4f, 910 to 0f, 3600 to 0f, 14000 to 0f),
    "Bass cut" to listOf(60 to -6f, 230 to -3f, 910 to 0f, 3600 to 0f, 14000 to 0f),
    "Treble boost" to listOf(60 to 0f, 230 to 0f, 910 to 0f, 3600 to 3f, 14000 to 6f),
    "Vocal" to listOf(60 to -2f, 230 to -1f, 910 to 3f, 3600 to 4f, 14000 to 1f),
    "Rock" to listOf(60 to 5f, 230 to 3f, 910 to -1f, 3600 to 3f, 14000 to 5f),
    "Pop" to listOf(60 to -1f, 230 to 2f, 910 to 4f, 3600 to 2f, 14000 to -1f),
    "Hip hop" to listOf(60 to 5f, 230 to 4f, 910 to 0f, 3600 to 1f, 14000 to 3f),
    "Electronic" to listOf(60 to 4f, 230 to 2f, 910 to 0f, 3600 to 2f, 14000 to 5f),
    "Acoustic" to listOf(60 to 3f, 230 to 1f, 910 to 1f, 3600 to 2f, 14000 to 3f),
    "Late night" to listOf(60 to 2f, 230 to 1f, 910 to 0f, 3600 to -1f, 14000 to -3f)
)

/** dB for [hz] on a preset curve, interpolated on a log-frequency scale. */
private fun curveAt(points: List<Pair<Int, Float>>, hz: Int): Float {
    val x = log10(hz.coerceAtLeast(20).toFloat())
    if (x <= log10(points.first().first.toFloat())) return points.first().second
    if (x >= log10(points.last().first.toFloat())) return points.last().second
    for (i in 0 until points.size - 1) {
        val a = log10(points[i].first.toFloat())
        val b = log10(points[i + 1].first.toFloat())
        if (x in a..b) {
            val t = (x - a) / (b - a)
            return points[i].second + (points[i + 1].second - points[i].second) * t
        }
    }
    return 0f
}

private fun presetLevels(name: String, info: EqInfo): List<Int> {
    val points = presets.firstOrNull { it.first == name }?.second ?: return info.centersHz.map { 0 }
    return info.centersHz.map { hz -> (curveAt(points, hz) * 100).roundToInt().coerceIn(info.minMb, info.maxMb) }
}

private fun hzLabel(hz: Int) = if (hz >= 1000) {
    val k = hz / 1000f
    (if (k >= 10) k.roundToInt().toString() else "%.1f".format(k).removeSuffix(".0")) + " kHz"
} else "$hz Hz"

@UnstableApi
@Composable
fun EqualizerScreen() {
    val actions = LocalActions.current
    val ctx = LocalContext.current
    val s by Settings.state.collectAsState()
    val info by Eq.info.collectAsState()

    Column(Modifier.fillMaxSize()) {
        TopBar("Equalizer", onBack = { actions.back() })
        val i = info
        if (i == null) {
            EmptyState(
                Icons.Rounded.Equalizer,
                "Equalizer isn't ready",
                "Play a song first. If it still doesn't show up, this phone doesn't let apps use its equalizer. Your phone's own equalizer works instead."
            )
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                TextButton(onClick = { openSystemEq(ctx, actions::message) }) {
                    Text("Open the phone's equalizer", color = Sc.Accent, fontWeight = FontWeight.Bold)
                }
            }
        } else {

        // Levels being edited (millibels), kept in step with Settings
        var levels by remember(i) {
            mutableStateOf(i.centersHz.indices.map { idx -> s.eqBands.getOrNull(idx) ?: 0 })
        }
        LaunchedEffect(s.eqBands, i) {
            levels = i.centersHz.indices.map { idx -> s.eqBands.getOrNull(idx) ?: 0 }
        }

        fun save(newLevels: List<Int>, preset: String) {
            levels = newLevels
            Settings.update { it.copy(eqBands = newLevels, eqPreset = preset, eqEnabled = true) }
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { Settings.update { it.copy(eqEnabled = !it.eqEnabled) } }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Equalizer", color = Sc.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(if (s.eqEnabled) s.eqPreset else "Off", color = Sc.TextDim, fontSize = 13.sp)
                }
                Switch(
                    checked = s.eqEnabled,
                    onCheckedChange = { on -> Settings.update { it.copy(eqEnabled = on) } },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Sc.Accent,
                        checkedBorderColor = Sc.Accent,
                        uncheckedThumbColor = Sc.TextDim,
                        uncheckedTrackColor = Sc.SurfaceHighest,
                        uncheckedBorderColor = Sc.SurfaceHighest
                    )
                )
            }

            Column(Modifier.alpha(if (s.eqEnabled) 1f else 0.55f)) {
                EqCurve(
                    info = i,
                    levels = levels,
                    onDrag = { l ->
                        levels = l
                        Eq.preview(l, enabled = true)
                    },
                    onDone = { l -> save(l, "Custom") },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                Text(
                    "Drag the dots to shape the sound, or start from a preset.",
                    color = Sc.TextDim, fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                Text("Presets", color = Sc.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 10.dp))
                FlowRow(
                    Modifier.padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presets.forEach { (name, _) ->
                        Chip(name, s.eqEnabled && s.eqPreset == name, { save(presetLevels(name, i), name) })
                    }
                    if (s.eqPreset == "Custom") Chip("Custom", s.eqEnabled, {})
                }

                if (i.bassBoost) {
                    Text("Bass boost", color = Sc.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 2.dp))
                    var bass by remember { mutableFloatStateOf(s.eqBass / 1000f) }
                    LaunchedEffect(s.eqBass) { bass = s.eqBass / 1000f }
                    Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Slider(
                            value = bass,
                            onValueChange = { bass = it },
                            onValueChangeFinished = {
                                val v = (bass * 1000).roundToInt()
                                Settings.update { it.copy(eqBass = v, eqEnabled = true) }
                            },
                            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Sc.Accent, inactiveTrackColor = Sc.SurfaceHighest),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(if (bass <= 0.01f) "Off" else "${(bass * 100).roundToInt()}%", color = Sc.TextDim, fontSize = 13.sp, modifier = Modifier.width(40.dp), textAlign = TextAlign.End)
                    }
                }

                Row(Modifier.padding(horizontal = 8.dp, vertical = 16.dp)) {
                    TextButton(onClick = {
                        save(i.centersHz.map { 0 }, "Flat")
                        Settings.update { it.copy(eqBass = 0) }
                    }) { Text("Reset", color = Sc.Text, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { openSystemEq(ctx, actions::message) }) {
                        Text("Phone's equalizer", color = Sc.TextDim)
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
        }
    }
}

@UnstableApi
private fun openSystemEq(ctx: android.content.Context, message: (String) -> Unit) {
    try {
        ctx.startActivity(PlayerController.equalizerIntent())
    } catch (e: Exception) {
        message("No equalizer found on this phone")
    }
}

/** The frequency curve: one draggable dot per band, a smooth line through them, dB while dragging. */
@Composable
private fun EqCurve(
    info: EqInfo,
    levels: List<Int>,
    onDrag: (List<Int>) -> Unit,
    onDone: (List<Int>) -> Unit,
    modifier: Modifier = Modifier
) {
    val n = info.centersHz.size
    val current by rememberUpdatedState(levels)
    var active by remember { mutableIntStateOf(-1) }
    val span = (info.maxMb - info.minMb).coerceAtLeast(1)

    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Sc.Surface)
            .padding(vertical = 12.dp)
    ) {
        // dB readout for the dot being dragged
        Text(
            if (active in levels.indices) {
                val db = levels[active] / 100f
                (if (db > 0) "+" else "") + "%.1f".format(db) + " dB at " + hzLabel(info.centersHz[active])
            } else "${info.maxMb / 100} dB",
            color = if (active >= 0) Sc.Text else Sc.TextFaint,
            fontSize = 12.sp,
            fontWeight = if (active >= 0) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(start = 14.dp, bottom = 4.dp)
        )
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(200.dp)
                .pointerInput(info) {
                    val pad = size.width / (2f * n.coerceAtLeast(1))
                    fun bandAt(x: Float): Int {
                        if (n <= 1) return 0
                        val step = (size.width - 2 * pad) / (n - 1)
                        return ((x - pad) / step).roundToInt().coerceIn(0, n - 1)
                    }
                    fun levelAt(y: Float): Int {
                        val t = (y / size.height).coerceIn(0f, 1f)
                        val mb = info.maxMb - t * span
                        // Snap to 0.5 dB
                        return ((mb / 50f).roundToInt() * 50).coerceIn(info.minMb, info.maxMb)
                    }
                    detectDragGestures(
                        onDragStart = { o ->
                            active = bandAt(o.x)
                            onDrag(current.toMutableList().also { it[active] = levelAt(o.y) })
                        },
                        onDragEnd = {
                            onDone(current)
                            active = -1
                        },
                        onDragCancel = {
                            onDone(current)
                            active = -1
                        }
                    ) { change, _ ->
                        change.consume()
                        if (active in 0 until n) onDrag(current.toMutableList().also { it[active] = levelAt(change.position.y) })
                    }
                }
                .pointerInput(info) {
                    val pad = size.width / (2f * n.coerceAtLeast(1))
                    detectTapGestures { o ->
                        if (n == 0) return@detectTapGestures
                        val step = if (n <= 1) 1f else (size.width - 2 * pad) / (n - 1)
                        val b = ((o.x - pad) / step).roundToInt().coerceIn(0, n - 1)
                        val t = (o.y / size.height).coerceIn(0f, 1f)
                        val mb = ((info.maxMb - t * span) / 50f).roundToInt() * 50
                        onDone(current.toMutableList().also { it[b] = mb.coerceIn(info.minMb, info.maxMb) })
                    }
                }
        ) {
            val pad = size.width / (2f * n.coerceAtLeast(1))
            val w = size.width
            val h = size.height
            fun yOf(mb: Int) = h * (info.maxMb - mb).toFloat() / span
            // Grid: +max, 0 dB, -max
            listOf(info.maxMb, 0, info.minMb).forEach { mb ->
                val y = yOf(mb)
                drawLine(if (mb == 0) Color.White.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.08f), Offset(0f, y), Offset(w, y), strokeWidth = 1.dp.toPx())
            }
            if (n == 0) return@Canvas
            val step = if (n <= 1) 0f else (w - 2 * pad) / (n - 1)
            val pts = (0 until n).map { Offset(pad + it * step, yOf(levels.getOrElse(it) { 0 })) }
            // Smooth line through the dots
            val line = Path().apply {
                moveTo(0f, pts.first().y)
                lineTo(pts.first().x, pts.first().y)
                for (k in 0 until pts.size - 1) {
                    val a = pts[k]
                    val b = pts[k + 1]
                    val mx = (a.x + b.x) / 2
                    cubicTo(mx, a.y, mx, b.y, b.x, b.y)
                }
                lineTo(w, pts.last().y)
            }
            val fill = Path().apply {
                addPath(line)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(fill, Brush.verticalGradient(listOf(Sc.Accent.copy(alpha = 0.35f), Color.Transparent)))
            drawPath(line, Sc.Accent, style = Stroke(width = 3.dp.toPx()))
            pts.forEachIndexed { k, p ->
                val r = if (k == active) 11.dp.toPx() else 8.dp.toPx()
                drawCircle(Color.White, r, p)
                drawCircle(Sc.Accent, r - 3.dp.toPx(), p)
            }
        }
        // Band labels
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            info.centersHz.forEachIndexed { k, hz ->
                Text(
                    hzLabel(hz),
                    color = if (k == active) Sc.Text else Sc.TextDim,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
