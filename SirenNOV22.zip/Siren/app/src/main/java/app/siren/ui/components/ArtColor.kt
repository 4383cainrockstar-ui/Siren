package app.siren.ui.components

import android.content.Context
import android.util.LruCache
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import app.siren.core.hiRes
import app.siren.ui.theme.Sc
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Pulls a color out of album art (like Spotify's player and headers), then darkens it
 * into a band where white text always reads well.
 */
object ArtColors {
    private val cache = LruCache<String, Int>(300)

    fun cached(url: String): Color? = cache.get(url)?.let { Color(it) }

    suspend fun extract(ctx: Context, url: String): Color? = withContext(Dispatchers.IO) {
        if (url.isBlank()) return@withContext null
        cache.get(url)?.let { return@withContext Color(it) }
        try {
            val req = ImageRequest.Builder(ctx)
                .data(hiRes(url, 120))
                .allowHardware(false)
                .size(96)
                .build()
            val result = ctx.imageLoader.execute(req) as? SuccessResult ?: return@withContext null
            val bmp = result.drawable.toBitmap()
            val p = Palette.from(bmp).maximumColorCount(16).generate()
            val dominant = p.dominantSwatch
            val hslD = FloatArray(3)
            val pick = if (dominant != null) {
                ColorUtils.colorToHSL(dominant.rgb, hslD)
                // A grey / black dominant color makes a dull gradient: prefer something with life in it
                if (hslD[1] < 0.18f) (p.vibrantSwatch ?: p.darkVibrantSwatch ?: p.mutedSwatch ?: dominant) else dominant
            } else {
                p.vibrantSwatch ?: p.mutedSwatch
            } ?: return@withContext null
            val hsl = FloatArray(3)
            ColorUtils.colorToHSL(pick.rgb, hsl)
            hsl[1] = hsl[1].coerceAtMost(0.7f)
            hsl[2] = hsl[2].coerceIn(0.2f, 0.34f)
            val out = ColorUtils.HSLToColor(hsl)
            cache.put(url, out)
            Color(out)
        } catch (e: Exception) {
            null
        }
    }
}

/** The (animated) color for a piece of artwork, [fallback] until it's known. */
@Composable
fun rememberArtColor(url: String, fallback: Color = Sc.SurfaceHighest): Color {
    val ctx = LocalContext.current
    var color by remember(url) { mutableStateOf(ArtColors.cached(url)) }
    LaunchedEffect(url) {
        if (color == null && url.isNotBlank()) color = ArtColors.extract(ctx, url)
    }
    val animated by animateColorAsState(if (Sc.oled) Color.Black else (color ?: fallback), tween(500), label = "artColor")
    return animated
}
