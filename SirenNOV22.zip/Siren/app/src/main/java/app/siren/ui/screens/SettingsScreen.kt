package app.siren.ui.screens

import androidx.compose.material.icons.rounded.Folder
import app.siren.data.LocalMusic
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Contrast
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.DownloadForOffline
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Navigation
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material3.Icon
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import app.siren.data.AppSettings
import app.siren.ui.UiState
import app.siren.ui.components.FindBar
import kotlinx.coroutines.delay
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import app.siren.BuildConfig
import app.siren.core.Music
import app.siren.data.ImportExport
import app.siren.data.Library
import app.siren.data.Settings
import app.siren.player.PlayerController
import app.siren.ui.LocalActions
import app.siren.ui.Routes
import app.siren.ui.components.Chip
import app.siren.player.WeeklyMix
import app.siren.ui.components.ConfirmDialog
import app.siren.ui.components.SirenMark
import app.siren.ui.components.TopBar
import app.siren.ui.theme.Sc
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

@UnstableApi
@Composable
fun SettingsScreen() {
    val actions = LocalActions.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val s by Settings.state.collectAsState()
    var cachePicker by remember { mutableStateOf(false) }
    var confirmSearches by remember { mutableStateOf(false) }
    var restorePending by remember { mutableStateOf(false) }
    var autoHelp by remember { mutableStateOf(false) }
    var smartPicker by remember { mutableStateOf(false) }
    var page by rememberSaveable { mutableStateOf("") }
    val pickLocal = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) LocalMusic.addFolder(ctx, uri)
    }
    var query by rememberSaveable { mutableStateOf("") }
    val lib by Library.data.collectAsState()
    var connected by remember { mutableStateOf(emptyList<String>()) }
    LaunchedEffect(page) {
        // Bluetooth devices connected right now (for picking your car)
        while (page == "car") {
            connected = connectedBluetoothNames(ctx)
            delay(3000)
        }
    }

    val backup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try {
                ImportExport.exportBackup(ctx, uri)
                actions.message("Backup saved")
            } catch (e: Exception) {
                actions.message(Music.friendlyError(e))
            }
        }
    }
    val restore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                ImportExport.importBackup(ctx, uri)
                PlayerController.applySettings()
                actions.message("Library restored")
            } catch (e: Exception) {
                actions.message(Music.friendlyError(e))
            }
        }
    }

    val pages = settingsPages()
    val title = when (page) {
        "" -> "Settings"
        HIDDEN -> "Hidden artists"
        else -> pages.firstOrNull { it.key == page }?.title ?: "Settings"
    }
    fun goBack() {
        if (page == "") actions.back()
        else page = if (page == HIDDEN) "foryou" else ""
    }
    BackHandler(enabled = page != "") { goBack() }

    Column(Modifier.fillMaxSize()) {
        TopBar(title, onBack = { goBack() })
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            when (page) {
                "" -> {
                    FindBar(query, { query = it }, "Search settings", Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp))
                    if (query.isNotBlank()) {
                        val q = query.trim().lowercase()
                        val hits = SETTING_INDEX.filter { (name, _) -> name.lowercase().contains(q) }
                        if (hits.isEmpty()) Caption("Nothing matches \"${query.trim()}\"")
                        hits.forEach { (name, key) ->
                            Action(name, "In " + (pages.firstOrNull { it.key == key }?.title ?: "")) {
                                query = ""
                                page = key
                            }
                        }
                    } else {
                        pages.forEach { pg ->
                            CategoryRow(pg.icon, pg.title, pg.summary(s, lib.hiddenArtists.size)) { page = pg.key }
                        }
                        About()
                    }
                }

                "playback" -> {
                    Toggle("High quality audio", "Best stream available. Turn off to save data.", s.highQuality) {
                        Settings.update { st -> st.copy(highQuality = it) }
                        PlayerController.qualityChanged()
                    }
                    Toggle(
                        "Explicit versions",
                        "When a song has an explicit and a clean version, play the explicit one. Clean only plays when there's no explicit version.",
                        s.preferExplicit
                    ) { Settings.update { st -> st.copy(preferExplicit = it) } }
                    Toggle("Autoplay", "When your music ends, keep going with similar songs.", s.autoRadio) {
                        Settings.update { st -> st.copy(autoRadio = it) }
                    }
                    Toggle(
                        "Smart shuffle",
                        "Every few songs, a song picked for your taste slips into the queue, from artists you haven't just heard. It's also the third tap on the player's shuffle button.",
                        s.smartShuffle
                    ) { PlayerController.setSmart(it) }
                    if (s.smartShuffle) {
                        Action("Smart shuffle picks", "A new pick every ${ordinal(s.smartEvery)} song") { smartPicker = true }
                        VarietySlider(s.smartVariety) { v -> Settings.update { it.copy(smartVariety = v) } }
                    }
                    Toggle("Resume where you left off", "Brings back your queue when Siren opens.", s.restoreQueue) {
                        Settings.update { st -> st.copy(restoreQueue = it) }
                    }
                    Toggle("Open the player on lyrics", "Show lyrics instead of the cover by default.", s.showLyricsByDefault) {
                        Settings.update { st -> st.copy(showLyricsByDefault = it) }
                    }
                    Action("Equalizer", if (s.eqEnabled) "On · ${s.eqPreset}" else "Off. Shape the sound with presets, bands and bass boost.") {
                        actions.open(Routes.EQUALIZER)
                    }
                }

                "sound" -> {
                    Toggle("Crossfade", "Fades each song out and the next one in at the changeover.", s.crossfadeSec > 0) {
                        Settings.update { st -> st.copy(crossfadeSec = if (it) 5 else 0) }
                    }
                    if (s.crossfadeSec > 0) {
                        CrossfadeSlider(s.crossfadeSec) { v -> Settings.update { it.copy(crossfadeSec = v) } }
                    }
                    if (android.os.Build.VERSION.SDK_INT >= 28) {
                        Toggle("Normalize volume", "Evens out loud and quiet songs so you're not reaching for the volume.", s.normalize) {
                            Settings.update { st -> st.copy(normalize = it) }
                        }
                        if (s.normalize) {
                            LevelPicker(s.normalizeLevel) { v -> Settings.update { it.copy(normalizeLevel = v) } }
                        }
                    }
                    Toggle("Skip silence", "Trims silent gaps inside songs.", s.skipSilence) {
                        Settings.update { st -> st.copy(skipSilence = it) }
                        PlayerController.applySettings()
                    }
                    Toggle("Skip non-music parts", "Skips talking intros and outros in music videos (SponsorBlock).", s.skipNonMusic) {
                        Settings.update { st -> st.copy(skipNonMusic = it) }
                    }
                    Toggle(
                        "Keep playing during calls",
                        "Music keeps going, turned down, while you're on a call (phone, Discord, WhatsApp…), then comes back up when you hang up. Some phones mute all music during calls no matter what; Siren tries to slip past that.",
                        s.keepDuringCalls
                    ) {
                        Settings.update { st -> st.copy(keepDuringCalls = it) }
                        PlayerController.applySettings()
                    }
                }

                "streaming" -> {
                    Toggle("Load next songs early", "Gets the next few songs ready while the current one plays, so new songs start right away.", s.preloadNext) {
                        Settings.update { st -> st.copy(preloadNext = it) }
                    }
                    if (s.preloadNext) {
                        Toggle("Only on Wi-Fi", "Skips loading ahead on mobile data.", s.preloadWifiOnly) {
                            Settings.update { st -> st.copy(preloadWifiOnly = it) }
                        }
                    }
                }

                "foryou" -> {
                    Toggle(
                        "Weekly mix",
                        "Every Monday Siren rebuilds one playlist, mostly songs you haven't heard plus a few you know. It replaces itself, so you only ever have one. Turning this off stops updates and keeps the current one.",
                        s.weeklyMix
                    ) {
                        Settings.update { st -> st.copy(weeklyMix = it) }
                        if (it) WeeklyMix.ensureFresh()
                    }
                    if (s.weeklyMix) {
                        Action("Rebuild weekly mix now", "Swaps in a fresh set right away.") {
                            actions.message("Building your weekly mix…")
                            WeeklyMix.ensureFresh(force = true) { ok ->
                                actions.message(if (ok) "Your weekly mix is ready" else "Couldn't build it right now. Try again in a bit.")
                            }
                        }
                    }
                    Toggle(
                        "Hold Next to hide an artist",
                        "Hold the Next button for 3 seconds: the song skips and that artist stops showing up in radio, autoplay, mixes and suggestions. Songs you pick yourself still play.",
                        s.holdToHide
                    ) { Settings.update { st -> st.copy(holdToHide = it) } }
                    Action(
                        "Hidden artists",
                        if (lib.hiddenArtists.isEmpty()) "None yet" else lib.hiddenArtists.size.let { if (it == 1) "1 artist" else "$it artists" } + ". Tap to unhide."
                    ) { page = HIDDEN }
                }

                HIDDEN -> {
                    if (lib.hiddenArtists.isEmpty()) {
                        Caption("No hidden artists. Hold Next for 3 seconds on a song (or pick Hide this artist in the player's menu) to keep that artist out of your radio and mixes.")
                    }
                    lib.hiddenArtists.forEach { h ->
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(h.name, color = Sc.Text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            Text(
                                "Unhide",
                                color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(Color.White)
                                    .clickable {
                                        Library.unhideArtist(h.key)
                                        actions.message("${h.name} is back")
                                    }
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                "car" -> {
                    Action("Open car mode", "Big buttons, nothing to scroll, screen stays on. Also in the player's ⋮ menu.") {
                        UiState.carMode.value = true
                    }
                    Toggle(
                        "Open by itself in the car",
                        "When your car's Bluetooth connects, car mode opens (as long as Siren is open or you open it).",
                        s.carAutoOpen
                    ) { Settings.update { st -> st.copy(carAutoOpen = it) } }
                    Caption("Your car")
                    if (s.carDevices.isEmpty()) {
                        Caption("None yet. Connect to your car's Bluetooth, then add it from the list below.")
                    }
                    s.carDevices.forEach { name ->
                        DeviceRow(name, "Remove") {
                            Settings.update { st -> st.copy(carDevices = st.carDevices - name) }
                        }
                    }
                    val others = connected.filter { it !in s.carDevices }
                    if (others.isNotEmpty()) {
                        Caption("Connected now")
                        others.forEach { name ->
                            DeviceRow(name, "Add") {
                                Settings.update { st -> st.copy(carDevices = (st.carDevices + name).distinct(), carAutoOpen = true) }
                            }
                        }
                    }
                }

                "local" -> {
                    val folders by LocalMusic.folders.collectAsState()
                    val scan by LocalMusic.scan.collectAsState()
                    val localCount by LocalMusic.tracks.collectAsState()
                    Caption("Siren plays music files from folders you pick (covers and tags included). They show up in Your Library as On this device, and play offline.")
                    if (folders.isEmpty()) {
                        Action("Add a folder", "Music, Download, or wherever your songs are") { pickLocal.launch(null) }
                    } else {
                        Caption("${localCount.size} songs from ${folders.size} folder" + if (folders.size == 1) "" else "s")
                        LocalFolders(folders, scan, onAdd = { pickLocal.launch(null) })
                        Action("Open On this device", null) { actions.open(Routes.DEVICE) }
                    }
                }

                "appearance" -> {
                    Toggle("Pure OLED black", "True black everywhere, including cards and menus, with no album-color tints. Saves battery on OLED screens.", s.pureOled) {
                        Settings.update { st -> st.copy(pureOled = it) }
                        Sc.oled = it
                        (ctx as? android.app.Activity)?.recreate()
                    }
                    Toggle(
                        "Distortion wave",
                        "A shockwave bends the screen from the button when you like a song, follow an artist, skip, play or pause, add to the queue, or finish a download. Needs Android 13 or newer.",
                        s.rippleEffects
                    ) { Settings.update { st -> st.copy(rippleEffects = it) } }
                }

                "downloads" -> {
                    Toggle("Download on Wi-Fi only", "Downloads wait until you're off mobile data.", s.wifiOnlyDownloads) {
                        Settings.update { st -> st.copy(wifiOnlyDownloads = it) }
                    }
                    Toggle("Download liked songs", "Every song you like gets saved for offline.", s.autoDownloadLikes) { on ->
                        Settings.update { st -> st.copy(autoDownloadLikes = on) }
                        if (on) {
                            val missing = Library.value.liked
                            if (missing.isNotEmpty()) actions.download(missing)
                        }
                    }
                    Action("Song cache", "${label(s.cacheMb)}. Songs you play are kept here so replays skip the network. Applies after a restart.") {
                        cachePicker = true
                    }
                    Action("Clear image cache", "Frees the space used by album art") {
                        scope.launch {
                            withContext(Dispatchers.IO) {
                                File(ctx.cacheDir, "artwork").deleteRecursively()
                                File(ctx.cacheDir, "auto-art").deleteRecursively()
                            }
                            actions.message("Image cache cleared")
                        }
                    }
                }

                "auto" -> {
                    Action("Set up Android Auto", "Siren shows up in Android Auto with your library, search and voice. Tap for setup.") {
                        autoHelp = true
                    }
                    Caption("Layout in the car. Grid shows big cover art with a short title under it, list shows rows. Changes show up the next time the car loads Siren.")
                    val allGrid = s.autoGridHome && s.autoGridLiked && s.autoGridPlaylists && s.autoGridSongs && s.autoGridDownloads
                    val allList = !s.autoGridHome && !s.autoGridLiked && !s.autoGridPlaylists && !s.autoGridSongs && !s.autoGridDownloads
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip("Art-first", allGrid, {
                            Settings.update { it.copy(autoGridHome = true, autoGridLiked = true, autoGridPlaylists = true, autoGridSongs = true, autoGridDownloads = true) }
                        })
                        Chip("Classic lists", allList, {
                            Settings.update { it.copy(autoGridHome = false, autoGridLiked = false, autoGridPlaylists = false, autoGridSongs = false, autoGridDownloads = false) }
                        })
                    }
                    LayoutChoice("Home", s.autoGridHome) { g -> Settings.update { it.copy(autoGridHome = g) } }
                    LayoutChoice("Liked songs", s.autoGridLiked) { g -> Settings.update { it.copy(autoGridLiked = g) } }
                    LayoutChoice("Playlists & albums", s.autoGridPlaylists) { g -> Settings.update { it.copy(autoGridPlaylists = g) } }
                    LayoutChoice("Songs inside a playlist", s.autoGridSongs) { g -> Settings.update { it.copy(autoGridSongs = g) } }
                    LayoutChoice("Downloads", s.autoGridDownloads) { g -> Settings.update { it.copy(autoGridDownloads = g) } }
                    Caption("Buttons next to skip. They also show in the notification and on the lockscreen.")
                    Toggle("Like", "Heart that saves the song to Liked songs", s.autoLikeButton) { on ->
                        Settings.update { it.copy(autoLikeButton = on) }
                    }
                    Toggle("Shuffle", "Tap to go shuffle → smart shuffle → off", s.autoShuffleButton) { on ->
                        Settings.update { it.copy(autoShuffleButton = on) }
                    }
                    Toggle("Repeat", "Tap to go repeat all → repeat one → off", s.autoRepeatButton) { on ->
                        Settings.update { it.copy(autoRepeatButton = on) }
                    }
                }

                "privacy" -> {
                    Toggle("Pause listening history", "Nothing new gets added to History or Quick picks.", s.pauseHistory) {
                        Settings.update { st -> st.copy(pauseHistory = it) }
                    }
                    Toggle("Save recent searches", "Keeps the songs, artists, albums and playlists you open from Search.", s.saveSearchHistory) {
                        Settings.update { st -> st.copy(saveSearchHistory = it) }
                    }
                    Action("Back up your library", "Likes, playlists, artists, history and settings in one file") {
                        backup.launch("siren-backup.json")
                    }
                    Spacer(Modifier.height(16.dp))
                    Action("Clear recent searches", null) { confirmSearches = true }
                    Action("Restore from backup", "Replaces your current library. Pulse backups work too.") { restorePending = true }
                }
            }
            Spacer(Modifier.height(36.dp))
        }
    }

    if (cachePicker) {
        AlertDialog(
            onDismissRequest = { cachePicker = false },
            containerColor = Sc.Sheet,
            title = { Text("Song cache size", color = Sc.Text, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Settings.cacheOptions.forEach { mb ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    Settings.update { it.copy(cacheMb = mb) }
                                    cachePicker = false
                                    actions.message("Cache set to ${label(mb)}. Restart Siren to apply.")
                                }
                                .padding(vertical = 11.dp)
                        ) {
                            Text(
                                label(mb),
                                color = if (mb == s.cacheMb) Sc.Accent else Sc.Text,
                                fontWeight = if (mb == s.cacheMb) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { cachePicker = false }) { Text("Close", color = Sc.TextDim) } }
        )
    }
    if (smartPicker) {
        AlertDialog(
            onDismissRequest = { smartPicker = false },
            containerColor = Sc.Sheet,
            title = { Text("Smart shuffle picks", color = Sc.Text, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Settings.smartOptions.forEach { n ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    Settings.update { it.copy(smartEvery = n) }
                                    PlayerController.smartEveryChanged()
                                    smartPicker = false
                                }
                                .padding(vertical = 11.dp)
                        ) {
                            Text(
                                "Every ${ordinal(n)} song",
                                color = if (n == s.smartEvery) Sc.Accent else Sc.Text,
                                fontWeight = if (n == s.smartEvery) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { smartPicker = false }) { Text("Close", color = Sc.TextDim) } }
        )
    }
    if (autoHelp) {
        AlertDialog(
            onDismissRequest = { autoHelp = false },
            containerColor = Sc.Sheet,
            title = { Text("Siren in Android Auto", color = Sc.Text, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Android Auto hides apps that weren't installed from the Play Store until you allow them once:",
                        color = Sc.TextDim, fontSize = 14.sp
                    )
                    Text(
                        "1. Open Android Auto settings on your phone (Settings → Connected devices → Android Auto).\n" +
                            "2. Scroll down and tap Version about 10 times until developer mode turns on.\n" +
                            "3. Open the ⋮ menu → Developer settings → turn on Unknown sources.\n" +
                            "4. Back in Android Auto settings → Customize launcher, make sure Siren is ticked.",
                        color = Sc.Text, fontSize = 14.sp, lineHeight = 21.sp
                    )
                    Text(
                        "After that Siren has its own tile in the car with Home, Liked, Playlists and Downloads, plus search and \"Hey Google, play … on Siren\".",
                        color = Sc.TextDim, fontSize = 14.sp
                    )
                }
            },
            confirmButton = { TextButton(onClick = { autoHelp = false }) { Text("Got it", color = Sc.Accent, fontWeight = FontWeight.Bold) } }
        )
    }
    if (confirmSearches) {
        ConfirmDialog("Clear recent searches?", "Everything under Recent searches will be removed.", "Clear", onDismiss = { confirmSearches = false }) {
            Library.clearSearches()
        }
    }
    if (restorePending) {
        ConfirmDialog(
            "Restore a backup?", "Your current likes, playlists and history get replaced by the backup.", "Choose file",
            onDismiss = { restorePending = false }
        ) { restore.launch(arrayOf("application/json", "text/*", "*/*")) }
    }
}

private fun label(mb: Int) = if (mb >= 1024) "${mb / 1024} GB" else "$mb MB"

private fun ordinal(n: Int) = when (n) {
    2 -> "2nd"
    3 -> "3rd"
    else -> "${n}th"
}

@Composable
private fun Caption(text: String) {
    Text(
        text,
        color = Sc.TextDim,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 2.dp)
    )
}

/** "Home        [List | Grid]" */
@Composable
private fun LayoutChoice(title: String, grid: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Sc.Text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Row(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(Sc.SurfaceHighest)
                .padding(3.dp)
        ) {
            Segment("List", !grid) { onChange(false) }
            Segment("Grid", grid) { onChange(true) }
        }
    }
}

@Composable
private fun Segment(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text,
        color = if (selected) Color.Black else Sc.TextDim,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Color.White else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp)
    )
}


@Composable
private fun Toggle(title: String, body: String?, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!value) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Sc.Text, fontSize = 16.sp)
            if (body != null) {
                Spacer(Modifier.height(2.dp))
                Text(body, color = Sc.TextDim, fontSize = 13.sp, lineHeight = 18.sp)
            }
        }
        Spacer(Modifier.width(16.dp))
        Switch(
            checked = value,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Sc.Accent,
                checkedBorderColor = Sc.Accent,
                uncheckedThumbColor = Sc.TextDim,
                uncheckedTrackColor = Sc.SurfaceHighest,
                uncheckedBorderColor = Sc.SurfaceHighest
            )
        )
    }
}

private val varietyHelp = listOf(
    "Stays close to what you're playing and leans on songs you already like.",
    "Mostly close matches, with the odd song you know well.",
    "A mix of close matches and new artists.",
    "Reaches further: more artists you don't usually play.",
    "Goes exploring: new artists and songs you've never heard."
)

/** Crossfade length, 1 to 12 seconds. */
@Composable
private fun CrossfadeSlider(value: Int, onChange: (Int) -> Unit) {
    var v by remember(value) { mutableStateOf(value.toFloat()) }
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text("Crossfade length: ${v.roundToInt().coerceIn(1, 12)} s", color = Sc.Text, fontSize = 16.sp)
        Slider(
            value = v,
            onValueChange = { v = it },
            onValueChangeFinished = { onChange(v.roundToInt().coerceIn(1, 12)) },
            valueRange = 1f..12f,
            steps = 10,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Sc.Accent,
                inactiveTrackColor = Sc.SurfaceHighest,
                activeTickColor = Color.White.copy(alpha = 0.6f),
                inactiveTickColor = Sc.TextFaint
            )
        )
    }
}

/** How hard volume normalization works. */
@Composable
private fun LevelPicker(value: Int, onChange: (Int) -> Unit) {
    val names = listOf("Gentle", "Balanced", "Strong")
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text("Normalize level", color = Sc.Text, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            names.forEachIndexed { i, n -> Chip(n, selected = value == i, onClick = { onChange(i) }) }
        }
    }
}

/** Smart shuffle's Familiar ↔ Adventurous setting. */
@Composable
private fun VarietySlider(value: Int, onChange: (Int) -> Unit) {
    var v by remember(value) { mutableStateOf(value.toFloat()) }
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text("Smart shuffle variety", color = Sc.Text, fontSize = 16.sp)
        Spacer(Modifier.height(2.dp))
        Text(varietyHelp[v.roundToInt().coerceIn(0, 4)], color = Sc.TextDim, fontSize = 13.sp, lineHeight = 18.sp)
        Slider(
            value = v,
            onValueChange = { v = it },
            onValueChangeFinished = { onChange(v.roundToInt().coerceIn(0, 4)) },
            valueRange = 0f..4f,
            steps = 3,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Sc.Accent,
                inactiveTrackColor = Sc.SurfaceHighest,
                activeTickColor = Color.White.copy(alpha = 0.6f),
                inactiveTickColor = Sc.TextFaint
            )
        )
        Row(Modifier.fillMaxWidth()) {
            Text("Familiar", color = Sc.TextDim, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("Adventurous", color = Sc.TextDim, fontSize = 12.sp)
        }
    }
}

@Composable
private fun Action(title: String, body: String?, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 13.dp)
    ) {
        Text(title, color = Sc.Text, fontSize = 16.sp)
        if (body != null) {
            Spacer(Modifier.height(2.dp))
            Text(body, color = Sc.TextDim, fontSize = 13.sp, lineHeight = 18.sp)
        }
    }
}

private const val HIDDEN = "hidden"

private class SettingsPage(val key: String, val title: String, val icon: ImageVector, val summary: (AppSettings, Int) -> String)

private fun onOff(b: Boolean) = if (b) "on" else "off"

private fun settingsPages() = listOf(
    SettingsPage("playback", "Playback", Icons.Rounded.PlayCircle) { s, _ ->
        "Autoplay ${onOff(s.autoRadio)} · Smart shuffle ${onOff(s.smartShuffle)}" + if (s.eqEnabled) " · EQ ${s.eqPreset}" else ""
    },
    SettingsPage("sound", "Sound", Icons.Rounded.GraphicEq) { s, _ ->
        (if (s.crossfadeSec > 0) "Crossfade ${s.crossfadeSec} s" else "Crossfade off") + " · Normalize ${onOff(s.normalize)}" +
            if (s.keepDuringCalls) " · Plays during calls" else ""
    },
    SettingsPage("streaming", "Track Streaming", Icons.Rounded.Bolt) { s, _ ->
        when {
            !s.preloadNext -> "Loading ahead off"
            s.preloadWifiOnly -> "Loads the next songs early on Wi-Fi"
            else -> "Loads the next songs early"
        }
    },
    SettingsPage("foryou", "Made for you", Icons.Rounded.AutoAwesome) { s, hidden ->
        "Weekly mix ${onOff(s.weeklyMix)}" + when (hidden) {
            0 -> ""
            1 -> " · 1 hidden artist"
            else -> " · $hidden hidden artists"
        }
    },
    SettingsPage("car", "Car mode", Icons.Rounded.DirectionsCar) { s, _ ->
        if (s.carAutoOpen && s.carDevices.isNotEmpty()) "Opens by itself in ${s.carDevices.first()}" else "Big buttons for driving"
    },
    SettingsPage("local", "Local files", Icons.Rounded.Folder) { _, _ ->
        val n = LocalMusic.folders.value.size
        if (n == 0) "Play music files from your phone" else "${LocalMusic.tracks.value.size} songs from $n folder" + if (n == 1) "" else "s"
    },
    SettingsPage("appearance", "Appearance", Icons.Rounded.Contrast) { s, _ -> (if (s.pureOled) "Pure OLED black" else "Default") + (if (s.rippleEffects) "" else " · No wave") },
    SettingsPage("downloads", "Downloads & storage", Icons.Rounded.DownloadForOffline) { s, _ ->
        "Cache ${label(s.cacheMb)}" + (if (s.wifiOnlyDownloads) " · Wi-Fi only" else "") + (if (s.autoDownloadLikes) " · Saves likes" else "")
    },
    SettingsPage("auto", "Android Auto", Icons.Rounded.Navigation) { s, _ ->
        if (s.autoGridHome && s.autoGridPlaylists) "Art-first layout" else "Layout and buttons in the car"
    },
    SettingsPage("privacy", "Privacy & backup", Icons.Rounded.Lock) { s, _ ->
        (if (s.pauseHistory) "History paused" else "History on") + " · Back up or restore"
    }
)

/** Every setting by name, for the search box. */
private val SETTING_INDEX = listOf(
    "High quality audio" to "playback", "Explicit versions" to "playback", "Autoplay" to "playback", "Smart shuffle" to "playback",
    "Resume where you left off" to "playback", "Open the player on lyrics" to "playback", "Equalizer" to "playback",
    "Crossfade" to "sound", "Normalize volume" to "sound", "Skip silence" to "sound",
    "Skip non-music parts (SponsorBlock)" to "sound", "Keep playing during calls" to "sound",
    "Load next songs early" to "streaming", "Only on Wi-Fi (loading ahead)" to "streaming",
    "Weekly mix" to "foryou", "Rebuild weekly mix" to "foryou", "Hold Next to hide an artist" to "foryou", "Hidden artists" to "foryou",
    "Car mode" to "car", "Open car mode by itself (Bluetooth)" to "car",
    "Local files" to "local", "Add a music folder" to "local", "Rescan music folders" to "local",
    "Pure OLED black" to "appearance", "Dark theme" to "appearance",
    "Download on Wi-Fi only" to "downloads", "Download liked songs" to "downloads", "Song cache" to "downloads", "Clear image cache" to "downloads",
    "Android Auto setup" to "auto", "Android Auto layout (grid or list)" to "auto", "Car buttons: like, shuffle, repeat" to "auto",
    "Pause listening history" to "privacy", "Recent searches" to "privacy", "Back up your library" to "privacy", "Restore from backup" to "privacy"
)

@Composable
private fun CategoryRow(icon: ImageVector, title: String, summary: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Sc.TextDim, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Sc.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(2.dp))
            Text(summary, color = Sc.TextDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = Sc.TextFaint)
    }
}

@Composable
private fun DeviceRow(name: String, button: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Bluetooth, null, tint = Sc.TextDim, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Text(name, color = Sc.Text, fontSize = 16.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            button,
            color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(Color.White)
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun About() {
    Spacer(Modifier.height(36.dp))
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SirenMark(size = 26.dp)
            Spacer(Modifier.width(8.dp))
            Text("Siren", color = Sc.Text, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.5).sp)
        }
        Spacer(Modifier.height(6.dp))
        Text("Version ${BuildConfig.VERSION_NAME} • No ads. No account. No tracking.", color = Sc.TextFaint, fontSize = 12.sp)
        Text("Lyrics by LRCLIB • Skips by SponsorBlock", color = Sc.TextFaint, fontSize = 12.sp)
    }
}
