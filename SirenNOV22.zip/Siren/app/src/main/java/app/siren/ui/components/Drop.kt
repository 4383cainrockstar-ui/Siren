package app.siren.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.siren.ui.theme.Sc

/*
 * Siren's mark: a drop landing in water, three flat rings spreading out.
 * Geometry is in a 100-unit box; the mark spans x 7..93, y 37..90 (centered at 50, 63.5).
 */
private val RING_Y = floatArrayOf(55f, 60f, 65f)
private val RING_RX = floatArrayOf(20f, 31.5f, 43f)
private val RING_RY = floatArrayOf(10.5f, 16.5f, 22.5f)
private val RING_W = floatArrayOf(4.6f, 3.8f, 3.0f)
private val RING_A = floatArrayOf(1f, 0.7f, 0.42f)
private const val DOT_Y = 47f
private const val DOT_R = 8f

/**
 * Draws the drop. [dotDrop] lifts the dot (in mark units, 0 = resting), [rings] is how far each
 * ring has spread (0..1, null = fully spread) and [fade] dims everything.
 */
fun DrawScope.drawDrop(
    color: Color,
    dotDrop: Float = 0f,
    dotAlpha: Float = 1f,
    rings: FloatArray? = null,
    ringAlpha: FloatArray? = null,
    showRings: Int = 3
) {
    val u = size.minDimension / 92f
    val cx = size.width / 2f
    val cy = size.height / 2f
    fun x(v: Float) = cx + (v - 50f) * u
    fun y(v: Float) = cy + (v - 63.5f) * u
    for (i in 0 until showRings.coerceIn(0, 3)) {
        val spread = rings?.getOrNull(i) ?: 1f
        if (spread <= 0f) continue
        val s = 0.35f + 0.65f * spread
        val rx = RING_RX[i] * u * s
        val ry = RING_RY[i] * u * s
        val a = RING_A[i] * (ringAlpha?.getOrNull(i) ?: 1f)
        if (a <= 0.01f) continue
        drawOval(
            color.copy(alpha = color.alpha * a),
            topLeft = Offset(x(50f) - rx, y(RING_Y[i]) - ry),
            size = Size(rx * 2, ry * 2),
            style = Stroke(width = RING_W[i] * u)
        )
    }
    if (dotAlpha > 0.01f) {
        drawCircle(color.copy(alpha = color.alpha * dotAlpha), radius = DOT_R * u, center = Offset(x(50f), y(DOT_Y - dotDrop)))
    }
}

/** The Siren mark, still. */
@Composable
fun SirenMark(modifier: Modifier = Modifier, size: Dp = 28.dp, color: Color = Sc.Accent) {
    Canvas(modifier.size(size)) { drawDrop(color) }
}

/**
 * Siren's loading animation: the dot falls, the rings spread out one after another, then it all
 * fades and starts again. One small canvas, nothing else redraws.
 */
@Composable
fun SirenLoader(modifier: Modifier = Modifier, size: Dp = 40.dp, color: Color = Sc.Accent) {
    val t = rememberInfiniteTransition(label = "loader")
    val p by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1250, easing = LinearEasing), RepeatMode.Restart),
        label = "loaderPhase"
    )
    Canvas(modifier.size(size).semantics { contentDescription = "Loading" }) {
        val st = loaderState(p)
        drawDrop(color, st.dotDrop, st.dotAlpha, st.rings, st.ringAlpha)
    }
}

/** Where everything is at phase [p] (0..1) of the loader's loop. */
internal class DropState(val dotDrop: Float, val dotAlpha: Float, val rings: FloatArray, val ringAlpha: FloatArray)

internal fun loaderState(p: Float): DropState {
    // Dot falls in over the first 28%
    val fall = (p / 0.28f).coerceIn(0f, 1f)
    val dotDrop = 30f * (1f - fall * fall)
    val fadeOut = ((p - 0.82f) / 0.18f).coerceIn(0f, 1f)
    val dotAlpha = (fall * 3f).coerceIn(0f, 1f) * (1f - fadeOut)
    val rings = FloatArray(3)
    val alphas = FloatArray(3)
    for (i in 0..2) {
        val start = 0.24f + i * 0.1f
        val q = ((p - start) / 0.38f).coerceIn(0f, 1f)
        rings[i] = 1f - (1f - q) * (1f - q) * (1f - q)
        alphas[i] = (q * 2.5f).coerceIn(0f, 1f) * (1f - fadeOut)
    }
    return DropState(dotDrop, dotAlpha, rings, alphas)
}

/**
 * Pull-to-refresh version: [pull] 0..1 while dragging (the dot comes down and rings fade in as
 * you pull), then the normal loop while it refreshes.
 */
@Composable
fun DropRefreshIndicator(pull: Float, refreshing: Boolean, modifier: Modifier = Modifier, size: Dp = 44.dp, color: Color = Sc.Accent) {
    if (refreshing) {
        SirenLoader(modifier, size, color)
        return
    }
    val f = pull.coerceIn(0f, 1f)
    if (f <= 0.02f) return
    Canvas(modifier.size(size)) {
        val rings = FloatArray(3) { i -> ((f - 0.25f - i * 0.2f) / 0.3f).coerceIn(0f, 1f) }
        drawDrop(color, dotDrop = 30f * (1f - f), dotAlpha = (f * 2f).coerceIn(0f, 1f), rings = rings, ringAlpha = rings)
    }
}
