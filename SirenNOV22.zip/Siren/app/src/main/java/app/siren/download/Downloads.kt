package app.siren.download

import app.siren.data.LocalMusic
import app.siren.data.Explicit
import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaCodec
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.media.MediaExtractor
import android.media.MediaFormat as AndroidMediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.util.UnstableApi
import app.siren.MainActivity
import app.siren.SirenApp
import app.siren.R
import app.siren.core.Music
import app.siren.core.Net
import app.siren.core.Track
import app.siren.data.DownloadRecord
import app.siren.data.Library
import app.siren.data.Settings
import app.siren.player.PlayerController
import app.siren.player.StreamResolver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileDescriptor
import java.io.FileOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue

/** Offline songs: saved as M4A (AAC) into Music/Siren, playable here and in any other player. */
@UnstableApi
object Downloads {
    private val queue = ConcurrentLinkedQueue<Pair<String, Track>>()

    /** Set by "Cancel all" (or the notification's Stop). The worker checks it between songs and mid-download. */
    @Volatile var cancelRequested = false
        private set

    /** Drops everything waiting and stops the song in progress. Saved songs are kept. */
    fun cancelAll(ctx: Context) {
        cancelRequested = true
        queue.clear()
        val live = Library.value.downloads
            .filter { it.status == DownloadRecord.STATUS_QUEUED || it.status == DownloadRecord.STATUS_RUNNING }
            .map { it.id }.toSet()
        if (live.isNotEmpty()) Library.removeDownloads(live)
    }

    fun enqueue(ctx: Context, tracks: List<Track>): Int {
        // One pass over what's already saved, one library update for the lot. (Doing it song by
        // song made "Download all" on a big playlist freeze the app.)
        val existing = Library.value.downloads.associateBy { it.track.videoId }
        val now = System.currentTimeMillis()
        val fresh = tracks.filterNot { LocalMusic.isLocal(it) }.distinctBy { it.videoId }
            .filter { t -> existing[t.videoId]?.let { it.status == DownloadRecord.STATUS_FAILED } ?: true }
            .mapIndexed { i, t -> DownloadRecord(id = UUID.randomUUID().toString(), track = t, createdAt = now - i) }
        val added = fresh.size
        if (added > 0) {
            cancelRequested = false
            Library.addDownloads(fresh)
            fresh.forEach { queue.add(it.id to it.track) }
            ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
        }
        return added
    }

    fun retry(ctx: Context, record: DownloadRecord) {
        Library.removeDownload(record.id)
        enqueue(ctx, listOf(record.track))
    }

    /** Removes the entry and, if asked, the file it saved. */
    fun remove(ctx: Context, record: DownloadRecord, deleteFile: Boolean) {
        queue.removeAll { it.first == record.id }
        if (deleteFile && record.fileUri.isNotBlank()) {
            try {
                val uri = Uri.parse(record.fileUri)
                if (uri.scheme == "content") ctx.contentResolver.delete(uri, null, null)
                else uri.path?.let { File(it).delete() }
            } catch (_: Exception) {
            }
        }
        Library.removeDownload(record.id)
        PlayerController.refreshSourceFor(record.track)
    }

    internal fun next(): Pair<String, Track>? = queue.poll()

    fun pending(): Int = queue.size

    /** At startup anything that was mid-flight when the app died is marked as interrupted. */
    fun markInterrupted() {
        val live = queue.map { it.first }.toHashSet()
        Library.updateDownloads { r ->
            if ((r.status == DownloadRecord.STATUS_RUNNING || r.status == DownloadRecord.STATUS_QUEUED) && r.id !in live)
                r.copy(status = DownloadRecord.STATUS_FAILED, error = "Interrupted. Tap to retry.")
            else r
        }
    }
}

@UnstableApi
class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var worker: Job? = null
    private val nm by lazy { NotificationManagerCompat.from(this) }
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            Downloads.cancelAll(this)
            if (worker?.isActive != true) {
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            return START_NOT_STICKY
        }
        ServiceCompat.startForeground(
            this, NOTIF_ID, progressNotification("Starting download…", 0, true),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        )
        if (worker?.isActive != true) worker = scope.launch { drain() }
        return START_NOT_STICKY
    }

    private fun drain() {
        var done = 0
        var failed = 0
        while (true) {
            if (Downloads.cancelRequested) break
            waitForWifiIfNeeded()
            if (Downloads.cancelRequested) break
            val (id, track) = Downloads.next() ?: break
            if (runJob(id, track)) done++ else failed++
        }
        if (done + failed > 0 && !Downloads.cancelRequested) {
            val text = buildString {
                append(if (done == 1) "1 song saved" else "$done songs saved")
                if (failed > 0) append(", $failed failed")
            }
            nm.notifySafe(NOTIF_DONE, doneNotification(text))
        }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /** "Download on Wi-Fi only": hold the queue while the connection is metered (mobile data). */
    private fun waitForWifiIfNeeded() {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        var notified = false
        while (Settings.current.wifiOnlyDownloads && Downloads.pending() > 0 && isMetered(cm)) {
            if (!notified) {
                notified = true
                nm.notifySafe(NOTIF_ID, progressNotification("Waiting for Wi-Fi (${Downloads.pending()} songs)", 0, true))
                Library.updateQueuedDownloads { it.copy(error = "Waiting for Wi-Fi") }
            }
            Thread.sleep(5_000)
        }
    }

    private fun isMetered(cm: ConnectivityManager): Boolean {
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return true
        return !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    private fun runJob(id: String, track: Track): Boolean {
        if (Library.value.downloads.none { it.id == id }) return false // removed while waiting
        Library.updateDownload(id) { it.copy(status = DownloadRecord.STATUS_RUNNING, progress = 0f, error = "") }
        val tmp = File(File(cacheDir, "dl").apply { mkdirs() }, "$id.part")
        return try {
            val info = Music.streamBlocking(Explicit.playableId(track.videoId, track), fresh = true)
            val audio = StreamResolver.pickM4a(info) ?: StreamResolver.pickAudio(info, true)
                ?: throw IOException("No downloadable audio")
            val total = try {
                audio.itagItem?.contentLength ?: -1L
            } catch (e: Exception) {
                -1L
            }
            val queued = Downloads.pending()
            if (Downloads.cancelRequested) throw IOException("Cancelled")
            var last = 0L
            fetch(audio.content, tmp, total) { got ->
                val now = System.currentTimeMillis()
                if (now - last > 500) {
                    last = now
                    val p = if (total > 0) (got.toFloat() / total).coerceIn(0f, 1f) else 0f
                    Library.updateDownload(id) { it.copy(progress = p, sizeBytes = got) }
                    val title = if (queued > 0) "${track.title} (+$queued more)" else track.title
                    nm.notifySafe(NOTIF_ID, progressNotification(title, (p * 100).toInt(), total <= 0))
                }
            }
            // Removed or cancelled while downloading: don't save a file nobody's tracking
            if (Downloads.cancelRequested || Library.value.downloads.none { it.id == id }) return false
            val m4a = audio.format == org.schabi.newpipe.extractor.MediaFormat.M4A
            val ext = if (m4a) "m4a" else "webm"
            val mime = if (m4a) "audio/mp4" else "audio/webm"
            val name = safeName(listOf(track.artist, track.title).filter { it.isNotBlank() }.joinToString(" - ")) + "." + ext
            val uri = writeOutput(name, mime, track) { fd, path ->
                if (m4a) {
                    try {
                        remux(tmp, fd, path)
                    } catch (e: Exception) {
                        copyRaw(tmp, fd, path)
                    }
                } else copyRaw(tmp, fd, path)
            }
            Library.updateDownload(id) {
                it.copy(status = DownloadRecord.STATUS_DONE, progress = 1f, fileUri = uri.toString(), fileName = name, sizeBytes = tmp.length())
            }
            main.post { PlayerController.refreshSourceFor(track) }
            true
        } catch (e: Exception) {
            if (e.message != "Cancelled") {
                Library.updateDownload(id) { it.copy(status = DownloadRecord.STATUS_FAILED, error = Music.friendlyError(e)) }
            }
            false
        } finally {
            tmp.delete()
        }
    }

    /** Pulls the file in 4 MB ranges the way YouTube's own apps do (big single requests get throttled). */
    private fun fetch(url: String, out: File, expected: Long, onProgress: (Long) -> Unit) {
        val isPlayback = Uri.parse(url).path?.startsWith("/videoplayback") == true
        var pos = 0L
        var rn = 0
        FileOutputStream(out).use { fos ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val end = if (expected > 0) minOf(expected - 1, pos + CHUNK - 1) else pos + CHUNK - 1
                val b = Request.Builder().header("User-Agent", Net.USER_AGENT).header("Accept-Encoding", "identity")
                if (isPlayback) b.url("$url&range=$pos-$end&rn=${rn++}").post(byteArrayOf(0x78, 0).toRequestBody())
                else b.url(url).get()
                Net.client.newCall(b.build()).execute().use { resp ->
                    if (resp.code == 416) return
                    if (!resp.isSuccessful) throw IOException("Server answered HTTP ${resp.code}")
                    val body = resp.body ?: throw IOException("Empty response")
                    var got = 0L
                    body.byteStream().use { input ->
                        while (true) {
                            if (Downloads.cancelRequested) throw IOException("Cancelled")
                            val n = input.read(buf)
                            if (n == -1) break
                            fos.write(buf, 0, n)
                            got += n
                            onProgress(pos + got)
                        }
                    }
                    pos += got
                    if (!isPlayback || got == 0L) return
                    if (expected > 0 && pos >= expected) return
                    if (expected <= 0 && got < CHUNK) return
                }
            }
        }
    }

    private fun writeOutput(name: String, mime: String, track: Track, write: (FileDescriptor?, String?) -> Unit): Uri {
        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/Siren")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
                put(MediaStore.Audio.Media.TITLE, track.title)
                put(MediaStore.Audio.Media.ARTIST, track.artist)
                put(MediaStore.Audio.Media.IS_MUSIC, 1)
            }
            val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Couldn't create the file in Music")
            try {
                resolver.openFileDescriptor(uri, "rw")?.use { pfd -> write(pfd.fileDescriptor, null) }
                    ?: throw IOException("Couldn't open the output file")
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        } else {
            val dir = File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "Siren").apply { mkdirs() }
            var file = File(dir, name)
            var i = 1
            while (file.exists()) {
                file = File(dir, name.substringBeforeLast('.') + " ($i)." + name.substringAfterLast('.'))
                i++
            }
            write(null, file.absolutePath)
            return Uri.fromFile(file)
        }
    }

    /** YouTube's M4A is a streaming-style MP4; remuxing gives a normal file every player seeks in. */
    @SuppressLint("WrongConstant")
    private fun remux(src: File, fd: FileDescriptor?, path: String?) {
        val ex = MediaExtractor()
        val muxer = if (fd != null) MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        else MediaMuxer(path!!, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        try {
            ex.setDataSource(src.absolutePath)
            var track = -1
            for (t in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(t).getString(AndroidMediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    track = t
                    break
                }
            }
            if (track < 0) throw IOException("No audio track")
            ex.selectTrack(track)
            val out = muxer.addTrack(ex.getTrackFormat(track))
            muxer.start()
            val buffer = ByteBuffer.allocate(1024 * 1024)
            val info = MediaCodec.BufferInfo()
            while (true) {
                buffer.clear()
                val size = ex.readSampleData(buffer, 0)
                if (size < 0) break
                info.offset = 0
                info.size = size
                info.presentationTimeUs = ex.sampleTime
                info.flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                muxer.writeSampleData(out, buffer, info)
                ex.advance()
            }
            muxer.stop()
        } finally {
            ex.release()
            try {
                muxer.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun copyRaw(src: File, fd: FileDescriptor?, path: String?) {
        val out = if (fd != null) FileOutputStream(fd) else FileOutputStream(path!!)
        out.use { o ->
            o.channel.truncate(0)
            src.inputStream().use { it.copyTo(o) }
        }
    }

    private fun safeName(title: String): String =
        title.replace(Regex("[\\\\/:*?\"<>|\\n\\r\\t]"), " ").replace(Regex("\\s+"), " ").trim().take(120).ifBlank { "Siren song" }

    private fun openDownloadsIntent(): PendingIntent {
        val i = Intent(this, MainActivity::class.java).setAction(MainActivity.ACTION_OPEN_DOWNLOADS)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(this, 3, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun progressNotification(title: String, percent: Int, indeterminate: Boolean): Notification =
        NotificationCompat.Builder(this, SirenApp.CHANNEL_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(if (indeterminate) "Downloading…" else "$percent%")
            .setProgress(100, percent, indeterminate)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openDownloadsIntent())
            .addAction(0, "Stop", stopIntent())
            .build()

    private fun stopIntent(): PendingIntent {
        val i = Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL)
        return PendingIntent.getService(this, 4, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun doneNotification(text: String): Notification =
        NotificationCompat.Builder(this, SirenApp.CHANNEL_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Downloads finished")
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openDownloadsIntent())
            .build()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val NOTIF_ID = 6150
        private const val NOTIF_DONE = 6151
        const val ACTION_CANCEL = "app.siren.DOWNLOAD_CANCEL"
        private const val CHUNK = 4L * 1024 * 1024
    }
}

@SuppressLint("MissingPermission")
private fun NotificationManagerCompat.notifySafe(id: Int, n: Notification) {
    try {
        if (areNotificationsEnabled()) notify(id, n)
    } catch (_: SecurityException) {
    }
}
