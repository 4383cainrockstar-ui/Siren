package app.siren.data

import android.content.Context
import app.siren.core.ArtistRef
import app.siren.core.CollectionRef
import app.siren.core.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.sample
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

object LibraryJson {
    val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        encodeDefaults = true
        isLenient = true
    }
}

@Serializable
data class Played(
    val track: Track,
    val lastPlayed: Long,
    val plays: Int = 1
)

@Serializable
data class LocalPlaylist(
    val id: String,
    val name: String,
    val tracks: List<Track> = emptyList(),
    val createdAt: Long = 0,
    val updatedAt: Long = 0,
    /** Name of the folder it's filed in (empty = not in a folder). A folder exists while it has playlists. */
    val folder: String = ""
)

@Serializable
data class DownloadRecord(
    val id: String,
    val track: Track,
    val status: String = STATUS_QUEUED,
    val progress: Float = 0f,
    val fileUri: String = "",
    val fileName: String = "",
    val sizeBytes: Long = 0,
    val error: String = "",
    val createdAt: Long = 0
) {
    companion object {
        const val STATUS_QUEUED = "queued"
        const val STATUS_RUNNING = "running"
        const val STATUS_DONE = "done"
        const val STATUS_FAILED = "failed"
    }
}

/**
 * Something you actually opened from Search: a song, artist, album or playlist.
 * Typed text alone is never saved.
 */
@Serializable
data class RecentPick(
    val kind: String,
    val url: String,
    val title: String,
    val subtitle: String = "",
    val thumbnail: String = "",
    val track: Track? = null,
    val isAlbum: Boolean = false,
    val at: Long = 0
) {
    companion object {
        const val SONG = "song"
        const val ARTIST = "artist"
        const val COLLECTION = "collection"

        fun song(t: Track) = RecentPick(SONG, t.url, t.title, t.artist, t.thumbnail, track = t)
        fun artist(a: ArtistRef) = RecentPick(ARTIST, a.url, a.name, "Artist", a.avatar)
        fun collection(c: CollectionRef) = RecentPick(COLLECTION, c.url, c.name, c.author, c.thumbnail, isAlbum = c.isAlbum)
    }
}

/** An artist you hid: they stay out of radio, autoplay, mixes and suggestions. */
@Serializable
data class HiddenArtist(val key: String, val name: String, val at: Long = 0)

@Serializable
data class LibraryData(
    val liked: List<Track> = emptyList(),
    val playlists: List<LocalPlaylist> = emptyList(),
    val saved: List<CollectionRef> = emptyList(),
    val artists: List<ArtistRef> = emptyList(),
    val history: List<Played> = emptyList(),
    /** Old typed-search history (Pulse / Siren 2.0). No longer shown. */
    val searchHistory: List<String> = emptyList(),
    val recentPicks: List<RecentPick> = emptyList(),
    val downloads: List<DownloadRecord> = emptyList(),
    val hiddenArtists: List<HiddenArtist> = emptyList(),
    val version: Int = 1
)

/**
 * Everything Siren remembers lives in one JSON file: small, fast, trivially backed up.
 * State is a StateFlow so the UI recomposes on change; writes are debounced to disk.
 */
@OptIn(FlowPreview::class)
object Library {
    private const val MAX_HISTORY = 2000
    private const val MAX_SEARCH = 40

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var file: File
    private val _data = MutableStateFlow(LibraryData())
    val data: StateFlow<LibraryData> = _data.asStateFlow()
    val value: LibraryData get() = _data.value

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "library.json")
        val tmp = File(ctx.filesDir, "library.json.tmp")
        val source = when {
            file.exists() -> file
            tmp.exists() -> tmp
            else -> null
        }
        if (source != null) {
            _data.value = try {
                LibraryJson.json.decodeFromString(LibraryData.serializer(), source.readText())
            } catch (e: Exception) {
                LibraryData()
            }
        }
        // At most one write a second: downloads update progress constantly and the file can be big
        _data.drop(1).sample(1000).onEach { save(it) }.launchIn(scope)
    }

    @Synchronized
    private fun save(d: LibraryData) {
        try {
            val tmp = File(file.parentFile, "library.json.tmp")
            tmp.writeText(LibraryJson.json.encodeToString(LibraryData.serializer(), d))
            if (!tmp.renameTo(file)) {
                file.writeText(tmp.readText())
                tmp.delete()
            }
        } catch (_: Exception) {
        }
    }

    fun replaceAll(d: LibraryData) {
        _data.value = d
    }

    private fun edit(block: (LibraryData) -> LibraryData) = _data.update(block)

    private fun sameSong(a: Track, b: Track) = a.videoId == b.videoId

    // ---------------- Likes ----------------

    fun isLiked(track: Track): Boolean = value.liked.any { sameSong(it, track) }

    /** Set by the app: called after a song gets liked (used for "Download liked songs"). */
    var onLiked: ((Track) -> Unit)? = null

    /** Same as [onLiked], for a batch liked at once (multi-select). */
    var onLikedMany: ((List<Track>) -> Unit)? = null

    /** Likes every song in [tracks] that isn't liked yet. Returns how many were new. */
    fun likeAll(tracks: List<Track>): Int {
        val have = value.liked.map { it.videoId }.toHashSet()
        val fresh = tracks.filter { have.add(it.videoId) }
        if (fresh.isEmpty()) return 0
        edit { d -> d.copy(liked = fresh + d.liked) }
        onLikedMany?.invoke(fresh)
        return fresh.size
    }

    fun unlikeAll(tracks: List<Track>) {
        val ids = tracks.map { it.videoId }.toHashSet()
        edit { d -> d.copy(liked = d.liked.filterNot { it.videoId in ids }) }
    }

    fun toggleLike(track: Track): Boolean {
        val now = !isLiked(track)
        edit { d ->
            if (now) d.copy(liked = listOf(track) + d.liked)
            else d.copy(liked = d.liked.filterNot { sameSong(it, track) })
        }
        if (now) onLiked?.invoke(track)
        return now
    }

    // ---------------- Local playlists ----------------

    fun createPlaylist(name: String, tracks: List<Track> = emptyList()): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        edit { it.copy(playlists = listOf(LocalPlaylist(id, name.ifBlank { "My playlist" }, tracks.distinctBy { t -> t.videoId }, now, now)) + it.playlists) }
        return id
    }

    fun playlist(id: String): LocalPlaylist? = value.playlists.firstOrNull { it.id == id }

    /**
     * A playlist the app maintains itself (the weekly mix): created once under a fixed id, then
     * its songs are swapped in place. Keeps a name you gave it.
     */
    fun upsertAutoPlaylist(id: String, name: String, tracks: List<Track>) = edit { d ->
        val now = System.currentTimeMillis()
        val list = tracks.distinctBy { it.videoId }
        if (d.playlists.any { it.id == id }) {
            d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(tracks = list, updatedAt = now) else it })
        } else {
            d.copy(playlists = listOf(LocalPlaylist(id, name, list, now, now)) + d.playlists)
        }
    }

    private fun editPlaylist(id: String, block: (LocalPlaylist) -> LocalPlaylist) = edit { d ->
        d.copy(playlists = d.playlists.map { if (it.id == id) block(it).copy(updatedAt = System.currentTimeMillis()) else it })
    }

    // ---- Folders (grouping for playlists in Your Library) ----

    fun folders(): List<String> = value.playlists.map { it.folder }.filter { it.isNotBlank() }.distinct().sortedBy { it.lowercase() }

    /** Files a playlist in a folder (empty name takes it out). Doesn't change its "recent" order. */
    fun setFolder(id: String, folder: String) = edit { d ->
        d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(folder = folder.trim()) else it })
    }

    fun renameFolder(old: String, new: String) = edit { d ->
        val n = new.trim()
        if (n.isBlank()) d else d.copy(playlists = d.playlists.map { if (it.folder == old) it.copy(folder = n) else it })
    }

    /** Takes every playlist out of the folder (the playlists stay). */
    fun ungroupFolder(name: String) = edit { d ->
        d.copy(playlists = d.playlists.map { if (it.folder == name) it.copy(folder = "") else it })
    }

    // ---- Duplicates ----

    private fun dupKey(t: Track): String {
        val strip = Regex("[^\\p{L}\\p{N}]")
        val k = t.title.lowercase().replace(strip, "") + "|" + t.artist.lowercase().replace(strip, "")
        return if (k.length <= 1) t.videoId else k
    }

    fun duplicateCount(id: String): Int {
        val p = playlist(id) ?: return 0
        return p.tracks.size - p.tracks.distinctBy { dupKey(it) }.size
    }

    /** Keeps the first copy of each song (same title and artist). Returns how many were removed. */
    fun removeDuplicates(id: String): Int {
        var removed = 0
        editPlaylist(id) { p ->
            val keep = p.tracks.distinctBy { dupKey(it) }
            removed = p.tracks.size - keep.size
            p.copy(tracks = keep)
        }
        return removed
    }

    fun renamePlaylist(id: String, name: String) = editPlaylist(id) { it.copy(name = name.ifBlank { it.name }) }

    fun deletePlaylist(id: String) = edit { d -> d.copy(playlists = d.playlists.filterNot { it.id == id }) }

    /** Returns how many tracks were actually new to the playlist. */
    fun addToPlaylist(id: String, tracks: List<Track>): Int {
        var added = 0
        editPlaylist(id) { p ->
            val fresh = tracks.filter { t -> p.tracks.none { sameSong(it, t) } }.distinctBy { it.videoId }
            added = fresh.size
            p.copy(tracks = p.tracks + fresh)
        }
        return added
    }

    fun removeFromPlaylist(id: String, track: Track) = editPlaylist(id) { p ->
        p.copy(tracks = p.tracks.filterNot { sameSong(it, track) })
    }

    fun movePlaylistItem(id: String, from: Int, to: Int) = editPlaylist(id) { p ->
        if (from !in p.tracks.indices || to !in p.tracks.indices) p
        else {
            val list = p.tracks.toMutableList()
            val item = list.removeAt(from)
            list.add(to, item)
            p.copy(tracks = list)
        }
    }

    // ---------------- Saved albums / playlists ----------------

    fun isSaved(url: String): Boolean = value.saved.any { it.url == url }

    fun toggleSaved(c: CollectionRef): Boolean {
        val now = !isSaved(c.url)
        edit { d -> if (now) d.copy(saved = listOf(c) + d.saved) else d.copy(saved = d.saved.filterNot { it.url == c.url }) }
        return now
    }

    // ---------------- Artists ----------------

    private fun channelId(url: String) = url.trimEnd('/').substringAfterLast('/')

    fun isFollowing(url: String): Boolean = value.artists.any { channelId(it.url) == channelId(url) }

    fun toggleFollow(a: ArtistRef): Boolean {
        val now = !isFollowing(a.url)
        edit { d ->
            if (now) d.copy(artists = listOf(a) + d.artists)
            else d.copy(artists = d.artists.filterNot { channelId(it.url) == channelId(a.url) })
        }
        return now
    }

    // ---------------- History ----------------

    fun recordPlay(track: Track) {
        if (Settings.current.pauseHistory) return
        val now = System.currentTimeMillis()
        edit { d ->
            val old = d.history.firstOrNull { sameSong(it.track, track) }
            val entry = Played(track, now, (old?.plays ?: 0) + 1)
            d.copy(history = (listOf(entry) + d.history.filterNot { sameSong(it.track, track) }).take(MAX_HISTORY))
        }
    }

    fun removeFromHistory(track: Track) = edit { d -> d.copy(history = d.history.filterNot { sameSong(it.track, track) }) }

    fun clearHistory() = edit { it.copy(history = emptyList()) }

    /** Most played songs from the last [days] days. */
    fun topPlayed(limit: Int = 20, days: Int = 45): List<Track> {
        val since = System.currentTimeMillis() - days * 24L * 3600 * 1000
        return value.history.filter { it.lastPlayed >= since }
            .sortedWith(compareByDescending<Played> { it.plays }.thenByDescending { it.lastPlayed })
            .take(limit).map { it.track }
    }

    /** Artists you play the most, with the track to seed their mix from. */
    fun topArtists(limit: Int = 6): List<Pair<String, Track>> =
        value.history
            .filter { it.track.artist.isNotBlank() }
            .groupBy { it.track.artist.lowercase() }
            .map { (_, list) -> list.sumOf { it.plays } to list.maxByOrNull { it.plays }!!.track }
            .sortedByDescending { it.first }
            .take(limit)
            .map { it.second.artist to it.second }

    // ---------------- Recent searches (what you opened, not what you typed) ----------------

    fun addPick(p: RecentPick) {
        if (!Settings.current.saveSearchHistory || p.url.isBlank()) return
        val stamped = p.copy(at = System.currentTimeMillis())
        edit { d -> d.copy(recentPicks = (listOf(stamped) + d.recentPicks.filterNot { it.url == p.url }).take(MAX_SEARCH)) }
    }

    fun removePick(url: String) = edit { d -> d.copy(recentPicks = d.recentPicks.filterNot { it.url == url }) }

    fun clearSearches() = edit { it.copy(searchHistory = emptyList(), recentPicks = emptyList()) }

    // ---------------- Downloads ----------------

    // Lookup by video id, rebuilt only when the downloads list changes (every row and every queued
    // song asks "is this downloaded?")
    @Volatile
    private var dlIndex: Pair<List<DownloadRecord>, Map<String, DownloadRecord>>? = null

    private fun downloadMap(): Map<String, DownloadRecord> {
        val list = value.downloads
        dlIndex?.let { (l, m) -> if (l === list) return m }
        val m = HashMap<String, DownloadRecord>(list.size * 2)
        for (r in list) m.putIfAbsent(r.track.videoId, r)
        dlIndex = list to m
        return m
    }

    fun download(track: Track): DownloadRecord? = downloadMap()[track.videoId]

    fun downloadedUri(track: Track): String? =
        download(track)?.takeIf { it.status == DownloadRecord.STATUS_DONE && it.fileUri.isNotBlank() }?.fileUri

    /** Many at once (Download all): one library update instead of one per song. */
    fun addDownloads(records: List<DownloadRecord>) {
        if (records.isEmpty()) return
        val ids = records.map { it.track.videoId }.toHashSet()
        edit { d -> d.copy(downloads = records + d.downloads.filterNot { it.track.videoId in ids }) }
    }

    fun upsertDownload(r: DownloadRecord) = edit { d ->
        d.copy(downloads = listOf(r) + d.downloads.filterNot { it.id == r.id || sameSong(it.track, r.track) })
    }

    fun updateDownload(id: String, block: (DownloadRecord) -> DownloadRecord) = edit { d ->
        d.copy(downloads = d.downloads.map { if (it.id == id) block(it) else it })
    }

    fun updateQueuedDownloads(block: (DownloadRecord) -> DownloadRecord) = edit { d ->
        d.copy(downloads = d.downloads.map { if (it.status == DownloadRecord.STATUS_QUEUED) block(it) else it })
    }

    /** Rewrites every download record in one go. */
    fun updateDownloads(block: (DownloadRecord) -> DownloadRecord) = edit { d -> d.copy(downloads = d.downloads.map(block)) }

    fun removeDownload(id: String) = edit { d -> d.copy(downloads = d.downloads.filterNot { it.id == id }) }

    fun removeDownloads(ids: Set<String>) = edit { d -> d.copy(downloads = d.downloads.filterNot { it.id in ids }) }

    // ---------------- Hidden artists ----------------

    /** Same rule radio uses to tell artists apart ("Drake, 21 Savage" -> "drake"). */
    private fun hideKey(artist: String): String = app.siren.player.Stations.artistKey(artist)

    fun hiddenKeys(): Set<String> = value.hiddenArtists.map { it.key }.toHashSet()

    fun isHidden(t: Track): Boolean {
        val h = value.hiddenArtists
        if (h.isEmpty()) return false
        val k = hideKey(t.artist)
        return k.isNotEmpty() && h.any { it.key == k }
    }

    fun isHiddenName(artist: String): Boolean {
        val k = hideKey(artist)
        return k.isNotEmpty() && value.hiddenArtists.any { it.key == k }
    }

    /** Hides [artist]. Returns its key (for undo), or "" if there's no artist to hide. */
    fun hideArtist(artist: String): String {
        val k = hideKey(artist)
        if (k.isEmpty()) return ""
        val name = app.siren.core.cleanArtist(artist).split(",", " & ", " feat", " ft.").first().trim().ifBlank { artist }
        edit { d ->
            if (d.hiddenArtists.any { it.key == k }) d
            else d.copy(hiddenArtists = listOf(HiddenArtist(k, name, System.currentTimeMillis())) + d.hiddenArtists)
        }
        return k
    }

    fun unhideArtist(key: String) = edit { d -> d.copy(hiddenArtists = d.hiddenArtists.filterNot { it.key == key }) }
}

/** Drops songs by artists you've hidden. */
fun List<Track>.withoutHidden(): List<Track> =
    if (Library.value.hiddenArtists.isEmpty()) this else filterNot { Library.isHidden(it) }
