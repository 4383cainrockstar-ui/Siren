package app.siren.player

import app.siren.data.LocalMusic
import app.siren.data.Explicit
import app.siren.BuildConfig
import android.net.Uri
import android.os.Bundle
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService.LibraryParams
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaSession
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import app.siren.core.Entry
import app.siren.core.Music
import app.siren.core.Track
import app.siren.core.hiRes
import app.siren.core.watchUrl
import app.siren.data.AppSettings
import app.siren.data.DownloadRecord
import app.siren.data.Library
import app.siren.data.withoutHidden
import app.siren.data.Settings
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap

/**
 * What Android Auto (and other media browsers) see: a library to browse and search, voice
 * "play X on Siren", resume-on-connect, and a Like button next to the player controls.
 *
 * Media ids:
 *   root, home, liked, playlists, downloads        browsable folders
 *   pl:<id>  col:<encoded url>                     a local playlist / a saved album or playlist
 *   mix:<videoId>                                  an artist mix (plays as a radio)
 *   <parent>|<videoId>                             a song inside a list, so the whole list queues up
 */
@UnstableApi
class AutoLibrary(private val scope: CoroutineScope) : MediaLibrarySession.Callback {

    private val searches = ConcurrentHashMap<String, List<Track>>()
    private val collections = ConcurrentHashMap<String, Pair<String, List<Track>>>()

    // -----------------------------------------------------------------------------------------
    // Connection: commands + the Like button
    // -----------------------------------------------------------------------------------------

    override fun onConnect(session: MediaSession, controller: MediaSession.ControllerInfo): MediaSession.ConnectionResult {
        val sessionCommands = MediaSession.ConnectionResult.DEFAULT_SESSION_AND_LIBRARY_COMMANDS.buildUpon()
            .add(LIKE)
            .add(SHUFFLE)
            .add(REPEAT)
            .build()
        // No "10 seconds back / forward": car screens show those instead of skip buttons
        val playerCommands = MediaSession.ConnectionResult.DEFAULT_PLAYER_COMMANDS.buildUpon()
            .remove(Player.COMMAND_SEEK_BACK)
            .remove(Player.COMMAND_SEEK_FORWARD)
            .build()
        return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
            .setAvailableSessionCommands(sessionCommands)
            .setAvailablePlayerCommands(playerCommands)
            .build()
    }

    override fun onCustomCommand(
        session: MediaSession,
        controller: MediaSession.ControllerInfo,
        customCommand: SessionCommand,
        args: Bundle
    ): ListenableFuture<SessionResult> {
        when (customCommand.customAction) {
            ACTION_LIKE -> PlayerController.current.value?.let { Library.toggleLike(it) }
            ACTION_SHUFFLE -> PlayerController.cycleShuffle()
            ACTION_REPEAT -> PlayerController.cycleRepeat()
            else -> return super.onCustomCommand(session, controller, customCommand, args)
        }
        return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
    }

    // -----------------------------------------------------------------------------------------
    // Browsing
    // -----------------------------------------------------------------------------------------

    override fun onGetLibraryRoot(
        session: MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        params: LibraryParams?
    ): ListenableFuture<LibraryResult<MediaItem>> {
        val extras = Bundle().apply {
            putBoolean(CONTENT_STYLE_SUPPORTED, true)
            putInt(CONTENT_STYLE_BROWSABLE, STYLE_GRID)
            putInt(CONTENT_STYLE_PLAYABLE, STYLE_LIST)
            putBoolean(SEARCH_SUPPORTED, true)
        }
        val root = folder(ROOT, "Siren")
        return Futures.immediateFuture(LibraryResult.ofItem(root, LibraryParams.Builder().setExtras(extras).build()))
    }

    override fun onGetItem(
        session: MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        mediaId: String
    ): ListenableFuture<LibraryResult<MediaItem>> {
        val song = songFor(mediaId)
        val item = when {
            song != null -> playable(mediaId, song)
            mediaId == ROOT -> folder(ROOT, "Siren")
            else -> null
        }
        return Futures.immediateFuture(
            if (item != null) LibraryResult.ofItem(item, null) else LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE)
        )
    }

    override fun onGetChildren(
        session: MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        parentId: String,
        page: Int,
        pageSize: Int,
        params: LibraryParams?
    ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> = future {
        val lib = Library.value
        val st = Settings.current
        val items: List<MediaItem> = when {
            // The tabs along the top. Each one carries its own list / grid choice from Settings.
            parentId == ROOT -> listOf(
                folder(HOME, "Home", playableGrid = st.autoGridHome, browsableGrid = st.autoGridHome, artUri = tabIcon("home")),
                folder(LIKED, "Liked", playableGrid = st.autoGridLiked, artUri = tabIcon("liked")),
                folder(PLAYLISTS, "Playlists", browsableGrid = st.autoGridPlaylists, artUri = tabIcon("playlists")),
                folder(DOWNLOADS, "Downloads", playableGrid = st.autoGridDownloads, artUri = tabIcon("downloads"))
            )
            parentId == HOME -> homeItems(st)
            parentId == GENRES -> genreItems()
            // Long lists open short: Shuffle all, the newest songs, By artist, then pages
            parentId == LIKED || parentId == DOWNLOADS || parentId == RECENT || parentId == DEVICE ||
                parentId.startsWith("pl:") || parentId.startsWith("col:") -> listing(parentId, tracksFor(parentId))
            parentId.startsWith("byartist^") -> {
                val base = parentId.removePrefix("byartist^")
                tracksFor(base).groupBy { Stations.artistKey(it.artist) }
                    .filterKeys { it.isNotBlank() }
                    .entries.sortedByDescending { it.value.size }
                    .take(40)
                    .map { (key, list) ->
                        folder(
                            "artist^$base^" + Uri.encode(key), list.first().artist.ifBlank { key },
                            "${list.size} song" + if (list.size == 1) "" else "s", list.first().thumbnail,
                            playableGrid = false
                        )
                    }
            }
            parentId.startsWith("chunk^") -> {
                val (_, base, n) = parentId.split("^", limit = 3)
                val from = (n.toIntOrNull() ?: 1) * PAGE
                tracksFor(base).drop(from).take(PAGE).map { playable("$base|${it.videoId}", it) }
            }
            parentId == PLAYLISTS -> {
                val local = lib.playlists.map { p ->
                    folder("pl:${p.id}", p.name, "${p.tracks.size} songs", p.tracks.firstOrNull()?.thumbnail ?: "", playableGrid = st.autoGridSongs)
                }
                val saved = lib.saved.map { c ->
                    folder("col:" + Uri.encode(c.url), c.name, c.author.ifBlank { if (c.isAlbum) "Album" else "Playlist" }, c.thumbnail, playableGrid = st.autoGridSongs)
                }
                val device = LocalMusic.tracks.value.takeIf { it.isNotEmpty() }?.let { files ->
                    listOf(folder(DEVICE, "On this device", "${files.size} songs", files.firstOrNull { it.thumbnail.isNotBlank() }?.thumbnail ?: "", playableGrid = st.autoGridSongs))
                } ?: emptyList()
                device + local + saved
            }
            else -> tracksFor(parentId).take(300).map { playable("$parentId|${it.videoId}", it) }
        }
        val from = (page * pageSize).coerceAtMost(items.size)
        val to = (from + pageSize).coerceAtMost(items.size)
        LibraryResult.ofItemList(items.subList(from, to), params)
    }

    // -----------------------------------------------------------------------------------------
    // Search (typed in the car, or "Hey Google, search … on Siren")
    // -----------------------------------------------------------------------------------------

    override fun onSearch(
        session: MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        query: String,
        params: LibraryParams?
    ): ListenableFuture<LibraryResult<Void>> {
        scope.launch {
            val found = searchSongs(query)
            session.notifySearchResultChanged(browser, query, found.size, params)
        }
        return Futures.immediateFuture(LibraryResult.ofVoid())
    }

    override fun onGetSearchResult(
        session: MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        query: String,
        page: Int,
        pageSize: Int,
        params: LibraryParams?
    ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> = future {
        val found = searchSongs(query)
        val parent = SEARCH + Uri.encode(query)
        val items = found.map { playable("$parent|${it.videoId}", it) }
        val from = (page * pageSize).coerceAtMost(items.size)
        val to = (from + pageSize).coerceAtMost(items.size)
        LibraryResult.ofItemList(items.subList(from, to), params)
    }

    // -----------------------------------------------------------------------------------------
    // Playing something picked in the car / asked for by voice
    // -----------------------------------------------------------------------------------------

    override fun onSetMediaItems(
        mediaSession: MediaSession,
        controller: MediaSession.ControllerInfo,
        mediaItems: List<MediaItem>,
        startIndex: Int,
        startPositionMs: Long
    ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> = future {
        val first = mediaItems.firstOrNull()
        val id = first?.mediaId.orEmpty()
        val voice = first?.requestMetadata?.searchQuery
        when {
            // "Play …" by voice: a song, an artist, a genre, a playlist, "my liked songs", a radio
            mediaItems.size == 1 && (id.isBlank() || id == MediaItem.DEFAULT_MEDIA_ID) && voice != null ->
                voiceQueue(voice, first.requestMetadata.extras)
            // Home: Today's vibe / Tracks we think you'd like
            mediaItems.size == 1 && id.startsWith("feed:") -> {
                val kind = id.removePrefix("feed:")
                val f = Discover.cached(24L * 3600 * 1000) ?: Discover.feed()
                val list = (if (kind == "vibe") f.vibe else f.forYou).withoutHidden()
                PlayerController.adoptExternalQueue(
                    if (kind == "vibe") "Today's vibe" else "Tracks we think you'd like",
                    radio = true, seed = list.lastOrNull()
                )
                MediaSession.MediaItemsWithStartPosition(list.map { PlayerController.mediaItemFor(it) }, 0, 0)
            }
            // A genre or mood station
            mediaItems.size == 1 && id.startsWith("genre:") ->
                stationQueue(Station.genre(Uri.decode(id.removePrefix("genre:"))))
            // Shuffle everything in a list
            mediaItems.size == 1 && id.startsWith("shuf:") -> {
                val base = id.removePrefix("shuf:")
                // A real shuffle (shuffle button on, new order every time), not a pre-mixed list
                val (list, start) = PlayerController.prepareShuffledQueue(tracksFor(base))
                PlayerController.adoptExternalQueue(titleFor(base), radio = false, seed = list.getOrNull(start))
                MediaSession.MediaItemsWithStartPosition(list.map { PlayerController.mediaItemFor(it) }, start, 0)
            }
            // A daily / artist mix: a station on that artist
            mediaItems.size == 1 && id.startsWith("mix:") -> {
                val vid = id.removePrefix("mix:")
                val seed = knownTrack(vid) ?: Music.track(watchUrl(vid))
                if (seed.artistUrl.isNotBlank()) stationQueue(Station.artist(seed.artist, seed.artistUrl, seed.thumbnail))
                else radioQueue(seed, "${seed.artist.ifBlank { seed.title }} Mix")
            }
            // A song in a list: queue the whole list from that song
            mediaItems.size == 1 && id.contains('|') -> {
                val parent = id.substringBeforeLast('|')
                val vid = id.substringAfterLast('|')
                val list = tracksFor(parent).ifEmpty { listOfNotNull(knownTrack(vid)) }
                val at = list.indexOfFirst { it.videoId == vid }.coerceAtLeast(0)
                PlayerController.adoptExternalQueue(titleFor(parent), radio = parent.startsWith(SEARCH), seed = list.getOrNull(at))
                MediaSession.MediaItemsWithStartPosition(list.map { PlayerController.mediaItemFor(it) }, at, 0)
            }
            else -> {
                val tracks = mediaItems.mapNotNull { songFor(it.mediaId) }
                PlayerController.adoptExternalQueue("", radio = false)
                MediaSession.MediaItemsWithStartPosition(
                    tracks.map { PlayerController.mediaItemFor(it) },
                    startIndex.coerceIn(0, (tracks.size - 1).coerceAtLeast(0)),
                    startPositionMs
                )
            }
        }
    }

    override fun onAddMediaItems(
        mediaSession: MediaSession,
        controller: MediaSession.ControllerInfo,
        mediaItems: List<MediaItem>
    ): ListenableFuture<List<MediaItem>> {
        val items = mediaItems.mapNotNull { m ->
            songFor(m.mediaId)?.let { PlayerController.mediaItemFor(it) }
                ?: m.takeIf { it.localConfiguration != null }
        }
        return Futures.immediateFuture(items)
    }

    /** Car started / headphones connected and the system asks to resume. */
    override fun onPlaybackResumption(
        mediaSession: MediaSession,
        controller: MediaSession.ControllerInfo
    ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
        val (items, index, pos) = PlayerController.snapshot()
        if (items.isEmpty()) return Futures.immediateFailedFuture(UnsupportedOperationException("Nothing to resume"))
        return Futures.immediateFuture(MediaSession.MediaItemsWithStartPosition(items, index, pos))
    }

    // -----------------------------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------------------------

    /** Home: Today's vibe, tracks we think you'd like, daily mixes, genres, recently played. */
    private suspend fun homeItems(st: AppSettings): List<MediaItem> {
        val lib = Library.value
        val feed = Discover.cached() ?: run {
            // Built in the background so a slow lookup never blocks the car screen; shows up on the next open
            val job = scope.async { Discover.feed() }
            withTimeoutOrNull(8000) { job.await() }
        }
        val out = ArrayList<MediaItem>()
        // Made for you: Today's vibe, picks, the weekly mix (all with covers Siren draws)
        val made = "Made for you"
        if (feed != null && feed.vibe.isNotEmpty()) {
            val bucket = when (java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) {
                in 5..11 -> 0
                in 12..16 -> 1
                in 17..21 -> 2
                else -> 3
            }
            out += collection(
                "feed:vibe", "Today's vibe", feed.vibeTitle, "",
                artUri = ArtworkProvider.madeUri("vibe", feed.vibeTitle.ifBlank { "Today's vibe" }, seed = bucket), group = made
            )
        }
        if (feed != null && feed.forYou.isNotEmpty()) {
            out += collection(
                "feed:foryou", "Tracks we think you'd like", "New songs picked for you", "",
                artUri = ArtworkProvider.madeUri("foryou", "We think you'd like"), group = made
            )
        }
        Library.playlist(WeeklyMix.ID)?.takeIf { it.tracks.isNotEmpty() }?.let { w ->
            out += folder(
                "pl:${w.id}", w.name, "${w.tracks.size} songs · new every Monday", "",
                playableGrid = st.autoGridSongs, artUri = ArtworkProvider.madeUri("weekly", "Weekly mix"), group = made
            )
        }
        // Your mixes: each Daily Mix on its artist's photo with a MIX label
        val mixesGroup = "Your mixes"
        val mixes = feed?.mixes.orEmpty()
        if (mixes.isNotEmpty()) {
            mixes.forEach { m ->
                out += collection(
                    "mix:${m.anchorTrack.videoId}", "Daily Mix ${m.number}",
                    m.names.take(3).joinToString(", "), "",
                    artUri = ArtworkProvider.madeUri("mix", m.anchor, "MIX ${m.number}", photo = hiRes(m.image, 544)),
                    group = mixesGroup
                )
            }
        } else {
            Library.topArtists(6).forEachIndexed { i, (artist, seed) ->
                out += collection(
                    "mix:${seed.videoId}", "$artist Mix", "$artist and more", "",
                    artUri = ArtworkProvider.madeUri("mix", artist, "MIX ${i + 1}", photo = hiRes(seed.thumbnail, 544)),
                    group = mixesGroup
                )
            }
        }
        // Browse
        val browse = "Browse"
        out += folder(
            GENRES, "Genres & moods", "Hip-hop, rock, chill and more", "", playableGrid = true,
            artUri = ArtworkProvider.madeUri("genre", "Genres & moods", seed = 3), group = browse
        )
        if (lib.history.isNotEmpty()) {
            out += folder(RECENT, "Recently played", "", lib.history.first().track.thumbnail, playableGrid = st.autoGridSongs, group = browse)
        }
        return out
    }

    private fun genreItems(): List<MediaItem> {
        val lib = Library.value
        val thumbs = (lib.liked.map { it.thumbnail } + lib.history.map { it.track.thumbnail }).filter { it.isNotBlank() }
        return GENRE_LIST.mapIndexed { i, (title, q) ->
            collection("genre:" + Uri.encode(q), title, "Radio", thumbs.getOrNull(i * 3 % thumbs.size.coerceAtLeast(1)).orEmpty(),
                artUri = ArtworkProvider.madeUri("genre", title, seed = i))
        }
    }

    /**
     * A list that stays short on a car screen: Shuffle all and the first songs up top, then
     * By artist and pages of 25 for the rest.
     */
    private fun listing(parent: String, tracks: List<Track>): List<MediaItem> {
        if (tracks.size <= PAGE + 10) return tracks.take(300).map { playable("$parent|${it.videoId}", it) }
        val out = ArrayList<MediaItem>()
        out += collection("shuf:$parent", "Shuffle all", "${tracks.size} songs", "", artUri = ArtworkProvider.madeUri("shuffle", "Shuffle all"))
        out += folder("byartist^$parent", "By artist", "Jump straight to an artist", tracks.first().thumbnail, playableGrid = false, browsableGrid = false)
        out += tracks.take(PAGE).map { playable("$parent|${it.videoId}", it) }
        var n = 1
        while (n * PAGE < tracks.size && n <= 8) {
            val from = n * PAGE
            val to = minOf(from + PAGE, tracks.size)
            out += folder("chunk^$parent^$n", "Songs ${from + 1}–$to", "", tracks[from].thumbnail, playableGrid = false)
            n++
        }
        return out
    }

    private val genreWords = GENRE_LIST.flatMap { listOf(it.first.lowercase(), it.second.lowercase()) }.toSet()

    private suspend fun stationQueue(st: Station): MediaSession.MediaItemsWithStartPosition {
        val (next, list) = try {
            Stations.batch(st, emptyList(), emptySet())
        } catch (e: Exception) {
            st to emptyList()
        }
        PlayerController.adoptExternalQueue(st.title, radio = true, seed = list.firstOrNull(), station = next)
        return MediaSession.MediaItemsWithStartPosition(list.map { PlayerController.mediaItemFor(it) }, 0, 0)
    }

    private suspend fun voiceQueue(voice: String, ex: Bundle?): MediaSession.MediaItemsWithStartPosition {
        val q = voice.trim()
        val focus = ex?.getString("android.intent.extra.focus").orEmpty()
        val artistX = ex?.getString("android.intent.extra.artist").orEmpty()
        val playlistX = ex?.getString("android.intent.extra.playlist").orEmpty()
        val lib = Library.value
        val low = q.lowercase().removePrefix("my ").removeSuffix(" playlist").removeSuffix(" songs").trim()
        val isArtist = focus.contains("artist", ignoreCase = true) && artistX.isNotBlank()

        fun shuffledQueue(name: String, list: List<Track>): MediaSession.MediaItemsWithStartPosition {
            val (l, start) = PlayerController.prepareShuffledQueue(list)
            PlayerController.adoptExternalQueue(name, radio = false, seed = l.getOrNull(start))
            return MediaSession.MediaItemsWithStartPosition(l.map { PlayerController.mediaItemFor(it) }, start, 0)
        }

        val likedWords = setOf("liked", "liked songs", "favorites", "favourites", "likes", "something i like", "something", "anything", "music")
        return when {
            q.isEmpty() && !isArtist -> {
                val pool = lib.liked.ifEmpty { lib.history.map { it.track } }
                if (pool.isEmpty()) MediaSession.MediaItemsWithStartPosition(emptyList(), 0, 0) else shuffledQueue("Liked songs", pool)
            }
            Regex("(?i)\\b(radio|station)\\b").containsMatchIn(q) -> stationQueue(Stations.resolve(q))
            isArtist -> stationQueue(Stations.resolve(artistX))
            low in likedWords && lib.liked.isNotEmpty() -> shuffledQueue("Liked songs", lib.liked)
            low in setOf("local", "local files", "local music", "on this device", "my files", "downloaded music") &&
                LocalMusic.tracks.value.isNotEmpty() -> shuffledQueue("On this device", LocalMusic.tracks.value)
            else -> {
                val pl = lib.playlists.firstOrNull {
                    it.tracks.isNotEmpty() && (it.name.equals(playlistX.ifBlank { low }, ignoreCase = true) || it.name.equals(low, ignoreCase = true))
                }
                when {
                    pl != null -> shuffledQueue(pl.name, pl.tracks)
                    low in genreWords -> stationQueue(Station.genre(GENRE_LIST.firstOrNull { it.first.lowercase() == low || it.second == low }?.second ?: low))
                    else -> {
                        val seed = searchSongs(q).firstOrNull()
                        when {
                            seed == null -> MediaSession.MediaItemsWithStartPosition(emptyList(), 0, 0)
                            // They said an artist's name: that's a station on the artist, not one song's radio
                            Stations.artistKey(seed.artist) == low -> stationQueue(Stations.resolve(q))
                            else -> radioQueue(seed, "${seed.title} radio")
                        }
                    }
                }
            }
        }
    }

    private suspend fun radioQueue(seed: Track, source: String): MediaSession.MediaItemsWithStartPosition {
        // Same station engine as the app: related artists, the seed artist only now and then
        val more = try {
            Stations.batch(Station.song(seed), listOf(seed), setOf(seed.videoId)).second
        } catch (e: Exception) {
            emptyList()
        }
        PlayerController.adoptExternalQueue(source, radio = true, seed = seed)
        return MediaSession.MediaItemsWithStartPosition((listOf(seed) + more).map { PlayerController.mediaItemFor(it) }, 0, 0)
    }

    private suspend fun searchSongs(query: String): List<Track> {
        searches[query]?.let { return it }
        val found = try {
            Music.search(query, Music.SONGS).items.filterIsInstance<Entry.Song>().map { it.track }.take(30)
        } catch (e: Exception) {
            emptyList()
        }
        if (found.isNotEmpty()) searches[query] = found
        return found
    }

    /** Songs inside a folder id. Saved albums / playlists and searches get fetched (and cached). */
    private suspend fun tracksFor(parent: String): List<Track> {
        val lib = Library.value
        return when {
            parent == HOME || parent == RECENT -> lib.history.map { it.track }
            parent == LIKED -> lib.liked
            parent == DEVICE -> LocalMusic.tracks.value
            parent.startsWith("artist^") -> {
                val (_, base, key) = parent.split("^", limit = 3)
                val k = Uri.decode(key)
                tracksFor(base).filter { Stations.artistKey(it.artist) == k }
            }
            parent == DOWNLOADS -> lib.downloads.filter { it.status == DownloadRecord.STATUS_DONE }.map { it.track }
            parent.startsWith("pl:") -> lib.playlists.firstOrNull { it.id == parent.removePrefix("pl:") }?.tracks ?: emptyList()
            parent.startsWith("col:") -> {
                val url = Uri.decode(parent.removePrefix("col:"))
                collections[url]?.second ?: try {
                    val (h, list) = Music.allTracks(url, cap = 300)
                    collections[url] = h.ref.name to list
                    list
                } catch (e: Exception) {
                    emptyList()
                }
            }
            parent.startsWith(SEARCH) -> searchSongs(Uri.decode(parent.removePrefix(SEARCH)))
            else -> emptyList()
        }
    }

    private fun titleFor(parent: String): String {
        val lib = Library.value
        return when {
            parent == HOME || parent == RECENT -> "Recently played"
            parent.startsWith("artist^") -> {
                val k = Uri.decode(parent.split("^", limit = 3).last())
                Library.value.history.firstOrNull { Stations.artistKey(it.track.artist) == k }?.track?.artist ?: k
            }
            parent == LIKED -> "Liked songs"
            parent == DEVICE -> "On this device"
            parent == DOWNLOADS -> "Downloads"
            parent.startsWith("pl:") -> lib.playlists.firstOrNull { it.id == parent.removePrefix("pl:") }?.name ?: ""
            parent.startsWith("col:") -> {
                val url = Uri.decode(parent.removePrefix("col:"))
                collections[url]?.first ?: lib.saved.firstOrNull { it.url == url }?.name ?: ""
            }
            parent.startsWith(SEARCH) -> "Search: " + Uri.decode(parent.removePrefix(SEARCH))
            else -> ""
        }
    }

    /** Any song Siren already knows about, without hitting the network. */
    private fun knownTrack(videoId: String): Track? {
        val lib = Library.value
        return lib.liked.firstOrNull { it.videoId == videoId }
            ?: lib.history.firstOrNull { it.track.videoId == videoId }?.track
            ?: lib.playlists.asSequence().flatMap { it.tracks.asSequence() }.firstOrNull { it.videoId == videoId }
            ?: lib.downloads.firstOrNull { it.track.videoId == videoId }?.track
            ?: searches.values.asSequence().flatten().firstOrNull { it.videoId == videoId }
            ?: collections.values.asSequence().flatMap { it.second.asSequence() }.firstOrNull { it.videoId == videoId }
    }

    private fun songFor(mediaId: String): Track? {
        if (!mediaId.contains('|')) return null
        return knownTrack(mediaId.substringAfterLast('|'))
    }

    /**
     * A browsable folder. [playableGrid] / [browsableGrid] tell Android Auto how to lay out what's
     * inside it: big cover-art tiles (grid) or rows (list). Null keeps the app-wide default.
     */
    private fun folder(
        id: String,
        title: String,
        subtitle: String = "",
        art: String = "",
        playableGrid: Boolean? = null,
        browsableGrid: Boolean? = null,
        artUri: Uri? = null,
        group: String? = null
    ): MediaItem {
        val style = Bundle().apply {
            if (playableGrid != null) putInt(CONTENT_STYLE_PLAYABLE, if (playableGrid) STYLE_GRID else STYLE_LIST)
            if (browsableGrid != null) putInt(CONTENT_STYLE_BROWSABLE, if (browsableGrid) STYLE_GRID else STYLE_LIST)
            if (group != null) putString(GROUP_TITLE, group)
        }
        val md = MediaMetadata.Builder()
            .setTitle(title)
            .setSubtitle(subtitle.ifBlank { null })
            .setIsBrowsable(true)
            .setIsPlayable(false)
            .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)
            .apply { if (!style.isEmpty) setExtras(style) }
            .apply { (artUri ?: ArtworkProvider.uriFor(hiRes(art, 300)))?.let { setArtworkUri(it) } }
            .build()
        return MediaItem.Builder().setMediaId(id).setMediaMetadata(md).build()
    }

    /** Icon for a tab along the top of Siren in the car. */
    private fun tabIcon(name: String): Uri = Uri.parse("android.resource://${BuildConfig.APPLICATION_ID}/drawable/ic_tab_$name")

    private fun playable(id: String, t: Track): MediaItem {
        // Badges: the download icon on saved songs, the E on explicit ones
        val badges = Bundle().apply {
            if (Library.downloadedUri(t) != null) putLong(DOWNLOAD_STATUS, STATUS_DOWNLOADED)
            if (Explicit.isExplicit(t.videoId)) putLong(IS_EXPLICIT, 1L)
        }
        val md = MediaMetadata.Builder()
            .setTitle(t.title)
            .setDisplayTitle(t.title)
            .setArtist(t.artist.ifBlank { null })
            .setAlbumArtist(t.artist.ifBlank { null })
            .setSubtitle(t.artist.ifBlank { null })
            .setIsBrowsable(false)
            .setIsPlayable(true)
            .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
            .apply { if (!badges.isEmpty) setExtras(badges) }
            .apply { ArtworkProvider.uriFor(hiRes(t.thumbnail, 300))?.let { setArtworkUri(it) } }
            .build()
        return MediaItem.Builder().setMediaId(id).setMediaMetadata(md).build()
    }

    private fun mixItem(artist: String, seed: Track): MediaItem =
        collection("mix:${seed.videoId}", "$artist Mix", "$artist and more", seed.thumbnail)

    /** Something you tap to play as a whole (a mix, a station, a vibe), shown as a tile. */
    private fun collection(id: String, title: String, subtitle: String, art: String, artUri: Uri? = null, group: String? = null): MediaItem {
        val md = MediaMetadata.Builder()
            .setTitle(title)
            .setSubtitle(subtitle.ifBlank { null })
            .setIsBrowsable(false)
            .setIsPlayable(true)
            .setMediaType(MediaMetadata.MEDIA_TYPE_PLAYLIST)
            .apply { if (group != null) setExtras(Bundle().apply { putString(GROUP_TITLE, group) }) }
            .apply { (artUri ?: ArtworkProvider.uriFor(hiRes(art, 300)))?.let { setArtworkUri(it) } }
            .build()
        return MediaItem.Builder().setMediaId(id).setMediaMetadata(md).build()
    }

    private fun <T : Any> future(block: suspend () -> T): ListenableFuture<T> {
        val f = SettableFuture.create<T>()
        scope.launch {
            try {
                f.set(block())
            } catch (e: CancellationException) {
                f.cancel(false)
            } catch (e: Throwable) {
                f.setException(e)
            }
        }
        return f
    }

    companion object {
        const val ROOT = "root"
        const val HOME = "home"
        const val LIKED = "liked"
        const val PLAYLISTS = "playlists"
        const val DOWNLOADS = "downloads"
        const val DEVICE = "device"
        const val RECENT = "recent"
        const val GENRES = "genres"
        const val SEARCH = "search:"
        private const val PAGE = 25

        /** Genre and mood stations on Home: shown name to the search that feeds the station. */
        private val GENRE_LIST = listOf(
            "Hip-Hop" to "hip hop", "Rap" to "rap", "Trap" to "trap", "Hyperpop" to "hyperpop",
            "Rock" to "rock", "Indie" to "indie", "Pop" to "pop", "R&B" to "r&b",
            "Electronic" to "electronic", "Alternative" to "alternative", "Punk" to "punk",
            "Lo-fi" to "lo-fi", "Chill" to "chill", "Workout" to "workout"
        )

        const val ACTION_LIKE = "siren.LIKE"
        const val ACTION_SHUFFLE = "siren.SHUFFLE"
        const val ACTION_REPEAT = "siren.REPEAT"
        val LIKE = SessionCommand(ACTION_LIKE, Bundle.EMPTY)
        val SHUFFLE = SessionCommand(ACTION_SHUFFLE, Bundle.EMPTY)
        val REPEAT = SessionCommand(ACTION_REPEAT, Bundle.EMPTY)

        // Android Auto content style hints
        private const val CONTENT_STYLE_SUPPORTED = "android.media.browse.CONTENT_STYLE_SUPPORTED"
        private const val CONTENT_STYLE_BROWSABLE = "android.media.browse.CONTENT_STYLE_BROWSABLE_HINT"
        private const val CONTENT_STYLE_PLAYABLE = "android.media.browse.CONTENT_STYLE_PLAYABLE_HINT"
        private const val SEARCH_SUPPORTED = "android.media.browse.SEARCH_SUPPORTED"
        private const val GROUP_TITLE = "android.media.browse.CONTENT_STYLE_GROUP_TITLE_HINT"
        private const val DOWNLOAD_STATUS = "android.media.extra.DOWNLOAD_STATUS"
        private const val STATUS_DOWNLOADED = 2L
        private const val IS_EXPLICIT = "android.media.IS_EXPLICIT"
        private const val STYLE_LIST = 1
        private const val STYLE_GRID = 2

        /** Heart next to the player controls (notification, lockscreen, car). */
        fun likeButton(liked: Boolean): CommandButton =
            CommandButton.Builder(if (liked) CommandButton.ICON_HEART_FILLED else CommandButton.ICON_HEART_UNFILLED)
                .setDisplayName(if (liked) "Remove from Liked songs" else "Add to Liked songs")
                .setSessionCommand(LIKE)
                .build()

        /** Shuffle button: off / shuffle / smart shuffle (star). */
        fun shuffleButton(shuffle: Boolean, smart: Boolean): CommandButton {
            val icon = when {
                shuffle && smart -> CommandButton.ICON_SHUFFLE_STAR
                shuffle -> CommandButton.ICON_SHUFFLE_ON
                else -> CommandButton.ICON_SHUFFLE_OFF
            }
            val name = when {
                shuffle && smart -> "Smart shuffle on"
                shuffle -> "Shuffle on"
                else -> "Shuffle off"
            }
            return CommandButton.Builder(icon).setDisplayName(name).setSessionCommand(SHUFFLE).build()
        }

        fun repeatButton(mode: Int): CommandButton {
            val icon = when (mode) {
                Player.REPEAT_MODE_ONE -> CommandButton.ICON_REPEAT_ONE
                Player.REPEAT_MODE_ALL -> CommandButton.ICON_REPEAT_ALL
                else -> CommandButton.ICON_REPEAT_OFF
            }
            val name = when (mode) {
                Player.REPEAT_MODE_ONE -> "Repeat this song"
                Player.REPEAT_MODE_ALL -> "Repeat all"
                else -> "Repeat off"
            }
            return CommandButton.Builder(icon).setDisplayName(name).setSessionCommand(REPEAT).build()
        }

        /** The extra buttons picked in Settings → Android Auto. */
        fun layout(liked: Boolean, shuffle: Boolean, smart: Boolean, repeat: Int, st: app.siren.data.AppSettings): List<CommandButton> =
            buildList {
                if (st.autoLikeButton) add(likeButton(liked))
                if (st.autoShuffleButton) add(shuffleButton(shuffle, smart))
                if (st.autoRepeatButton) add(repeatButton(repeat))
            }
    }
}
