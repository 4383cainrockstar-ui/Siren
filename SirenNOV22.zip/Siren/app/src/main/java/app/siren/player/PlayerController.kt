package app.siren.player

import app.siren.data.LocalMusic
import app.siren.data.Explicit
import android.content.Context
import android.content.Intent
import android.media.audiofx.AudioEffect
import android.net.Uri
import android.os.Bundle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.ShuffleOrder
import app.siren.core.Entry
import app.siren.core.Music
import app.siren.core.NonMusic
import app.siren.core.Segment
import app.siren.core.Track
import app.siren.core.cleanArtist
import app.siren.core.hiRes
import app.siren.core.videoIdFromUrl
import app.siren.data.Library
import app.siren.data.LibraryJson
import app.siren.data.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import java.io.File
import kotlin.random.Random

/**
 * One row of the queue, in the order songs will play. [index] is the position in the player.
 * [smart]: slipped in by smart shuffle, [why]: the song it was picked for.
 */
data class QueueItem(val index: Int, val track: Track, val smart: Boolean = false, val why: String = "")

@Serializable
private data class SavedQueue(
    val tracks: List<Track> = emptyList(),
    val index: Int = 0,
    val positionMs: Long = 0,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val radio: Boolean = false,
    val source: String = "",
    val smartIds: List<String> = emptyList(),
    val smartWhy: Map<String, String> = emptyMap(),
    val station: Station? = null,
    /** The shuffle order (play order) when shuffle was on. */
    val order: List<Int> = emptyList(),
    val savedAt: Long = 0
)

/**
 * App-wide player. ExoPlayer owns the real queue, so the notification, lockscreen,
 * headphones, Bluetooth and car controls all get next/previous/shuffle for free.
 */
@UnstableApi
object PlayerController {
    const val SLEEP_END_OF_SONG = -1L

    private lateinit var app: Context
    lateinit var player: ExoPlayer
        private set
    private var initialized = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _current = MutableStateFlow<Track?>(null)
    val current: StateFlow<Track?> = _current.asStateFlow()
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()
    private val _buffering = MutableStateFlow(false)
    val buffering: StateFlow<Boolean> = _buffering.asStateFlow()
    private val _queue = MutableStateFlow<List<QueueItem>>(emptyList())
    val queue: StateFlow<List<QueueItem>> = _queue.asStateFlow()
    private val _index = MutableStateFlow(-1)
    val index: StateFlow<Int> = _index.asStateFlow()
    private val _shuffle = MutableStateFlow(false)
    val shuffle: StateFlow<Boolean> = _shuffle.asStateFlow()
    private val _repeat = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeat: StateFlow<Int> = _repeat.asStateFlow()
    private val _speed = MutableStateFlow(1f)
    val speed: StateFlow<Float> = _speed.asStateFlow()
    private val _sleepAt = MutableStateFlow<Long?>(null)
    val sleepAt: StateFlow<Long?> = _sleepAt.asStateFlow()
    private val _source = MutableStateFlow("")
    val source: StateFlow<String> = _source.asStateFlow()
    private val _radio = MutableStateFlow(false)
    val radio: StateFlow<Boolean> = _radio.asStateFlow()
    private val _loadingRadio = MutableStateFlow(false)
    val loadingRadio: StateFlow<Boolean> = _loadingRadio.asStateFlow()
    private val _smart = MutableStateFlow(false)
    /** Smart shuffle: a related song every few songs. */
    val smart: StateFlow<Boolean> = _smart.asStateFlow()
    private val _station = MutableStateFlow<Station?>(null)
    /** The radio station playing (artist, genre or song), or null for a normal queue. */
    val station: StateFlow<Station?> = _station.asStateFlow()
    private var stationToken = 0
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    /** Emits when songs are added to the queue (add to queue / play next), so the UI can pulse. */
    private val _added = MutableSharedFlow<Int>(extraBufferCapacity = 4)
    val added: SharedFlow<Int> = _added.asSharedFlow()

    private var segments: List<Segment> = emptyList()
    private var segmentsFor = ""
    private var retriedFor = ""
    private var radioJob: Job? = null
    private var lastRecorded = ""
    private lateinit var queueFile: File
    private var callFocus: CallFocus? = null

    // Smart shuffle
    private val smartIds = HashSet<String>()
    private var sinceSmart = 0
    private var smartJob: Job? = null
    private val smartCache = LinkedHashMap<String, List<Track>>()
    private val artistCache = LinkedHashMap<String, List<Track>>()
    /** Smart pick video id -> title of the song it was picked for ("Because you played …"). */
    private val smartWhy = HashMap<String, String>()

    // ---------------------------------------------------------------------------------------
    // Setup
    // ---------------------------------------------------------------------------------------

    fun init(ctx: Context) {
        if (initialized) return
        initialized = true
        app = ctx.applicationContext
        queueFile = File(app.filesDir, "queue.json")

        val cache = SimpleCache(
            File(app.cacheDir, "audio"),
            LeastRecentlyUsedCacheEvictor(Settings.current.cacheMb.toLong() * 1024 * 1024),
            StandaloneDatabaseProvider(app)
        )
        val network = CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(YtDataSource.Factory())
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        StreamResolver.audioCache = network
        val resolving = ResolvingDataSource.Factory(network, StreamResolver)
        val dataSources = DefaultDataSource.Factory(app, resolving)

        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        player = ExoPlayer.Builder(app)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSources))
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setSkipSilenceEnabled(Settings.current.skipSilence)
            .build()

        player.addListener(listener)
        callFocus = CallFocus(app, player, attrs).also { it.setEnabled(Settings.current.keepDuringCalls) }
        Eq.attach(player.audioSessionId)
        Leveler.attach(player.audioSessionId)
        startFadeLoop()
        _smart.value = Settings.current.smartShuffle
        if (Settings.current.restoreQueue) restoreQueue()
        startTicker()
    }

    // ---------------- Crossfade ----------------

    private var fading = false

    /** Only songs that start on their own (the last one ended) fade in. Tapping a song or skipping starts at full volume. */
    private var fadeIn = false

    /** 1 normally; ramps down over the last seconds of a song and back up over the first seconds of the next. */
    private fun fadeGain(): Float {
        val sec = Settings.current.crossfadeSec
        if (sec <= 0) return 1f
        val dur = player.duration
        if (dur == C.TIME_UNSET || dur <= 0L) return 1f
        val fadeMs = minOf(sec * 1000L, dur / 2).coerceAtLeast(1L)
        val pos = player.currentPosition
        val up = if (fadeIn) (pos.toFloat() / fadeMs).coerceIn(0f, 1f) else 1f
        val down = ((dur - pos).toFloat() / fadeMs).coerceIn(0f, 1f)
        val g = minOf(up, down)
        return g * g * (3f - 2f * g)
    }

    private fun applyVolume() {
        val g = fadeGain()
        if (g >= 1f && !fading) return
        fading = g < 1f
        player.volume = g * (callFocus?.level ?: 1f)
    }

    private fun startFadeLoop() {
        scope.launch {
            while (isActive) {
                delay(100)
                if (Settings.current.crossfadeSec > 0 || fading) applyVolume()
            }
        }
    }

    private val listener = object : Player.Listener {
        override fun onPositionDiscontinuity(oldPosition: Player.PositionInfo, newPosition: Player.PositionInfo, reason: Int) {
            if (reason == Player.DISCONTINUITY_REASON_SEEK) fadeIn = false
            applyVolume()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            fadeIn = reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO
            applyVolume()
            val t = mediaItem?.toTrack()
            _current.value = t
            _index.value = player.currentMediaItemIndex
            retriedFor = ""
            if (t != null && t.videoId != lastRecorded) {
                lastRecorded = t.videoId
                Library.recordPlay(t)
                _station.value?.let { st -> _station.value = st.copy(played = (st.played + t.videoId).takeLast(400)) }
            }
            loadSegments(t)
            maybeExtendRadio()
            if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT) maybeSmart(countThis = true)
            preloadUpcoming()
            saveQueueSoon()
        }

        override fun onTimelineChanged(timeline: Timeline, reason: Int) {
            val pending = pendingShuffle
            if (pending != null && reason == Player.TIMELINE_CHANGE_REASON_PLAYLIST_CHANGED && player.mediaItemCount == pending.size) {
                pendingShuffle = null
                player.shuffleModeEnabled = true
                player.setShuffleOrder(ShuffleOrder.DefaultShuffleOrder(pending, Random.nextLong()))
            }
            syncQueue()
            preloadUpcoming()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
            if (!isPlaying) saveQueueSoon()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            _buffering.value = playbackState == Player.STATE_BUFFERING
            if (playbackState == Player.STATE_READY) preloadUpcoming()
            if (playbackState == Player.STATE_ENDED) onQueueEnded()
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            if (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM && _sleepAt.value == SLEEP_END_OF_SONG) {
                player.setPauseAtEndOfMediaItems(false)
                _sleepAt.value = null
            }
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _shuffle.value = shuffleModeEnabled
            syncQueue()
            saveQueueSoon()
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            _repeat.value = repeatMode
            saveQueueSoon()
        }

        override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
            _speed.value = playbackParameters.speed
        }

        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            Eq.attach(audioSessionId)
            Leveler.attach(audioSessionId)
            // Lets system / third-party equalizers attach to Siren's audio
            try {
                app.sendBroadcast(
                    Intent(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
                        .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, audioSessionId)
                        .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, app.packageName)
                        .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
                )
            } catch (_: Exception) {
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            handleError(error)
        }
    }

    // ---------------------------------------------------------------------------------------
    // Track <-> MediaItem
    // ---------------------------------------------------------------------------------------

    private fun Track.toMediaItem(): MediaItem {
        Explicit.register(this)
        val local = Library.downloadedUri(this)
        val uri = when {
            LocalMusic.isLocal(this) -> LocalMusic.playUri(this)   // a file on the phone
            local != null -> Uri.parse(local)
            else -> StreamResolver.uriFor(videoId)
        }
        val extras = Bundle().apply {
            putString("url", url)
            putString("artistUrl", artistUrl)
            putString("thumb", thumbnail)
            putLong("duration", duration)
            putString("album", album)
        }
        val art = hiRes(thumbnail)
        // Car screens (Android Auto) show "display title" + "subtitle" whenever a display title is
        // set, and ignore the artist field. Fill every field so the artist shows up everywhere.
        val md = MediaMetadata.Builder()
            .setTitle(title)
            .setDisplayTitle(title)
            .setArtist(artist.ifBlank { null })
            .setAlbumArtist(artist.ifBlank { null })
            .setSubtitle(artist.ifBlank { null })
            .setDescription(album.ifBlank { null })
            .setAlbumTitle(album.ifBlank { null })
            .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
            .setIsPlayable(true)
            .setIsBrowsable(false)
            .setExtras(extras)
            .apply { if (art.isNotBlank()) setArtworkUri(Uri.parse(art)) }
            .build()
        return MediaItem.Builder()
            .setMediaId(url)
            .setUri(uri)
            .setMediaMetadata(md)
            .build()
    }

    /** For the car / media browser: a playable item for [track]. */
    fun mediaItemFor(track: Track): MediaItem = track.toMediaItem()

    fun trackOf(item: MediaItem): Track = item.toTrack()

    /** A queue set from outside the app (Android Auto, Assistant): keep our own state in sync. */
    fun adoptExternalQueue(source: String, radio: Boolean, seed: Track? = null, station: Station? = null) {
        radioJob?.cancel()
        resetSmart()
        stationToken++
        _station.value = station ?: if (radio && seed != null) Station.song(seed) else null
        _source.value = source
        _radio.value = radio
        if (radio && seed != null) scope.launch {
            // Let the session apply the new items first, then top up the radio
            delay(1500)
            maybeExtendRadio()
        }
    }

    /** What's in the queue right now, for "resume playback" on Bluetooth / car start. */
    fun snapshot(): Triple<List<MediaItem>, Int, Long> {
        val items = (0 until player.mediaItemCount).map { player.getMediaItemAt(it) }
        return Triple(items, player.currentMediaItemIndex.coerceAtLeast(0), player.currentPosition.coerceAtLeast(0))
    }

    private fun MediaItem.toTrack(): Track {
        val md = mediaMetadata
        val ex = md.extras
        return Track(
            url = ex?.getString("url") ?: mediaId,
            title = md.title?.toString() ?: "",
            artist = md.artist?.toString() ?: "",
            artistUrl = ex?.getString("artistUrl") ?: "",
            thumbnail = ex?.getString("thumb") ?: md.artworkUri?.toString() ?: "",
            duration = ex?.getLong("duration", -1L) ?: -1L,
            album = ex?.getString("album") ?: ""
        )
    }

    // ---------------------------------------------------------------------------------------
    // Queue building
    // ---------------------------------------------------------------------------------------

    fun playTracks(tracks: List<Track>, start: Int = 0, shuffle: Boolean = false, source: String = "") {
        val list = tracks.distinctBy { it.videoId }
        if (list.isEmpty()) return
        radioJob?.cancel()
        resetSmart()
        _radio.value = false
        _station.value = null
        _source.value = source
        val first = if (shuffle) shuffleOrder(list).first() else start.coerceIn(0, list.size - 1)
        player.setMediaItems(list.map { it.toMediaItem() }, first, 0L)
        if (shuffle) {
            player.shuffleModeEnabled = true
            reshuffleFrom(first)
        } else if (player.shuffleModeEnabled) {
            reshuffleFrom(first)
        }
        player.prepare()
        player.play()
    }

    fun playTrack(track: Track, source: String = "") {
        if (Settings.current.autoRadio) playRadio(track, source) else playTracks(listOf(track), 0, false, source)
    }

    /** Plays [seed] now and keeps going with a station built around it. */
    fun playRadio(seed: Track, source: String = "") {
        radioJob?.cancel()
        resetSmart()
        stationToken++
        _station.value = Station.song(seed)
        _radio.value = true
        _source.value = source.ifBlank { "${seed.title} radio" }
        player.shuffleModeEnabled = false
        player.setMediaItems(listOf(seed.toMediaItem()), 0, 0L)
        player.prepare()
        player.play()
        extendRadio(seed)
    }

    /** Turns whatever's playing into a radio. */
    fun startRadioFromCurrent() {
        val t = _current.value ?: return
        // Drop everything after the current song and refill with similar ones
        val idx = player.currentMediaItemIndex
        if (idx + 1 < player.mediaItemCount) player.removeMediaItems(idx + 1, player.mediaItemCount)
        _radio.value = true
        stationToken++
        _station.value = Station.song(t)
        _source.value = "${t.title} radio"
        extendRadio(t)
    }

    /**
     * Starts a station: an artist ("Soulja Boy Radio"), a genre / mood ("2000s hip hop Radio")
     * or a song. Artists are spaced out like real radio and it never runs out.
     */
    fun playStation(st: Station) {
        radioJob?.cancel()
        resetSmart()
        val token = ++stationToken
        _station.value = st
        _radio.value = true
        _source.value = st.title
        _messages.tryEmit("Tuning in to ${st.title}…")
        radioJob = scope.launch {
            _loadingRadio.value = true
            try {
                val (next, list) = Stations.batch(st, emptyList(), emptySet())
                if (token != stationToken) return@launch
                _station.value = next
                if (list.isEmpty()) {
                    _messages.tryEmit("Couldn't build that station. Try another one.")
                    return@launch
                }
                player.shuffleModeEnabled = false
                player.setMediaItems(list.map { it.toMediaItem() }, 0, 0L)
                player.prepare()
                player.play()
                saveQueueSoon()
            } catch (_: Exception) {
                _messages.tryEmit("Couldn't build that station. Check your connection.")
            } finally {
                _loadingRadio.value = false
            }
        }
    }

    /**
     * "Hey Google, play ___ on Siren". Nothing named: carry on / shuffle Liked songs.
     * "___ radio" or an artist: a station. One of your playlists or Liked songs: that.
     * Anything else: the best matching song, then radio from it.
     */
    fun playVoice(query: String, focus: String, artist: String, playlist: String) {
        val q = query.trim()
        val lib = Library.value
        val isArtist = focus.contains("artist", ignoreCase = true) && artist.isNotBlank()
        val wantsRadio = Regex("(?i)\\b(radio|station)\\b").containsMatchIn(q)
        val plName = playlist.ifBlank { q }.lowercase().removePrefix("my ").removeSuffix(" playlist").trim()
        when {
            q.isEmpty() && !isArtist -> {
                if (player.mediaItemCount > 0) {
                    if (player.playbackState == Player.STATE_IDLE) player.prepare()
                    player.play()
                } else if (lib.liked.isNotEmpty()) playTracks(lib.liked, shuffle = true, source = "Liked songs")
                else _messages.tryEmit("Tell me what to play")
            }
            wantsRadio -> playStationFor(q)
            isArtist -> playStationFor(artist)
            plName == "liked songs" || plName == "liked" || plName == "favorites" || plName == "my likes" ->
                if (lib.liked.isNotEmpty()) playTracks(lib.liked, shuffle = true, source = "Liked songs")
                else _messages.tryEmit("No liked songs yet")
            else -> {
                val pl = lib.playlists.firstOrNull { it.name.equals(plName, ignoreCase = true) && it.tracks.isNotEmpty() }
                if (pl != null) {
                    playTracks(pl.tracks, shuffle = true, source = pl.name)
                    return
                }
                _messages.tryEmit("Finding \"$q\"…")
                scope.launch {
                    val t = try {
                        Music.search(q, Music.SONGS).items.filterIsInstance<Entry.Song>().firstOrNull()?.track
                    } catch (e: Exception) {
                        null
                    }
                    if (t == null) _messages.tryEmit("Couldn't find \"$q\"")
                    else playRadio(t, "${t.title} radio")
                }
            }
        }
    }

    /** "Soulja Boy radio" typed in Search: an artist station if it's an artist, else a genre. */
    fun playStationFor(text: String) {
        scope.launch {
            playStation(Stations.resolve(text))
        }
    }

    /** Thumbs up: more like this on the station. Tap again to undo. */
    fun thumbUp() {
        val st = _station.value ?: return
        val t = _current.value ?: return
        if (st.liked.any { it.videoId == t.videoId }) {
            _station.value = st.copy(liked = st.liked.filterNot { it.videoId == t.videoId })
        } else {
            _station.value = st.copy(liked = (st.liked + t).takeLast(30), banned = st.banned - t.videoId)
            _messages.tryEmit("More like this on ${st.title}")
        }
        saveQueueSoon()
    }

    /** Thumbs down: skip it, never play it on this station again, and cool off that artist. */
    fun thumbDown() {
        val st = _station.value ?: return
        val t = _current.value ?: return
        val key = Stations.artistKey(t.artist)
        val count = (st.cooled[key] ?: 0) + 1
        _station.value = st.copy(
            banned = (st.banned + t.videoId).takeLast(500),
            liked = st.liked.filterNot { it.videoId == t.videoId },
            cooled = if (key.isEmpty()) st.cooled else st.cooled + (key to count)
        )
        if (count >= 2 && key.isNotEmpty()) {
            // Two strikes: that artist is off the station, including what's already lined up
            val order = playOrder()
            val at = order.indexOf(player.currentMediaItemIndex)
            order.drop(at + 1).filter { Stations.artistKey(player.getMediaItemAt(it).toTrack().artist) == key }
                .sortedDescending().forEach { player.removeMediaItem(it) }
            _messages.tryEmit("No more ${t.artist.ifBlank { "of this artist" }} on this station")
        } else {
            _messages.tryEmit("Got it. You won't hear this one here again")
        }
        next()
        saveQueueSoon()
    }

    /**
     * Skips [t] (if it's playing) and hides its artist from radio, autoplay, smart shuffle, mixes
     * and suggestions. Lined-up radio songs by them go too; your own playlists are left alone.
     * Returns the hidden key for undo ("" if the song has no artist).
     */
    fun hideArtist(t: Track): String {
        val key = Library.hideArtist(t.artist)
        if (key.isEmpty()) {
            if (_current.value?.videoId == t.videoId) next()
            return ""
        }
        Discover.dropHidden()
        if (_radio.value || _station.value != null) {
            val order = playOrder()
            val at = order.indexOf(player.currentMediaItemIndex)
            order.drop(at + 1).filter { Stations.artistKey(player.getMediaItemAt(it).toTrack().artist) == key }
                .sortedDescending().forEach { player.removeMediaItem(it) }
        }
        if (_current.value?.videoId == t.videoId) next()
        saveQueueSoon()
        return key
    }

    fun isThumbedUp(track: Track?): Boolean =
        track != null && _station.value?.liked?.any { it.videoId == track.videoId } == true

    private fun extendRadio(seed: Track) {
        radioJob?.cancel()
        val st = _station.value ?: Station.song(seed).also { _station.value = it }
        val token = stationToken
        radioJob = scope.launch {
            _loadingRadio.value = true
            try {
                val have = HashSet<String>()
                for (i in 0 until player.mediaItemCount) {
                    videoIdFromUrl(player.getMediaItemAt(i).mediaId)?.let { have.add(it) }
                }
                val cur = player.currentMediaItemIndex.coerceAtLeast(0)
                val recent = (maxOf(0, cur - 10)..minOf(cur, player.mediaItemCount - 1)).map { player.getMediaItemAt(it).toTrack() }
                val (next, more) = Stations.batch(st, recent, have)
                if (token != stationToken) return@launch
                // Keep thumbs given while this was loading; take the new bookkeeping
                _station.value = (_station.value ?: next).copy(sourcesUsed = next.sourcesUsed)
                val fresh = more.filter { have.add(it.videoId) }
                if (fresh.isNotEmpty()) player.addMediaItems(fresh.map { it.toMediaItem() })
                // Keep the queue from growing forever on long sessions
                val extra = player.currentMediaItemIndex - 100
                if (extra > 0) player.removeMediaItems(0, extra)
            } catch (_: Exception) {
            } finally {
                _loadingRadio.value = false
            }
        }
    }

    private fun maybeExtendRadio() {
        if (player.mediaItemCount == 0) return
        val remaining = player.mediaItemCount - 1 - player.currentMediaItemIndex
        val auto = Settings.current.autoRadio && player.repeatMode == Player.REPEAT_MODE_OFF && !player.shuffleModeEnabled
        if (remaining <= 2 && (_radio.value || auto) && radioJob?.isActive != true) {
            val seed = _current.value ?: return
            if (!_radio.value) {
                _radio.value = true
                if (_source.value.isBlank()) _source.value = "Radio"
            }
            extendRadio(seed)
        }
    }

    private fun onQueueEnded() {
        // Radio still loading when the last song finished: continue as soon as it lands
        if (radioJob?.isActive == true) {
            scope.launch {
                radioJob?.join()
                if (player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                    player.play()
                }
            }
        }
    }

    fun playNext(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        if (player.mediaItemCount == 0) {
            playTracks(tracks)
            return
        }
        insertManyAfterCurrent(tracks)
        _added.tryEmit(tracks.size)
        _messages.tryEmit(if (tracks.size == 1) "Playing next" else "${tracks.size} songs play next")
    }

    /** Puts songs right after the current one, also when shuffle is on (where a plain insert lands anywhere). */
    private fun insertManyAfterCurrent(tracks: List<Track>) {
        val cur = player.currentMediaItemIndex
        val items = tracks.map { it.toMediaItem() }
        if (player.shuffleModeEnabled) {
            val order = playOrder().toMutableList()
            val n = player.mediaItemCount
            player.addMediaItems(n, items)
            val at = order.indexOf(cur)
            val ids = items.indices.map { n + it }
            if (at >= 0) order.addAll(at + 1, ids) else order.addAll(ids)
            if (order.size == player.mediaItemCount) {
                player.setShuffleOrder(ShuffleOrder.DefaultShuffleOrder(order.toIntArray(), Random.nextLong()))
            }
        } else {
            player.addMediaItems((cur + 1).coerceAtMost(player.mediaItemCount), items)
        }
        syncQueue()
        saveQueueSoon()
        preloadUpcoming()
    }

    /** "Play next" on a song that's already in the queue: moves it to right after the current one. */
    fun moveNextInQueue(index: Int) {
        val order = playOrder()
        val from = order.indexOf(index)
        val cur = order.indexOf(player.currentMediaItemIndex)
        if (from < 0 || cur < 0 || from == cur) return
        if (from != cur + 1) moveInQueue(from, if (from > cur) cur + 1 else cur)
        _messages.tryEmit("Playing next")
    }

    /** Looks up the next few songs' stream links in the background so they start without a wait. */
    fun preloadUpcoming() {
        if (!Settings.current.preloadNext || player.mediaItemCount == 0) return
        if (player.playbackState != Player.STATE_READY) return
        if (Settings.current.preloadWifiOnly) {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
            if (cm != null && cm.isActiveNetworkMetered) return
        }
        val order = playOrder()
        val at = order.indexOf(player.currentMediaItemIndex)
        if (at < 0) return
        val ids = order.drop(at + 1).take(3).mapNotNull {
            StreamResolver.idOf(player.getMediaItemAt(it).localConfiguration?.uri)
        }
        if (ids.isNotEmpty()) StreamResolver.prefetch(ids)
    }

    fun addToQueue(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        if (player.mediaItemCount == 0) {
            playTracks(tracks)
            return
        }
        player.addMediaItems(tracks.map { it.toMediaItem() })
        _added.tryEmit(tracks.size)
        _messages.tryEmit(if (tracks.size == 1) "Added to queue" else "${tracks.size} songs added to queue")
    }

    fun removeAt(index: Int) {
        if (index in 0 until player.mediaItemCount) player.removeMediaItem(index)
    }

    fun move(from: Int, to: Int) {
        val n = player.mediaItemCount
        if (from in 0 until n && to in 0 until n && from != to) player.moveMediaItem(from, to)
    }

    /**
     * Moves a song within the queue as you see it (play order, so it works with shuffle on:
     * then only the shuffle order changes). Positions are in the queue list, not the player.
     */
    fun moveInQueue(fromPos: Int, toPos: Int) {
        val order = playOrder()
        if (fromPos !in order.indices || toPos !in order.indices || fromPos == toPos) return
        if (!player.shuffleModeEnabled) {
            player.moveMediaItem(order[fromPos], order[toPos])
        } else {
            val o = order.toMutableList()
            val x = o.removeAt(fromPos)
            o.add(toPos, x)
            player.setShuffleOrder(ShuffleOrder.DefaultShuffleOrder(o.toIntArray(), Random.nextLong()))
        }
    }

    fun skipTo(index: Int) {
        if (index !in 0 until player.mediaItemCount) return
        player.seekTo(index, 0L)
        if (player.playbackState == Player.STATE_IDLE) player.prepare()
        player.play()
    }

    /** Removes everything after the current song. */
    fun clearUpcoming() {
        radioJob?.cancel()
        val idx = player.currentMediaItemIndex
        if (idx + 1 < player.mediaItemCount) player.removeMediaItems(idx + 1, player.mediaItemCount)
        _radio.value = false
        _station.value = null
        _messages.tryEmit("Cleared up next")
    }

    fun clearQueue() {
        radioJob?.cancel()
        resetSmart()
        player.stop()
        player.clearMediaItems()
        _radio.value = false
        _station.value = null
        _source.value = ""
        _current.value = null
        saveQueueSoon()
    }

    /** Makes a fresh shuffle order that starts at [first] so nothing gets skipped. */
    private fun reshuffleFrom(first: Int) {
        val n = player.mediaItemCount
        if (n <= 1) return
        val tracks = (0 until n).map { player.getMediaItemAt(it).toTrack() }
        val order = shuffleOrder(tracks, first)
        player.setShuffleOrder(ShuffleOrder.DefaultShuffleOrder(order, Random.nextLong()))
    }

    /**
     * A shuffle that feels random to people (like Spotify's): truly random each time, but songs
     * you played in the last couple of days go toward the back, and the same artist doesn't come
     * up twice in a row when it can be avoided. [first] stays first.
     */
    fun shuffleOrder(tracks: List<Track>, first: Int = -1): IntArray {
        val n = tracks.size
        if (n == 0) return IntArray(0)
        val recentCut = System.currentTimeMillis() - 48L * 3600 * 1000
        val lastPlayed = HashMap<String, Long>()
        Library.value.history.forEach { lastPlayed[it.track.videoId] = it.lastPlayed }
        val rest = (0 until n).filter { it != first }
        val (recent, fresh) = rest.partition { (lastPlayed[tracks[it].videoId] ?: 0L) > recentCut }
        val pool = (fresh.shuffled() + recent.shuffled()).toMutableList()
        // Spread artists out: take the next song whose artist isn't one of the last two
        val keys = Array(n) { Stations.artistKey(tracks[it].artist) }
        val out = ArrayList<Int>(n)
        if (first in 0 until n) out += first
        while (pool.isNotEmpty()) {
            val a1 = out.getOrNull(out.size - 1)?.let { keys[it] }
            val a2 = out.getOrNull(out.size - 2)?.let { keys[it] }
            val window = minOf(pool.size, 8)
            val pick = (0 until window).firstOrNull { val k = keys[pool[it]]; k != a1 && k != a2 } ?: 0
            out += pool.removeAt(pick)
        }
        return out.toIntArray()
    }

    /** Set by Android Auto / voice "shuffle" requests; applied once the new queue lands. */
    @Volatile private var pendingShuffle: IntArray? = null

    /**
     * For queues handed over by Android Auto or voice: play [tracks] shuffled for real (shuffle
     * button on, a fresh order every time). Returns the list in its normal order plus where to
     * start; the shuffle order is applied as soon as the session sets the items.
     */
    fun prepareShuffledQueue(tracks: List<Track>): Pair<List<Track>, Int> {
        if (tracks.isEmpty()) return tracks to 0
        val order = shuffleOrder(tracks)
        pendingShuffle = order
        return tracks to order.first()
    }

    // ---------------------------------------------------------------------------------------
    // Transport
    // ---------------------------------------------------------------------------------------

    fun togglePlay() {
        if (player.mediaItemCount == 0) return
        when {
            player.isPlaying -> player.pause()
            else -> {
                if (player.playbackState == Player.STATE_IDLE) player.prepare()
                if (player.playbackState == Player.STATE_ENDED) player.seekToDefaultPosition(0)
                player.play()
            }
        }
    }

    /** Next song. At the end of the queue it keeps going with similar songs instead of doing nothing. */
    fun next() {
        if (player.mediaItemCount == 0) return
        if (player.hasNextMediaItem()) {
            player.seekToNextMediaItem()
            return
        }
        val t = _current.value ?: return
        if (radioJob?.isActive != true) {
            _radio.value = true
            if (_source.value.isBlank()) _source.value = "${t.title} radio"
            extendRadio(t)
        }
        scope.launch {
            radioJob?.join()
            if (player.hasNextMediaItem()) {
                player.seekToNextMediaItem()
                if (player.playbackState == Player.STATE_IDLE) player.prepare()
                player.play()
            }
        }
    }

    fun previous() {
        if (player.currentPosition > 3000 || !player.hasPreviousMediaItem()) player.seekTo(0)
        else player.seekToPreviousMediaItem()
    }

    fun seekTo(ms: Long) {
        player.seekTo(ms.coerceAtLeast(0))
    }

    fun toggleShuffle() {
        val on = !player.shuffleModeEnabled
        player.shuffleModeEnabled = on
        if (on) reshuffleFrom(player.currentMediaItemIndex)
    }

    /** The player's shuffle button, Spotify style: off → shuffle → smart shuffle → off. */
    fun cycleShuffle() {
        when {
            // Off (or smart picks without shuffle): shuffle on, smart picks stay as they are
            !player.shuffleModeEnabled -> {
                player.shuffleModeEnabled = true
                reshuffleFrom(player.currentMediaItemIndex)
                if (_smart.value) {
                    // The reshuffle scattered the lined-up pick; put the next one back in place
                    removeUpcomingSmart()
                    maybeSmart(countThis = false)
                }
            }
            !_smart.value -> setSmart(true)
            else -> {
                setSmart(false, quiet = true)
                player.shuffleModeEnabled = false
            }
        }
    }

    // ---------------------------------------------------------------------------------------
    // Smart shuffle: every few songs, a related song you haven't heard lately slips in
    // ---------------------------------------------------------------------------------------

    fun setSmart(on: Boolean, quiet: Boolean = false) {
        if (_smart.value == on) return
        _smart.value = on
        Settings.update { it.copy(smartShuffle = on) }
        if (on) {
            // First pick goes right after the current song, then every N songs
            sinceSmart = smartEvery() - 1
            if (!quiet) _messages.tryEmit("Smart shuffle on: a new pick every ${ordinal(smartEvery())} song")
            maybeSmart(countThis = false)
        } else {
            smartJob?.cancel()
            removeUpcomingSmart()
            if (!quiet) _messages.tryEmit("Smart shuffle off")
        }
    }

    /** Frequency changed in Settings. */
    fun smartEveryChanged() {
        sinceSmart = sinceSmart.coerceAtMost(smartEvery() - 1)
        maybeSmart(countThis = false)
    }

    fun isSmartPick(track: Track): Boolean = track.videoId in smartIds

    private fun smartEvery() = Settings.current.smartEvery.coerceIn(2, 10)

    private fun ordinal(n: Int) = when (n) {
        2 -> "2nd"
        3 -> "3rd"
        else -> "${n}th"
    }

    private fun resetSmart() {
        smartJob?.cancel()
        smartIds.clear()
        smartWhy.clear()
        sinceSmart = 0
    }

    /** Positions in the order they'll play (follows shuffle). */
    private fun playOrder(): List<Int> {
        val tl = player.currentTimeline
        if (tl.isEmpty) return emptyList()
        val shuffled = player.shuffleModeEnabled
        val order = ArrayList<Int>(tl.windowCount)
        var i = tl.getFirstWindowIndex(shuffled)
        while (i != C.INDEX_UNSET && order.size < tl.windowCount) {
            order.add(i)
            i = tl.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, shuffled)
        }
        return order
    }

    private fun isSmartAt(i: Int): Boolean =
        i in 0 until player.mediaItemCount && player.getMediaItemAt(i).toTrack().videoId in smartIds

    private fun maybeSmart(countThis: Boolean) {
        if (!_smart.value || player.mediaItemCount == 0) return
        val cur = _current.value ?: return
        if (countThis) {
            if (cur.videoId in smartIds) sinceSmart = 0 else sinceSmart++
        }
        // A radio is already all "more like this", and repeat-one means one song on loop
        if (_radio.value || player.repeatMode == Player.REPEAT_MODE_ONE) return
        if (sinceSmart < smartEvery() - 1) return
        val order = playOrder()
        val next = order.getOrNull(order.indexOf(player.currentMediaItemIndex) + 1)
        if (next != null && isSmartAt(next)) return
        if (smartJob?.isActive == true) return
        val seedId = cur.videoId
        smartJob = scope.launch {
            val (pick, why) = findSmartPick(cur) ?: return@launch
            if (_current.value?.videoId != seedId || !_smart.value) return@launch
            smartWhy[pick.videoId] = why
            insertAfterCurrent(pick)
        }
    }

    /** "Drake, 21 Savage" / "Daft Punk - Topic" -> "drake" / "daft punk": the main artist, for comparing. */
    private fun artistKey(a: String): String =
        cleanArtist(a).lowercase().split(",", " & ", " x ", " feat", " ft.", " with ").first().trim()

    private suspend fun radioFor(seed: Track): List<Track> = smartCache[seed.videoId] ?: try {
        Music.radio(seed)
    } catch (e: Exception) {
        emptyList()
    }.also { found ->
        if (found.isNotEmpty()) {
            smartCache[seed.videoId] = found
            while (smartCache.size > 20) smartCache.remove(smartCache.keys.first())
        }
    }

    private suspend fun topSongsOf(t: Track): List<Track> {
        val key = artistKey(t.artist)
        artistCache[key]?.let { return it }
        val songs = try {
            Music.artistSongs(cleanArtist(t.artist), t.artistUrl, limit = 15)
        } catch (e: Exception) {
            emptyList()
        }
        if (songs.isNotEmpty()) {
            artistCache[key] = songs
            while (artistCache.size > 30) artistCache.remove(artistCache.keys.first())
        }
        return songs
    }

    private class Candidate(val track: Track, var score: Double, val why: String)

    /**
     * Picks the next smart shuffle song. Not just "more of this artist":
     *  - seeds from the current song plus another song from this session, so it follows your taste
     *  - skips artists you've heard in the last few songs (and the ones coming up)
     *  - branches out through similar artists' top songs
     *  - the Familiar ↔ Adventurous setting decides how close it stays and how much it favors
     *    songs you already like vs ones you've never heard
     */
    private suspend fun findSmartPick(cur: Track): Pair<Track, String>? {
        val variety = Settings.current.smartVariety.coerceIn(0, 4) // 0 familiar … 4 adventurous
        val lib = Library.value
        val history = lib.history

        // Snapshot the queue before any network wait
        val inQueue = HashSet<String>()
        for (i in 0 until player.mediaItemCount) inQueue.add(player.getMediaItemAt(i).toTrack().videoId)
        inQueue.addAll(smartIds)
        val order = playOrder()
        val at = order.indexOf(player.currentMediaItemIndex)
        val upcoming = order.drop(at + 1).take(3).map { player.getMediaItemAt(it).toTrack() }

        val curArtist = artistKey(cur.artist)
        val window = 3 + variety * 3 // how many recent songs' artists to steer clear of: 3..15
        val avoid = (listOf(cur) + upcoming + history.take(window).map { it.track })
            .map { artistKey(it.artist) }.filter { it.isNotEmpty() }.toHashSet()
        val heardLately = history.take(60).map { it.track.videoId }.toHashSet()
        val plays = history.take(800).associate { it.track.videoId to it.plays }
        val liked = lib.liked.map { it.videoId }.toHashSet()
        val hidden = Library.hiddenKeys()

        // Familiar boosts songs you know; adventurous pushes toward ones you don't
        val knownBoost = 0.3 - variety * 0.15

        val cands = LinkedHashMap<String, Candidate>()
        fun consider(t: Track, base: Double, why: String) {
            val id = t.videoId
            if (id == cur.videoId || id in inQueue) return
            val a = artistKey(t.artist)
            if (a.isNotEmpty() && (a in avoid || a in hidden)) return
            if (t.duration > 600 || t.duration in 1L..59L) return // mixes, intros, skits
            var s = base
            if (id in liked) s += knownBoost
            if ((plays[id] ?: 0) > 0) s += knownBoost * 0.7
            if (id in heardLately) s -= 0.6
            val old = cands[id]
            if (old == null || s > old.score) cands[id] = Candidate(t, s, why)
        }

        // 1) Radios: the current song, plus one other song from this session with a different artist
        val sessionSeed = history.drop(1).take(10).map { it.track }
            .filter { artistKey(it.artist).let { a -> a.isNotEmpty() && a != curArtist } }
            .distinctBy { artistKey(it.artist) }
            .shuffled().firstOrNull()
        val seeds = listOfNotNull(cur, sessionSeed)
        val curPool = radioFor(cur)
        for (seed in seeds) {
            val pool = if (seed === cur) curPool else radioFor(seed)
            if (pool.isEmpty()) continue
            // Adventurous skips the closest few and reaches further down the list
            val skipTop = listOf(0, 0, 2, 4, 6)[variety]
            pool.forEachIndexed { rank, t ->
                var s = 1.0 - rank.toDouble() / pool.size
                if (rank < skipTop) s -= 0.35
                if (seed !== cur) s -= 0.12
                consider(t, s, seed.title)
            }
        }

        // 2) Branch out: top songs from an artist who shows up around this song
        if (variety >= 1 || cands.size < 4) {
            val related = (curPool + (sessionSeed?.let { smartCache[it.videoId] } ?: emptyList()))
                .filter { artistKey(it.artist).let { a -> a.isNotEmpty() && a !in avoid } }
                .groupBy { artistKey(it.artist) }
                .values.map { it.first() }
            if (related.isNotEmpty()) {
                // Familiar picks the most closely related artist; adventurous goes further afield
                val reach = (1 + variety * 2).coerceAtMost(related.size)
                val via = related.take(reach + 1).random()
                val songs = topSongsOf(via)
                songs.forEachIndexed { rank, t ->
                    consider(t, 0.55 + variety * 0.08 - rank * 0.02, cur.title)
                }
            }
        }

        if (cands.isEmpty()) {
            // Everything got filtered out: fall back to the closest songs not already queued
            val fresh = curPool.filter { it.videoId !in inQueue && it.videoId != cur.videoId }
                .sortedBy { if (artistKey(it.artist) == curArtist) 1 else 0 }
            return fresh.take(6).randomOrNull()?.let { it to cur.title }
        }

        // A little randomness among the best few keeps it from feeling samey
        val top = cands.values.sortedByDescending { it.score }.take(5)
        val minScore = top.minOf { it.score }
        val weights = top.map { (it.score - minScore + 0.15).coerceAtLeast(0.05) }
        var r = Random.nextDouble() * weights.sum()
        for ((i, c) in top.withIndex()) {
            r -= weights[i]
            if (r <= 0) return c.track to c.why
        }
        return top.first().let { it.track to it.why }
    }

    private fun insertAfterCurrent(t: Track) {
        smartIds.add(t.videoId)
        val cur = player.currentMediaItemIndex
        if (player.shuffleModeEnabled) {
            val order = playOrder().toMutableList()
            val n = player.mediaItemCount
            player.addMediaItem(n, t.toMediaItem())
            val at = order.indexOf(cur)
            if (at >= 0) order.add(at + 1, n) else order.add(n)
            if (order.size == player.mediaItemCount) {
                player.setShuffleOrder(ShuffleOrder.DefaultShuffleOrder(order.toIntArray(), Random.nextLong()))
            }
        } else {
            player.addMediaItem((cur + 1).coerceAtMost(player.mediaItemCount), t.toMediaItem())
        }
        syncQueue()
        saveQueueSoon()
        preloadUpcoming()
    }

    /** Smart shuffle turned off: drop the picks that haven't played yet. */
    private fun removeUpcomingSmart() {
        val order = playOrder()
        val at = order.indexOf(player.currentMediaItemIndex)
        val drop = order.drop(at + 1).filter { isSmartAt(it) }.sortedDescending()
        drop.forEach { player.removeMediaItem(it) }
        smartIds.retainAll((0 until player.mediaItemCount).map { player.getMediaItemAt(it).toTrack().videoId }.toSet())
    }

    fun cycleRepeat() {
        player.repeatMode = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun setSpeed(speed: Float) {
        player.setPlaybackSpeed(speed.coerceIn(0.25f, 3f))
    }

    fun setSleepMinutes(minutes: Int) {
        player.setPauseAtEndOfMediaItems(false)
        _sleepAt.value = System.currentTimeMillis() + minutes * 60_000L
        _messages.tryEmit("Sleep timer: $minutes min")
    }

    fun sleepEndOfSong() {
        _sleepAt.value = SLEEP_END_OF_SONG
        player.setPauseAtEndOfMediaItems(true)
        _messages.tryEmit("Pausing after this song")
    }

    fun cancelSleep() {
        _sleepAt.value = null
        player.setPauseAtEndOfMediaItems(false)
    }

    fun applySettings() {
        player.setSkipSilenceEnabled(Settings.current.skipSilence)
        callFocus?.setEnabled(Settings.current.keepDuringCalls)
    }

    /** Quality changed: future loads pick the new stream. */
    fun qualityChanged() {
        StreamResolver.invalidate(null)
    }

    /** A download finished or was removed: swap the queued copies to/from the local file. */
    fun refreshSourceFor(track: Track) {
        for (i in 0 until player.mediaItemCount) {
            val item = player.getMediaItemAt(i)
            if (videoIdFromUrl(item.mediaId) == track.videoId && i != player.currentMediaItemIndex) {
                player.replaceMediaItem(i, item.toTrack().toMediaItem())
            }
        }
    }

    fun equalizerIntent(): Intent =
        Intent(AudioEffect.ACTION_DISPLAY_AUDIO_EFFECT_CONTROL_PANEL)
            .putExtra(AudioEffect.EXTRA_AUDIO_SESSION, player.audioSessionId)
            .putExtra(AudioEffect.EXTRA_PACKAGE_NAME, app.packageName)
            .putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)

    // ---------------------------------------------------------------------------------------
    // Errors
    // ---------------------------------------------------------------------------------------

    private fun handleError(error: PlaybackException) {
        val item = player.currentMediaItem ?: return
        val track = item.toTrack()
        val uri = item.localConfiguration?.uri

        // A downloaded file that was deleted outside the app: fall back to streaming
        if (uri != null && uri.scheme != StreamResolver.SCHEME) {
            val pos = player.currentPosition
            val streaming = item.buildUpon().setUri(StreamResolver.uriFor(track.videoId)).build()
            player.replaceMediaItem(player.currentMediaItemIndex, streaming)
            player.seekTo(player.currentMediaItemIndex, pos)
            player.prepare()
            player.play()
            return
        }

        // First failure on a song: usually an expired / rejected URL. Get a fresh one and retry.
        if (retriedFor != track.videoId) {
            retriedFor = track.videoId
            StreamResolver.invalidate(track.videoId)
            player.prepare()
            player.play()
            return
        }

        var cause: Throwable? = error
        var reason = error.cause?.message ?: error.errorCodeName
        while (cause != null) {
            if (cause is HttpDataSource.InvalidResponseCodeException) {
                reason = "server said ${cause.responseCode}"
                break
            }
            if (cause is java.io.IOException && !cause.message.isNullOrBlank() && cause.cause != null) {
                reason = cause.message ?: reason
            }
            cause = cause.cause
        }
        _messages.tryEmit("Couldn't play \"${track.title}\" ($reason)")
        if (player.hasNextMediaItem()) {
            player.seekToNextMediaItem()
            player.prepare()
            player.play()
        }
    }

    // ---------------------------------------------------------------------------------------
    // Ticker: skip non-music parts, sleep timer, saving the queue
    // ---------------------------------------------------------------------------------------

    private fun loadSegments(t: Track?) {
        segments = emptyList()
        segmentsFor = t?.videoId ?: ""
        if (t == null || !Settings.current.skipNonMusic) return
        val id = t.videoId
        scope.launch {
            val s = NonMusic.segments(id)
            if (segmentsFor == id) segments = s
        }
    }

    private fun startTicker() {
        scope.launch {
            var n = 0
            while (isActive) {
                delay(500)
                n++
                val sleep = _sleepAt.value
                if (sleep != null && sleep > 0 && System.currentTimeMillis() >= sleep) {
                    _sleepAt.value = null
                    player.pause()
                }
                if (player.isPlaying) {
                    val pos = player.currentPosition
                    if (Settings.current.skipNonMusic) {
                        val seg = segments.firstOrNull { pos >= it.startMs && pos < it.endMs - 500 }
                        if (seg != null) {
                            val dur = player.duration
                            if (dur != C.TIME_UNSET && seg.endMs >= dur - 1000) {
                                if (player.hasNextMediaItem()) player.seekToNextMediaItem() else player.seekTo(seg.endMs)
                            } else {
                                player.seekTo(seg.endMs)
                            }
                        }
                    }
                    if (n % 20 == 0) saveQueueSoon()
                }
            }
        }
    }

    // ---------------------------------------------------------------------------------------
    // Queue list for the UI + persistence
    // ---------------------------------------------------------------------------------------

    private fun syncQueue() {
        val tl = player.currentTimeline
        if (tl.isEmpty) {
            _queue.value = emptyList()
            _index.value = -1
            if (player.mediaItemCount == 0) _current.value = null
            return
        }
        _queue.value = playOrder().map {
            val t = player.getMediaItemAt(it).toTrack()
            QueueItem(it, t, t.videoId in smartIds, smartWhy[t.videoId].orEmpty())
        }
        _index.value = player.currentMediaItemIndex
        if (_current.value == null) _current.value = player.currentMediaItem?.toTrack()
    }

    private var saveJob: Job? = null

    private fun saveQueueSoon() {
        if (!::queueFile.isInitialized) return
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(800)
            val tracks = (0 until player.mediaItemCount).map { player.getMediaItemAt(it).toTrack() }
            val state = SavedQueue(
                tracks = tracks,
                index = player.currentMediaItemIndex.coerceAtLeast(0),
                positionMs = player.currentPosition,
                shuffle = player.shuffleModeEnabled,
                repeat = player.repeatMode,
                radio = _radio.value,
                source = _source.value,
                smartIds = tracks.map { it.videoId }.filter { it in smartIds },
                smartWhy = smartWhy.filterKeys { it in smartIds },
                station = _station.value,
                order = if (player.shuffleModeEnabled) playOrder() else emptyList(),
                savedAt = System.currentTimeMillis()
            )
            withContext(Dispatchers.IO) {
                try {
                    queueFile.writeText(LibraryJson.json.encodeToString(SavedQueue.serializer(), state))
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun restoreQueue() {
        try {
            if (!queueFile.exists()) return
            val s = LibraryJson.json.decodeFromString(SavedQueue.serializer(), queueFile.readText())
            if (s.tracks.isEmpty()) return
            val idx = s.index.coerceIn(0, s.tracks.size - 1)
            player.setMediaItems(s.tracks.map { it.toMediaItem() }, idx, s.positionMs.coerceAtLeast(0))
            player.shuffleModeEnabled = s.shuffle
            if (s.shuffle) {
                // A quick stop: carry on in the same order. A real break (next drive, next day):
                // keep the current song, reshuffle everything else so it's not the same run again.
                val fresh = System.currentTimeMillis() - s.savedAt < 3L * 3600 * 1000
                val valid = s.order.size == s.tracks.size && s.order.toSet().size == s.tracks.size && s.order.all { it in s.tracks.indices }
                if (fresh && valid) player.setShuffleOrder(ShuffleOrder.DefaultShuffleOrder(s.order.toIntArray(), Random.nextLong()))
                else reshuffleFrom(idx)
            }
            player.repeatMode = s.repeat
            _radio.value = s.radio
            _source.value = s.source
            smartIds.addAll(s.smartIds)
            smartWhy.putAll(s.smartWhy)
            _station.value = s.station?.takeIf { s.radio }
            _current.value = s.tracks[idx]
            lastRecorded = s.tracks[idx].videoId
            // Not prepared on purpose: nothing hits the network until you press play
        } catch (_: Exception) {
        }
    }
}
