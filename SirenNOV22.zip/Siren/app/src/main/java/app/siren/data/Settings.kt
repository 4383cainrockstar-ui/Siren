package app.siren.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable

@Serializable
data class AppSettings(
    // Playback
    val highQuality: Boolean = true,
    val autoRadio: Boolean = true,
    val skipSilence: Boolean = false,
    val skipNonMusic: Boolean = true,
    val restoreQueue: Boolean = true,
    /** Keep playing (turned down) during phone and app calls instead of pausing. */
    val keepDuringCalls: Boolean = false,
    /** Looks up the next few songs' stream links ahead of time so new songs start fast. */
    val preloadNext: Boolean = true,
    val preloadWifiOnly: Boolean = false,
    /** Fades one song out and the next in at the changeover. 0 = off, otherwise seconds (1 to 12). */
    val crossfadeSec: Int = 0,
    /** Evens out loud and quiet songs. Level: 0 Gentle, 1 Balanced, 2 Strong. */
    val normalize: Boolean = false,
    val normalizeLevel: Int = 1,
    /** One playlist, rebuilt every Monday from mostly songs you haven't heard. */
    val weeklyMix: Boolean = true,
    val weeklyMixWeek: String = "",
    /** When a song has explicit and clean versions, play the explicit one. */
    val preferExplicit: Boolean = true,
    /** Hold Next for 3 seconds: skip and hide that artist from suggestions. */
    val holdToHide: Boolean = true,
    // Car mode: open it by itself when one of these Bluetooth devices connects
    val carAutoOpen: Boolean = false,
    val carDevices: List<String> = emptyList(),
    /** True black everywhere (cards and sheets too), no album-color tints. */
    val pureOled: Boolean = false,
    /** Little ripples on like, follow, skip, play / pause, queue add and finished downloads. */
    val rippleEffects: Boolean = true,
    // Storage & downloads
    val cacheMb: Int = 512,
    val wifiOnlyDownloads: Boolean = false,
    val autoDownloadLikes: Boolean = false,
    // Smart shuffle: slips a related song into the queue every [smartEvery] songs
    val smartShuffle: Boolean = false,
    val smartEvery: Int = 3,
    /** 0 = Familiar (close to what you're playing, songs you know) … 4 = Adventurous */
    val smartVariety: Int = 2,
    // Android Auto: grid (big cover art) or list for each section
    val autoGridHome: Boolean = true,
    val autoGridLiked: Boolean = false,
    val autoGridPlaylists: Boolean = true,
    val autoGridSongs: Boolean = false,
    val autoGridDownloads: Boolean = false,
    // Extra buttons next to the controls (car, notification, lockscreen)
    val autoLikeButton: Boolean = true,
    val autoShuffleButton: Boolean = true,
    val autoRepeatButton: Boolean = false,
    // Equalizer (levels in millibels, one per band; bass boost 0..1000)
    val eqEnabled: Boolean = false,
    val eqBands: List<Int> = emptyList(),
    val eqBass: Int = 0,
    val eqPreset: String = "Flat",
    // Lyrics
    val showLyricsByDefault: Boolean = false,
    // Privacy
    val pauseHistory: Boolean = false,
    val saveSearchHistory: Boolean = true
)

object Settings {
    private const val KEY = "settings_json"
    private lateinit var prefs: SharedPreferences
    private val _state = MutableStateFlow(AppSettings())
    val state: StateFlow<AppSettings> = _state.asStateFlow()
    val current: AppSettings get() = _state.value

    val cacheOptions = listOf(128, 256, 512, 1024, 2048, 4096)
    val smartOptions = listOf(2, 3, 4, 5)

    fun init(ctx: Context) {
        // File name kept from Pulse so settings carry over
        prefs = ctx.getSharedPreferences("pulse", Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY, null)
        if (raw != null) {
            _state.value = try {
                LibraryJson.json.decodeFromString(AppSettings.serializer(), raw)
            } catch (e: Exception) {
                AppSettings()
            }
        }
    }

    fun update(block: (AppSettings) -> AppSettings) {
        val next = block(_state.value)
        _state.value = next
        prefs.edit().putString(KEY, LibraryJson.json.encodeToString(AppSettings.serializer(), next)).apply()
    }
}
