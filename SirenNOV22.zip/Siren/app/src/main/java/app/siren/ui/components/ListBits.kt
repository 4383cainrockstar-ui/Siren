package app.siren.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import app.siren.core.Track
import app.siren.data.DownloadRecord
import app.siren.data.LibraryData
import app.siren.data.Library
import app.siren.download.Downloads
import app.siren.ui.LocalActions
import app.siren.ui.theme.Sc

/** How much of [tracks] is saved offline. */
fun downloadState(tracks: List<Track>, lib: LibraryData): Pair<DlState, Float> {
    if (tracks.isEmpty()) return DlState.NONE to 0f
    val ids = tracks.map { it.videoId }.toHashSet()
    val recs = lib.downloads.filter { it.track.videoId in ids }
    val done = recs.count { it.status == DownloadRecord.STATUS_DONE }
    val active = recs.count { it.status == DownloadRecord.STATUS_RUNNING || it.status == DownloadRecord.STATUS_QUEUED }
    return when {
        done >= ids.size -> DlState.DONE to 1f
        active > 0 -> DlState.RUNNING to done.toFloat() / ids.size
        else -> DlState.NONE to 0f
    }
}

/**
 * "Download all" for a list. Tap to download everything ([downloadAll] can fetch the rest of a
 * long playlist first); when it's all saved, tap again to remove the downloads.
 */
@UnstableApi
@Composable
fun ListDownloadButton(tracks: List<Track>, downloadAll: (() -> Unit)? = null) {
    val actions = LocalActions.current
    val ctx = LocalContext.current
    val lib by Library.data.collectAsState()
    val (state, progress) = downloadState(tracks, lib)
    var confirm by remember { mutableStateOf(false) }
    DownloadToggle(state, progress, onClick = {
        when (state) {
            DlState.NONE -> {
                if (downloadAll != null) downloadAll()
                else if (tracks.isNotEmpty()) actions.download(tracks)
            }
            DlState.RUNNING -> {
                val ids = tracks.map { it.videoId }.toHashSet()
                val done = lib.downloads.count { it.track.videoId in ids && it.status == DownloadRecord.STATUS_DONE }
                actions.message("Downloading: $done of ${ids.size} saved")
            }
            DlState.DONE -> confirm = true
        }
    })
    if (confirm) {
        ConfirmDialog(
            "Remove downloads?",
            "These songs won't play offline anymore. They stay in your library.",
            "Remove",
            onDismiss = { confirm = false }
        ) {
            val ids = tracks.map { it.videoId }.toHashSet()
            Library.value.downloads.filter { it.track.videoId in ids }.forEach { Downloads.remove(ctx, it, deleteFile = true) }
            actions.message("Downloads removed")
        }
    }
}

/** Grey "Find in playlist" box. */
@Composable
fun FindBar(text: String, onText: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier) {
    Row(
        modifier
            .height(36.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Sc.SurfaceHighest)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = Sc.TextDim, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (text.isEmpty()) Text(placeholder, color = Sc.TextDim, fontSize = 13.sp, maxLines = 1)
            BasicTextField(
                value = text,
                onValueChange = onText,
                singleLine = true,
                textStyle = TextStyle(color = Sc.Text, fontSize = 13.sp),
                cursorBrush = SolidColor(Sc.Accent),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (text.isNotEmpty()) {
            Icon(
                Icons.Rounded.Close, "Clear", tint = Sc.TextDim,
                modifier = Modifier
                    .size(18.dp)
                    .clickable { onText("") }
            )
        }
    }
}

/** Small "Sort: <mode>" pill that cycles through [options]. */
@Composable
fun SortPill(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .height(36.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Sc.SurfaceHighest)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.SwapVert, null, tint = Sc.Text, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Sc.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

enum class SongSort(val label: String) {
    CUSTOM("Custom order"), TITLE("Title"), ARTIST("Artist"), RECENT("Recently added");

    /** Next mode; lists with no manual order (Liked songs) skip "Custom order". */
    fun next(custom: Boolean): SongSort {
        var n = entries[(ordinal + 1) % entries.size]
        if (!custom && n == CUSTOM) n = entries[(n.ordinal + 1) % entries.size]
        return n
    }

    /** [recentFirst]: the stored list already has the newest songs on top. */
    fun order(list: List<Track>, recentFirst: Boolean): List<Track> = when (this) {
        CUSTOM -> list
        TITLE -> list.sortedBy { it.title.lowercase() }
        ARTIST -> list.sortedWith(compareBy({ it.artist.lowercase() }, { it.title.lowercase() }))
        RECENT -> if (recentFirst) list else list.asReversed()
    }
}
