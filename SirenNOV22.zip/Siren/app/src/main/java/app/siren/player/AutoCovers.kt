package app.siren.player

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils

/**
 * Covers for Android Auto that Siren draws itself, so the car's grid looks designed instead of
 * repeating album art: Today's vibe, We think you'd like, the weekly mix, Daily Mixes (on the
 * artist's photo), genre tiles and Shuffle all.
 */
object AutoCovers {
    private const val S = 512
    private const val RED = 0xFFF2294E.toInt()

    private val GENRE_COLORS = intArrayOf(
        0xFFB0306A.toInt(), 0xFF2F6FE0.toInt(), 0xFF6A8D3A.toInt(), 0xFF7B3FB8.toInt(), 0xFFA8442C.toInt(),
        0xFF2E8C8C.toInt(), 0xFFC07A18.toInt(), 0xFF3A4FA8.toInt(), 0xFF8A2E4F.toInt(), 0xFF2F7A4F.toInt()
    )

    fun draw(kind: String, title: String, label: String, seed: Int, photo: Bitmap?): Bitmap {
        val b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        when (kind) {
            "vibe" -> {
                val (a, m, z) = when (seed) {
                    0 -> Triple(0xFFFFC46B.toInt(), 0xFFFF7A45.toInt(), 0xFFB0305A.toInt())   // morning
                    1 -> Triple(0xFFFF9A3C.toInt(), 0xFFC2366B.toInt(), 0xFF3A1450.toInt())   // afternoon
                    2 -> Triple(0xFFE0604A.toInt(), 0xFF7A2A6E.toInt(), 0xFF1C1238.toInt())   // evening
                    else -> Triple(0xFF4A3AA0.toInt(), 0xFF1E1A52.toInt(), 0xFF07070F.toInt()) // late night
                }
                gradient(c, p, intArrayOf(a, m, z))
                small(c, "TODAY'S VIBE")
                big(c, title)
            }
            "foryou" -> {
                gradient(c, p, intArrayOf(0xFF2A5B8A.toInt(), 0xFF142A44.toInt(), 0xFF0A1220.toInt()))
                small(c, "FOR YOU")
                big(c, title)
            }
            "weekly" -> {
                c.drawColor(0xFF000000.toInt())
                drop(c, S / 2f, S * 0.40f, S * 0.46f)
                center(c, title, S * 0.80f)
            }
            "shuffle" -> {
                gradient(c, p, intArrayOf(RED, 0xFFB01236.toInt(), 0xFF5A0A1E.toInt()))
                shuffleGlyph(c, S / 2f, S * 0.40f, S * 0.32f)
                center(c, title, S * 0.80f)
            }
            "mix" -> {
                if (photo != null) {
                    c.drawBitmap(photo, centerCrop(photo), Rect(0, 0, S, S), p)
                } else gradient(c, p, intArrayOf(0xFF3B2A1E.toInt(), 0xFF120C08.toInt(), 0xFF000000.toInt()))
                // Darken the bottom so the label reads
                p.shader = LinearGradient(0f, S * 0.45f, 0f, S.toFloat(), 0x00000000, 0xD8000000.toInt(), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, S.toFloat(), S.toFloat(), p)
                p.shader = null
                drop(c, 54f, 54f, 64f)
                pill(c, label.ifBlank { "MIX" })
                bottom(c, title)
            }
            else -> { // genre
                c.drawColor(GENRE_COLORS[Math.floorMod(seed, GENRE_COLORS.size)])
                // A soft shape in the corner for depth
                p.color = 0x22FFFFFF
                c.drawCircle(S * 0.86f, S * 0.18f, S * 0.36f, p)
                big(c, title)
            }
        }
        return b
    }

    private fun gradient(c: Canvas, p: Paint, colors: IntArray) {
        p.shader = LinearGradient(0f, 0f, S * 0.6f, S.toFloat(), colors, null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, S.toFloat(), S.toFloat(), p)
        p.shader = null
    }

    private fun bold(size: Float, color: Int = 0xFFFFFFFF.toInt()) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        textSize = size
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    private fun small(c: Canvas, text: String) {
        val tp = bold(30f, 0xD9FFFFFF.toInt()).apply { letterSpacing = 0.08f }
        c.drawText(text, 36f, 66f, tp)
    }

    /** Big title at the bottom left, up to 3 lines, shrinks to fit. */
    private fun big(c: Canvas, text: String) {
        var size = 88f
        var l: StaticLayout
        while (true) {
            l = StaticLayout.Builder.obtain(text, 0, text.length, bold(size), S - 72)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).setLineSpacing(0f, 0.92f).setMaxLines(3)
                .setEllipsize(TextUtils.TruncateAt.END).setIncludePad(false).build()
            if (l.height <= S * 0.5f || size <= 44f) break
            size -= 6f
        }
        c.save()
        c.translate(36f, S - 40f - l.height)
        l.draw(c)
        c.restore()
    }

    private fun bottom(c: Canvas, text: String) {
        val tp = bold(44f)
        val l = StaticLayout.Builder.obtain(text, 0, text.length, tp, S - 72)
            .setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END).setIncludePad(false).build()
        c.save()
        c.translate(36f, S - 36f - l.height)
        l.draw(c)
        c.restore()
    }

    private fun center(c: Canvas, text: String, baselineY: Float) {
        val tp = bold(54f).apply { textAlign = Paint.Align.CENTER }
        c.drawText(text, S / 2f, baselineY, tp)
    }

    private fun pill(c: Canvas, text: String) {
        val tp = bold(30f).apply { letterSpacing = 0.04f }
        val w = tp.measureText(text)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = RED }
        val top = S - 200f
        c.drawRoundRect(RectF(32f, top, 32f + w + 32f, top + 50f), 10f, 10f, p)
        c.drawText(text, 48f, top + 36f, tp)
    }

    /** Siren's drop mark, [size] wide, centered at (cx, cy). */
    private fun drop(c: Canvas, cx: Float, cy: Float, size: Float) {
        val u = size / 92f
        fun x(v: Float) = cx + (v - 50f) * u
        fun y(v: Float) = cy + (v - 63.5f) * u
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        val rings = arrayOf(
            floatArrayOf(55f, 20f, 10.5f, 4.6f, 1f),
            floatArrayOf(60f, 31.5f, 16.5f, 3.8f, 0.7f),
            floatArrayOf(65f, 43f, 22.5f, 3.0f, 0.42f)
        )
        for (r in rings) {
            p.color = (((r[4] * 255).toInt() and 0xFF) shl 24) or (RED and 0x00FFFFFF)
            p.strokeWidth = r[3] * u
            c.drawOval(RectF(x(50f) - r[1] * u, y(r[0]) - r[2] * u, x(50f) + r[1] * u, y(r[0]) + r[2] * u), p)
        }
        p.style = Paint.Style.FILL
        p.color = RED
        c.drawCircle(x(50f), y(47f), 8f * u, p)
    }

    private fun shuffleGlyph(c: Canvas, cx: Float, cy: Float, size: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = size * 0.09f
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        val h = size / 2f
        val path = android.graphics.Path().apply {
            moveTo(cx - h, cy - h * 0.55f); lineTo(cx - h * 0.35f, cy - h * 0.55f)
            lineTo(cx + h * 0.45f, cy + h * 0.55f); lineTo(cx + h, cy + h * 0.55f)
            moveTo(cx - h, cy + h * 0.55f); lineTo(cx - h * 0.35f, cy + h * 0.55f)
            lineTo(cx + h * 0.45f, cy - h * 0.55f); lineTo(cx + h, cy - h * 0.55f)
            moveTo(cx + h * 0.72f, cy - h * 0.85f); lineTo(cx + h, cy - h * 0.55f); lineTo(cx + h * 0.72f, cy - h * 0.25f)
            moveTo(cx + h * 0.72f, cy + h * 0.25f); lineTo(cx + h, cy + h * 0.55f); lineTo(cx + h * 0.72f, cy + h * 0.85f)
        }
        c.drawPath(path, p)
    }

    private fun centerCrop(b: Bitmap): Rect {
        val s = minOf(b.width, b.height)
        val x = (b.width - s) / 2
        val y = (b.height - s) / 2
        return Rect(x, y, x + s, y + s)
    }
}
