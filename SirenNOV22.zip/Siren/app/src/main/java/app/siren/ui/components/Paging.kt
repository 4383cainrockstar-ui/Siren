package app.siren.ui.components

import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.siren.core.Paged
import app.siren.core.Music
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.Page

/** Generic "first page, then more on scroll" loader used by every list screen. */
abstract class PagerVm<T> : ViewModel() {
    var items by mutableStateOf<List<T>>(emptyList())
        protected set
    var loading by mutableStateOf(false)
        protected set
    var loadingMore by mutableStateOf(false)
        protected set
    var error by mutableStateOf<String?>(null)
        protected set
    var started = false
        private set
    private var next: Page? = null
    private var job: Job? = null

    val hasMore: Boolean get() = next != null

    protected abstract suspend fun first(): Paged<T>
    protected abstract suspend fun more(page: Page): Paged<T>
    protected open fun keyOf(item: T): Any = item as Any

    fun start() {
        if (started) return
        reload()
    }

    fun reload() {
        started = true
        job?.cancel()
        job = viewModelScope.launch {
            loading = true
            error = null
            try {
                val p = first()
                items = p.items.distinctBy { keyOf(it) }
                next = p.next
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = Music.friendlyError(e)
            } finally {
                loading = false
            }
        }
    }

    fun loadMore() {
        val page = next ?: return
        if (loading || loadingMore) return
        loadingMore = true
        viewModelScope.launch {
            try {
                val p = more(page)
                val seen = items.map { keyOf(it) }.toHashSet()
                items = items + p.items.filter { seen.add(keyOf(it)) }
                next = p.next
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                next = null
            } finally {
                loadingMore = false
            }
        }
    }
}

/** Calls [onEnd] when the user scrolls near the bottom of a list. */
@Composable
fun EndReached(state: LazyListState, buffer: Int = 6, onEnd: () -> Unit) {
    LaunchedEffect(state) {
        snapshotFlow {
            val info = state.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: 0
            info.totalItemsCount > 0 && last >= info.totalItemsCount - buffer
        }.distinctUntilChanged().filter { it }.collect { onEnd() }
    }
}
