package app.siren.player

import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi

/**
 * The player as the outside world sees it: notification, lockscreen, Bluetooth, Android Auto.
 *
 * - Never advertises "seek back / forward 10s". Car screens (Android Auto) show those instead of
 *   skip buttons when they're on offer, which is exactly what we don't want for music.
 * - Always offers next / previous, even on the last song: next keeps the music going with a radio.
 */
@UnstableApi
class SessionPlayer(player: Player) : ForwardingPlayer(player) {

    override fun getAvailableCommands(): Player.Commands {
        val b = super.getAvailableCommands().buildUpon()
            .remove(Player.COMMAND_SEEK_BACK)
            .remove(Player.COMMAND_SEEK_FORWARD)
        if (mediaItemCount > 0) {
            b.addAll(
                Player.COMMAND_SEEK_TO_NEXT,
                Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM,
                Player.COMMAND_SEEK_TO_PREVIOUS,
                Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM
            )
        }
        return b.build()
    }

    override fun isCommandAvailable(command: Int): Boolean = availableCommands.contains(command)

    override fun seekToNext() = PlayerController.next()

    override fun seekToNextMediaItem() = PlayerController.next()

    override fun seekToPrevious() = PlayerController.previous()

    override fun seekToPreviousMediaItem() = PlayerController.previous()
}
