package app.siren.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.media3.common.util.UnstableApi
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import app.siren.core.ArtistRef
import app.siren.core.CollectionRef
import app.siren.core.Entry
import app.siren.ui.screens.ShareItem
import app.siren.core.Music
import app.siren.core.Track
import app.siren.data.Library
import app.siren.download.Downloads
import app.siren.player.PlayerController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

object Routes {
    const val HOME = "home"
    const val SEARCH = "search"
    const val LIBRARY = "library"
    const val ARTIST = "artist/{url}"
    const val COLLECTION = "collection/{url}"
    const val LOCAL = "local/{id}"
    const val FOLDER = "folder/{name}"
    const val LIKED = "liked"
    const val DOWNLOADS = "downloads"
    const val HISTORY = "history"
    const val ARTISTS = "artists"
    const val SAVED = "saved"
    const val SETTINGS = "settings"
    const val EQUALIZER = "equalizer"
    const val DEVICE = "device"

    val tabs = setOf(HOME, SEARCH, LIBRARY)
}

/** Everything a screen can ask the app to do. */
@UnstableApi
class Actions(
    private val nav: NavHostController,
    private val scope: CoroutineScope,
    private val snackbar: SnackbarHostState,
    private val ctx: Context
) {
    fun back() {
        if (!nav.popBackStack()) nav.navigate(Routes.HOME)
    }

    fun open(route: String) {
        UiState.playerOpen.value = false
        nav.navigate(route) { launchSingleTop = true }
    }

    fun tab(route: String) {
        nav.navigate(route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            // Search always comes back fresh (empty box + Recent searches), like Spotify.
            // Home and Your Library keep where you were.
            restoreState = route != Routes.SEARCH
        }
    }

    /** Opens Search and looks up [q]. */
    fun searchFor(q: String) {
        UiState.searchFor.value = q
        UiState.playerOpen.value = false
        tab(Routes.SEARCH)
    }

    fun artist(url: String) {
        if (url.isBlank()) {
            message("No artist page for this one")
            return
        }
        open("artist/" + Uri.encode(url))
    }

    fun collection(url: String) = open("collection/" + Uri.encode(url))

    /** Opens an artist known only by name (e.g. a suggested artist): finds their page first. */
    fun artistNamed(name: String) {
        scope.launch {
            val a = try {
                Music.search(name, Music.ARTISTS).items.filterIsInstance<Entry.Artist>().firstOrNull()?.artist
            } catch (e: Exception) {
                null
            }
            if (a != null) artist(a.url) else message("Couldn't find $name")
        }
    }

    fun local(id: String) = open("local/$id")

    fun folder(name: String) = open("folder/" + Uri.encode(name))

    fun openPlayer() {
        UiState.playerOpen.value = true
    }

    fun play(track: Track, source: String = "") {
        PlayerController.playTrack(track, source)
    }

    fun playAll(tracks: List<Track>, start: Int = 0, shuffle: Boolean = false, source: String = "") {
        if (tracks.isEmpty()) {
            message("Nothing to play")
            return
        }
        PlayerController.playTracks(tracks, start, shuffle, source)
    }

    fun radio(track: Track) {
        PlayerController.playRadio(track)
        message("Starting radio")
    }

    fun download(tracks: List<Track>) {
        val n = Downloads.enqueue(ctx, tracks)
        message(
            when {
                n == 0 -> "Already downloaded"
                n == 1 -> "Downloading"
                else -> "Downloading $n songs"
            }
        )
    }

    /** Opens the share screen (a card made from the cover, then where to send it). */
    fun share(track: Track) {
        UiState.share.value = ShareItem.song(track)
    }

    /** A lyric card: the chosen lines over the song's colors. */
    fun shareLyrics(track: Track, lines: List<String>) {
        if (lines.isEmpty()) return
        UiState.share.value = ShareItem.lyrics(track, lines)
    }

    fun shareCollection(c: CollectionRef) {
        UiState.share.value = ShareItem.collection(c)
    }

    fun shareArtist(a: ArtistRef) {
        UiState.share.value = ShareItem.artist(a)
    }

    /** A playlist made on this phone: collage card plus the song list as text (there's no link). */
    fun shareTracks(name: String, tracks: List<Track>) {
        val lines = tracks.take(100).mapIndexed { i, t -> "${i + 1}. ${t.title} – ${t.artist}".trim() }
        val more = if (tracks.size > 100) "\n…and ${tracks.size - 100} more" else ""
        UiState.share.value = ShareItem.playlist(name, tracks, "$name\n\n" + lines.joinToString("\n") + more)
    }

    fun shareText(text: String) {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Skips the song and hides its artist from suggestions, with Undo. */
    fun hideArtist(track: Track) {
        val key = PlayerController.hideArtist(track)
        if (key.isEmpty()) {
            message("Skipped")
            return
        }
        val name = Library.value.hiddenArtists.firstOrNull { it.key == key }?.name ?: track.artist
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val r = snackbar.showSnackbar("Hiding $name from suggestions", actionLabel = "Undo", duration = SnackbarDuration.Long)
            if (r == SnackbarResult.ActionPerformed) {
                Library.unhideArtist(key)
                message("$name is back")
            }
        }
    }

    fun message(text: String) {
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(text)
        }
    }

    /** Opens any YouTube / YouTube Music link: songs play, the rest opens its page. */
    fun link(raw: String) {
        val url = Music.extractUrl(raw) ?: raw.trim()
        val hasList = Regex("[?&]list=([A-Za-z0-9_-]+)").find(url)?.groupValues?.get(1)
        when (Music.linkKind(url)) {
            Music.LinkKind.SONG -> {
                if (hasList != null && !hasList.startsWith("RD")) {
                    collection("https://www.youtube.com/playlist?list=$hasList")
                    return
                }
                scope.launch {
                    try {
                        val t = Music.track(url)
                        PlayerController.playTrack(t)
                        openPlayer()
                    } catch (e: Exception) {
                        message(Music.friendlyError(e))
                    }
                }
            }
            Music.LinkKind.ARTIST -> artist(url)
            Music.LinkKind.COLLECTION -> collection(url)
            Music.LinkKind.NONE -> message("That link isn't something Siren can open")
        }
    }
}

val LocalActions = staticCompositionLocalOf<Actions> { error("Actions not provided") }
