package app.siren.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.util.UnstableApi
import app.siren.core.Music
import app.siren.data.ImportJob
import app.siren.data.Importer
import app.siren.data.UnsureItem
import app.siren.ui.LocalActions
import app.siren.ui.components.Artwork
import app.siren.ui.components.OutlineButton
import app.siren.ui.theme.Sc

/** Import picker: Spotify (Exportify), YouTube Music (Google Takeout), a link, or a text list. */
@OptIn(ExperimentalMaterial3Api::class)
@UnstableApi
@Composable
fun ImportSheet(onDismiss: () -> Unit) {
    val actions = LocalActions.current
    val ctx = LocalContext.current
    var linkMode by remember { mutableStateOf(false) }
    var link by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        Importer.startFile(ctx, uri)
        actions.message("Reading your file…")
        onDismiss()
    }
    fun pick() = picker.launch(
        arrayOf(
            "text/*", "text/csv", "text/comma-separated-values", "application/csv", "application/vnd.ms-excel",
            "application/zip", "application/x-zip-compressed", "*/*"
        )
    )
    // Imports run in the background with a progress notification, so ask for notifications first.
    // Either answer is fine: without them the import still runs, you just don't see it.
    val askNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { pick() }
    fun start() {
        val needs = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needs) {
            actions.message("Allow notifications to see import progress")
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else pick()
    }

    if (linkMode) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Sc.Sheet,
            title = { Text("Import from a link", color = Sc.Text, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Paste a YouTube or YouTube Music playlist or album link. Any size.", color = Sc.TextDim, fontSize = 14.sp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = link, onValueChange = { link = it }, singleLine = true,
                        placeholder = { Text("https://music.youtube.com/playlist?list=…") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Sc.Text, unfocusedBorderColor = Sc.Outline,
                            focusedTextColor = Sc.Text, unfocusedTextColor = Sc.Text, cursorColor = Sc.Accent
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val url = Music.extractUrl(link) ?: link.trim()
                    val list = Regex("[?&]list=([A-Za-z0-9_-]+)").find(url)?.groupValues?.get(1)
                    if (list == null) {
                        actions.message("That doesn't look like a playlist link")
                        return@TextButton
                    }
                    Importer.startLink(ctx, "https://www.youtube.com/playlist?list=$list")
                    actions.message("Loading the playlist…")
                    onDismiss()
                }) { Text("Import", color = Sc.Accent, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Sc.TextDim) } }
        )
        return
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Sc.Sheet
    ) {
        Column(Modifier.padding(bottom = 28.dp)) {
            Text("Import playlists", color = Sc.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            Text(
                "Runs in the background with no size limit. You can close Siren while it works.",
                color = Sc.TextDim, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp)
            )
            Spacer(Modifier.height(8.dp))
            SourceRow(
                Icons.Rounded.LibraryMusic, "From Spotify",
                "1. Open Exportify and log in with Spotify. 2. Export a playlist, or Export All for a zip. 3. Come back, tap here and pick the file.",
                site = "Open Exportify" to "https://exportify.net"
            ) { start() }
            SourceRow(
                Icons.Rounded.FolderZip, "From YouTube Music",
                "1. Open Google Takeout (YouTube is already picked). 2. Next step → Create export. 3. Google emails you a zip: download it, tap here and pick it. Exact matches, every song.",
                site = "Open Google Takeout" to "https://takeout.google.com/settings/takeout/custom/youtube"
            ) { start() }
            SourceRow(Icons.Rounded.Link, "Paste a YouTube Music link", "Copies a public playlist or album.") { linkMode = true }
            SourceRow(Icons.Rounded.Description, "A text list", "One song per line, like \"Artist - Song\", or YouTube links.") { start() }
        }
    }
}

@Composable
private fun SourceRow(icon: ImageVector, title: String, sub: String, site: Pair<String, String>? = null, onClick: () -> Unit) {
    val ctx = LocalContext.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Sc.TextDim, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Sc.Text, fontSize = 16.sp)
            Text(sub, color = Sc.TextDim, fontSize = 12.sp, lineHeight = 16.sp)
            if (site != null) {
                Spacer(Modifier.height(8.dp))
                OutlineButton(site.first, {
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(site.second)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                    }
                }, icon = Icons.AutoMirrored.Rounded.OpenInNew)
            }
        }
    }
}

/** Progress / results card at the top of a playlist that's being (or was) imported. */
@UnstableApi
@Composable
fun ImportBanner(playlistId: String) {
    val ctx = LocalContext.current
    val jobs by Importer.jobs.collectAsState()
    val job = jobs.firstOrNull { it.playlistId == playlistId } ?: return
    var report by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Sc.SurfaceHigh)
            .padding(14.dp)
    ) {
        val title = when {
            job.running -> "Importing… ${job.next} of ${job.total}"
            job.status == ImportJob.STOPPED && job.next < job.total -> "Import paused at ${job.next} of ${job.total}"
            else -> "Import done: ${job.matched} of ${job.total} added"
        }
        Text(title, color = Sc.Text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        if (job.needsLook > 0) {
            Spacer(Modifier.height(2.dp))
            Text(
                listOfNotNull(
                    job.unsure.size.takeIf { it > 0 }?.let { "$it not sure" },
                    job.missing.size.takeIf { it > 0 }?.let { "$it not found" }
                ).joinToString(" · "),
                color = Sc.TextDim, fontSize = 13.sp
            )
        }
        if (job.running) {
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { if (job.total > 0) job.next.toFloat() / job.total else 0f },
                color = Sc.Accent, trackColor = Sc.SurfaceHighest, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(4.dp))
            Text("Keeps going if you leave the app.", color = Sc.TextFaint, fontSize = 12.sp)
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (job.needsLook > 0) OutlineButton("Review ${job.needsLook}", { report = true }, active = true)
            when {
                job.running -> OutlineButton("Stop", { Importer.stop(job.id) })
                job.status == ImportJob.STOPPED && job.next < job.total -> {
                    OutlineButton("Resume", { Importer.resume(ctx, job.id) }, active = true)
                    OutlineButton("Dismiss", { Importer.dismiss(job.id) })
                }
                else -> OutlineButton("Dismiss", { Importer.dismiss(job.id) })
            }
        }
    }
    if (report) ImportReportSheet(job.id, onDismiss = { report = false })
}

/** "Not sure" matches to accept or skip, and songs that couldn't be found (search for them yourself). */
@OptIn(ExperimentalMaterial3Api::class)
@UnstableApi
@Composable
fun ImportReportSheet(jobId: String, onDismiss: () -> Unit) {
    val actions = LocalActions.current
    val jobs by Importer.jobs.collectAsState()
    val job = jobs.firstOrNull { it.id == jobId }
    if (job == null || job.needsLook == 0) {
        LaunchedEffect(Unit) { onDismiss() }
        return
    }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Sc.Sheet
    ) {
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 640.dp)) {
            if (job.unsure.isNotEmpty()) {
                item(key = "uh") {
                    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Not sure (${job.unsure.size})", color = Sc.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text("Close matches. Add the right ones.", color = Sc.TextDim, fontSize = 13.sp)
                        }
                        TextButton(onClick = { Importer.acceptAllUnsure(job.id) }) { Text("Add all", color = Sc.Accent, fontWeight = FontWeight.Bold) }
                    }
                }
                itemsIndexed(job.unsure, key = { i, _ -> "u$i" }) { _, u -> UnsureRow(job.id, u) }
            }
            if (job.missing.isNotEmpty()) {
                item(key = "mh") {
                    if (job.unsure.isNotEmpty()) HorizontalDivider(color = Sc.Outline, modifier = Modifier.padding(vertical = 8.dp))
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
                        Text("Couldn't find (${job.missing.size})", color = Sc.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Tap search to look for one yourself.", color = Sc.TextDim, fontSize = 13.sp)
                    }
                }
                itemsIndexed(job.missing, key = { i, _ -> "m$i" }) { _, label ->
                    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 4.dp, top = 2.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(label, color = Sc.Text, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        if (!label.startsWith("Video ")) {
                            IconButton(onClick = { onDismiss(); actions.searchFor(label.replace(" – ", " ")) }) {
                                Icon(Icons.Rounded.Search, "Search for it", tint = Sc.TextDim)
                            }
                        }
                        IconButton(onClick = { Importer.forgetMissing(job.id, label) }) {
                            Icon(Icons.Rounded.Close, "Remove from this list", tint = Sc.TextFaint, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
            item(key = "end") { Spacer(Modifier.height(28.dp)) }
        }
    }
}

@Composable
private fun UnsureRow(jobId: String, u: UnsureItem) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Artwork(u.track.thumbnail, Modifier.size(48.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(u.label, color = Sc.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(u.track.title, color = Sc.Text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(u.track.artist, color = Sc.TextDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = { Importer.acceptUnsure(jobId, u) }) { Icon(Icons.Rounded.Check, "Add it", tint = Sc.Accent) }
        IconButton(onClick = { Importer.skipUnsure(jobId, u) }) { Icon(Icons.Rounded.Close, "Not this one", tint = Sc.TextFaint, modifier = Modifier.size(20.dp)) }
    }
}
