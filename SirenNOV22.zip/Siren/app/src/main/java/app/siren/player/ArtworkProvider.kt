package app.siren.player

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import app.siren.BuildConfig
import app.siren.core.Net
import okhttp3.Request
import java.io.File
import java.io.FileNotFoundException
import java.security.MessageDigest

/**
 * Android Auto only loads browse artwork from content:// URIs, not from the web.
 * This hands it album art: the image is fetched once, cached, then served from disk.
 */
class ArtworkProvider : ContentProvider() {

    override fun onCreate(): Boolean = true

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (uri.path == "/made") return made(uri)
        if (uri.path == "/local") {
            // Covers read from music files on the phone (cached by Siren)
            val name = uri.getQueryParameter("f").orEmpty()
            if (name.isBlank() || name.contains('/') || name.contains("..")) throw FileNotFoundException("Bad name")
            val f = File(File(context?.cacheDir ?: throw FileNotFoundException("No context"), "local-art"), name)
            if (!f.exists()) throw FileNotFoundException("No cover")
            return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        }
        val remote = uri.getQueryParameter("u") ?: throw FileNotFoundException("No image")
        val host = Uri.parse(remote).host ?: throw FileNotFoundException("Bad image")
        // Only album / video art, nothing else gets fetched through here
        if (ALLOWED.none { host == it || host.endsWith(".$it") }) throw FileNotFoundException("Not allowed")
        val ctx = context ?: throw FileNotFoundException("No context")
        val dir = File(ctx.cacheDir, "auto-art").apply { mkdirs() }
        val file = File(dir, sha1(remote) + ".img")
        if (!file.exists() || file.length() == 0L) {
            try {
                Net.client.newCall(Request.Builder().url(remote).build()).execute().use { r ->
                    if (!r.isSuccessful) throw FileNotFoundException("HTTP ${r.code}")
                    val tmp = File(dir, file.name + ".tmp")
                    r.body?.byteStream()?.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                    tmp.renameTo(file)
                }
            } catch (e: FileNotFoundException) {
                throw e
            } catch (e: Exception) {
                throw FileNotFoundException(e.message ?: "Download failed")
            }
            trim(dir)
        }
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    /** A cover drawn on the phone (Daily Mix, Today's vibe, weekly mix, genres…), cached as PNG. */
    private fun made(uri: Uri): ParcelFileDescriptor {
        val ctx = context ?: throw FileNotFoundException("No context")
        val dir = File(ctx.cacheDir, "auto-art").apply { mkdirs() }
        val file = File(dir, "made-" + sha1(uri.toString()) + ".png")
        if (!file.exists() || file.length() == 0L) {
            val photoUrl = uri.getQueryParameter("u").orEmpty()
            val photo = if (photoUrl.isNotBlank() && ALLOWED.any { h -> (Uri.parse(photoUrl).host ?: "").let { it == h || it.endsWith(".$h") } }) {
                try {
                    Net.client.newCall(Request.Builder().url(photoUrl).build()).execute().use { r ->
                        if (r.isSuccessful) r.body?.bytes()?.let { android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size) } else null
                    }
                } catch (_: Exception) {
                    null
                }
            } else null
            val bmp = AutoCovers.draw(
                kind = uri.getQueryParameter("k").orEmpty(),
                title = uri.getQueryParameter("t").orEmpty(),
                label = uri.getQueryParameter("l").orEmpty(),
                seed = uri.getQueryParameter("s")?.toIntOrNull() ?: 0,
                photo = photo
            )
            val tmp = File(dir, file.name + ".tmp")
            tmp.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            tmp.renameTo(file)
            trim(dir)
        }
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    private fun trim(dir: File) {
        val files = dir.listFiles()?.sortedBy { it.lastModified() } ?: return
        var total = files.sumOf { it.length() }
        for (f in files) {
            if (total < MAX_BYTES) break
            total -= f.length()
            f.delete()
        }
    }

    override fun getType(uri: Uri): String = if (uri.path == "/made") "image/png" else "image/jpeg"
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0

    companion object {
        private const val MAX_BYTES = 40L * 1024 * 1024
        private val ALLOWED = listOf("ytimg.com", "googleusercontent.com", "ggpht.com", "youtube.com")
        val AUTHORITY: String = BuildConfig.APPLICATION_ID + ".artwork"

        /** content:// URI that serves [url] through this provider. */
        fun uriFor(url: String): Uri? {
            if (url.startsWith("file:") && url.contains("/local-art/")) {
                return Uri.Builder().scheme("content").authority(AUTHORITY).path("local")
                    .appendQueryParameter("f", url.substringAfterLast('/')).build()
            }
            if (url.isBlank() || !url.startsWith("http")) return null
            return Uri.Builder().scheme("content").authority(AUTHORITY).path("art").appendQueryParameter("u", url).build()
        }

        /**
         * content:// URI for a cover Siren draws itself. [kind]: vibe, foryou, weekly, mix, genre,
         * shuffle. [photo] is an optional picture to build it on (an artist for mixes).
         */
        fun madeUri(kind: String, title: String, label: String = "", seed: Int = 0, photo: String = ""): Uri =
            Uri.Builder().scheme("content").authority(AUTHORITY).path("made")
                .appendQueryParameter("k", kind)
                .appendQueryParameter("t", title)
                .appendQueryParameter("l", label)
                .appendQueryParameter("s", seed.toString())
                .apply { if (photo.isNotBlank()) appendQueryParameter("u", photo) }
                .appendQueryParameter("v", "1")
                .build()

        private fun sha1(s: String): String =
            MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
