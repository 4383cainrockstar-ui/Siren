package app.siren.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddCircleOutline
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.foundation.layout.size
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer

/**
 * Click that shrinks a touch while pressed (like Spotify's covers and tiles). The scale runs on
 * the graphics layer, so nothing re-lays out and it stays smooth.
 */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.pressClick(
    scale: Float = 0.96f,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) scale else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(interactionSource = src, indication = null, onLongClick = onLongClick, onClick = onClick)
}

/**
 * The like button's icon. Liking pops it (quick grow and settle with a little bounce);
 * unliking just swaps back.
 */
@androidx.compose.runtime.Composable
fun LikeIcon(liked: Boolean, size: androidx.compose.ui.unit.Dp, idleTint: androidx.compose.ui.graphics.Color) {
    val pop = remember { androidx.compose.animation.core.Animatable(1f) }
    val first = remember { booleanArrayOf(true) }
    androidx.compose.runtime.LaunchedEffect(liked) {
        if (first[0]) {
            first[0] = false
            return@LaunchedEffect
        }
        if (liked) {
            pop.snapTo(0.6f)
            pop.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = Spring.StiffnessMediumLow))
        }
    }
    androidx.compose.material3.Icon(
        if (liked) Icons.Rounded.CheckCircle else Icons.Rounded.AddCircleOutline,
        if (liked) "Remove from Liked songs" else "Add to Liked songs",
        tint = if (liked) app.siren.ui.theme.Sc.Accent else idleTint,
        modifier = Modifier
            .graphicsLayer { scaleX = pop.value; scaleY = pop.value }
            .then(Modifier.size(size))
    )
}
