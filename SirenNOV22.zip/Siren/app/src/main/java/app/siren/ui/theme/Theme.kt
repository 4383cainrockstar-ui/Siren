package app.siren.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Siren palette: true black, neutral greys, white type and one accent (siren red) that's
 * only used for things that are "on": play, liked, downloaded, toggles, progress.
 */
object Sc {
    /** Pure OLED mode: cards, menus and tints go true black too. Set at startup and when toggled. */
    @Volatile var oled = false

    val Bg = Color(0xFF000000)
    val Surface get() = if (oled) Color(0xFF050505) else Color(0xFF121212)
    val SurfaceHigh get() = if (oled) Color(0xFF0C0C0C) else Color(0xFF1F1F1F)
    val SurfaceHighest get() = if (oled) Color(0xFF181818) else Color(0xFF2A2A2A)
    val Sheet get() = if (oled) Color(0xFF000000) else Color(0xFF181818)
    val Outline get() = if (oled) Color(0xFF2A2A2A) else Color(0xFF2E2E2E)
    val Divider get() = if (oled) Color(0xFF161616) else Color(0xFF1C1C1C)

    val Text = Color(0xFFFFFFFF)
    val TextDim = Color(0xFFB3B3B3)
    val TextFaint = Color(0xFF7A7A7A)

    val Accent = Color(0xFFF2294E)
    val AccentBright = Color(0xFFFF4D6D)
    val AccentDeep = Color(0xFF9E0F2C)
    val Error = Color(0xFFFF5C5C)

    /** Liked songs cover: the only gradient in the app, so it reads as "yours". */
    val likedCover = Brush.linearGradient(listOf(Color(0xFFFF3B5C), Color(0xFF5B0A1E)))
    val downloadsCover = Brush.linearGradient(listOf(Color(0xFF3A3A3A), Color(0xFF121212)))

    /** Muted, solid colors for genre tiles and placeholders. */
    val tiles = listOf(
        Color(0xFFB0233F), Color(0xFF3D4BA8), Color(0xFF1F7A5C), Color(0xFFB4561E),
        Color(0xFF6B3FA0), Color(0xFF1E6E9C), Color(0xFF8A2B6E), Color(0xFF52693A),
        Color(0xFF9C3B2E), Color(0xFF2F5E8C), Color(0xFF7A5A1E), Color(0xFF4A4A6A)
    )

    fun tile(seed: String): Color = tiles[(seed.hashCode() and 0x7fffffff) % tiles.size]
}

private fun scheme() = darkColorScheme(
    primary = Sc.Accent,
    onPrimary = Color.White,
    primaryContainer = Sc.AccentDeep,
    onPrimaryContainer = Color.White,
    secondary = Sc.Text,
    onSecondary = Color.Black,
    secondaryContainer = Sc.SurfaceHighest,
    onSecondaryContainer = Sc.Text,
    tertiary = Sc.AccentBright,
    background = Sc.Bg,
    onBackground = Sc.Text,
    surface = Sc.Bg,
    onSurface = Sc.Text,
    surfaceVariant = Sc.SurfaceHigh,
    onSurfaceVariant = Sc.TextDim,
    surfaceContainer = Sc.Surface,
    surfaceContainerHigh = Sc.Sheet,
    surfaceContainerHighest = Sc.SurfaceHighest,
    surfaceContainerLow = Sc.Surface,
    surfaceContainerLowest = Sc.Bg,
    outline = Sc.Outline,
    outlineVariant = Sc.Divider,
    error = Sc.Error
)

private val base = Typography()
private val typography = Typography(
    displaySmall = base.displaySmall.copy(fontWeight = FontWeight.Black, letterSpacing = (-1.2).sp),
    headlineLarge = base.headlineLarge.copy(fontWeight = FontWeight.Black, letterSpacing = (-0.8).sp),
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
    headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.3).sp),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.Bold),
    titleSmall = base.titleSmall.copy(fontWeight = FontWeight.SemiBold),
    bodyLarge = base.bodyLarge,
    bodyMedium = base.bodyMedium,
    bodySmall = base.bodySmall,
    labelLarge = base.labelLarge.copy(fontWeight = FontWeight.Bold),
    labelMedium = base.labelMedium.copy(fontWeight = FontWeight.SemiBold),
    labelSmall = base.labelSmall
)

@Composable
fun SirenTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme(), typography = typography, content = content)
}
