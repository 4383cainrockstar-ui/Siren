package app.siren.ui.components

import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.siren.ui.theme.Sc

/**
 * Page layout for albums, playlists, Liked songs and Downloads: a list with a top bar that
 * fades in (tinted with the cover color) once the header scrolls away.
 */
@Composable
fun ListPage(
    state: LazyListState,
    title: String,
    tint: Color,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    topActions: @Composable RowScope.() -> Unit = {},
    overlay: @Composable BoxScope.() -> Unit = {},
    content: LazyListScope.() -> Unit
) {
    val density = LocalDensity.current
    val fadeAfter = with(density) { 260.dp.toPx() }
    val barAlpha by remember(state) {
        derivedStateOf {
            if (state.firstVisibleItemIndex > 0) 1f
            else (state.firstVisibleItemScrollOffset / fadeAfter).coerceIn(0f, 1f)
        }
    }
    // How far the header has scrolled (the big cover shrinks and fades with it)
    val headerOffset = remember(state) {
        derivedStateOf { if (state.firstVisibleItemIndex == 0) state.firstVisibleItemScrollOffset.toFloat() else 100000f }
    }
    Box(modifier.fillMaxSize()) {
        CompositionLocalProvider(LocalHeaderOffset provides headerOffset) {
            LazyColumn(state = state, modifier = Modifier.fillMaxSize().fastScroll(state), contentPadding = PaddingValues(bottom = 24.dp), content = content)
        }
        Box(
            Modifier
                .fillMaxWidth()
                .background(tint.copy(alpha = 0.55f).compositeOver(Sc.Bg).copy(alpha = barAlpha))
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .height(56.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Sc.Text) }
                Text(
                    title,
                    color = Sc.Text,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .weight(1f)
                        .alpha(barAlpha)
                )
                topActions()
            }
        }
        overlay()
    }
}

/** Cover, title, owner and details over a gradient made from the cover's color. */
@Composable
fun ListHeader(
    title: String,
    owner: String,
    meta: String,
    tint: Color,
    cover: @Composable () -> Unit,
    coverSize: Dp = 236.dp
) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(tint, tint.copy(alpha = 0.35f).compositeOver(Sc.Bg), Sc.Bg)))
            .statusBarsPadding()
            .padding(top = 56.dp, start = 16.dp, end = 16.dp)
    ) {
        val scrolled = LocalHeaderOffset.current
        val coverPx = with(LocalDensity.current) { coverSize.toPx() }
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    // Spotify-style: as you scroll, the cover lags behind, shrinks and fades.
                    // Read in the draw phase only, so scrolling never recomposes the header.
                    .graphicsLayer {
                        val off = scrolled?.value ?: 0f
                        val f = (off / coverPx).coerceIn(0f, 1f)
                        val s = 1f - 0.3f * f
                        scaleX = s
                        scaleY = s
                        translationY = off.coerceAtMost(coverPx) * 0.55f
                        alpha = 1f - 0.9f * f
                    }
                    .size(coverSize)
                    .shadow(24.dp, RoundedCornerShape(4.dp), ambientColor = Color.Black, spotColor = Color.Black)
            ) { cover() }
        }
        Spacer(Modifier.height(22.dp))
        Text(
            title,
            color = Sc.Text,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.5).sp,
            lineHeight = 28.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        if (owner.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                SirenMark(size = 18.dp)
                Spacer(Modifier.width(6.dp))
                Text(owner, color = Sc.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (meta.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(meta, color = Sc.TextDim, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

/**
 * The row under a header: small actions on the left (download, save, more…), shuffle and
 * a big play button on the right.
 */
@Composable
fun ActionRow(
    playing: Boolean,
    shuffle: Boolean,
    onShuffle: () -> Unit,
    onPlay: () -> Unit,
    left: @Composable RowScope.() -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 4.dp, end = 16.dp, top = 4.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start
    ) {
        left()
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onShuffle) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(6.dp))
                Icon(Icons.Rounded.Shuffle, if (shuffle) "Shuffle on" else "Shuffle off", tint = if (shuffle) Sc.Accent else Sc.TextDim, modifier = Modifier.size(28.dp))
                Spacer(Modifier.height(2.dp))
                Box(
                    Modifier
                        .size(4.dp)
                        .background(if (shuffle) Sc.Accent else Color.Transparent, RoundedCornerShape(50))
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        PlayFab(playing, onPlay)
    }
}

/** Scroll offset of the list's first item, for headers that react to scrolling. */
val LocalHeaderOffset = androidx.compose.runtime.staticCompositionLocalOf<androidx.compose.runtime.State<Float>?> { null }
