package app.siren.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.KeyEvent
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.drawable.toBitmap
import androidx.media3.common.util.UnstableApi
import androidx.palette.graphics.Palette
import app.siren.MainActivity
import app.siren.R
import app.siren.core.Track
import app.siren.core.hiRes
import app.siren.data.Library
import app.siren.player.PlaybackService
import app.siren.player.PlayerController
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 4x1 home screen widget: cover, song, artist, previous / play / next. */
@UnstableApi
class SirenWidgetSmall : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.refreshAsync(this, context)
}

/** 4x2 home screen widget: big cover, song, artist, like, previous / play / next. */
@UnstableApi
class SirenWidgetLarge : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.refreshAsync(this, context)
}

/** Receives the widget's button taps. */
@UnstableApi
class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Widgets.handle(context, intent.action ?: return)
    }
}

/**
 * Draws the widgets and keeps them in sync with the player. Everything's plain RemoteViews,
 * so it works on every launcher.
 */
@UnstableApi
@OptIn(FlowPreview::class)
object Widgets {
    private const val ACTION_PLAY = "app.siren.widget.PLAY"
    private const val ACTION_NEXT = "app.siren.widget.NEXT"
    private const val ACTION_PREV = "app.siren.widget.PREV"
    private const val ACTION_LIKE = "app.siren.widget.LIKE"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val defaultTint = Color.rgb(0x18, 0x18, 0x18)

    // Last cover we drew, so a play/pause tap doesn't reload the image
    private var artFor = ""
    private var art: Bitmap? = null
    private var tint = defaultTint

    /** Called once from the app: redraw whenever the song, play state or like changes. */
    fun init(ctx: Context) {
        val app = ctx.applicationContext
        scope.launch {
            val liked = combine(PlayerController.current, Library.data) { t, lib ->
                t != null && lib.liked.any { it.videoId == t.videoId }
            }
            combine(PlayerController.current, PlayerController.isPlaying, liked) { t, p, l -> Triple(t?.videoId, p, l) }
                .distinctUntilChanged()
                .debounce(150)
                .collect { render(app) }
        }
    }

    fun refreshAsync(receiver: BroadcastReceiver, ctx: Context) {
        val pending = receiver.goAsync()
        scope.launch {
            try {
                render(ctx.applicationContext)
            } finally {
                pending.finish()
            }
        }
    }

    fun handle(ctx: Context, action: String) {
        val p = PlayerController.player
        when (action) {
            ACTION_PLAY -> when {
                p.isPlaying -> p.pause()
                p.mediaItemCount == 0 -> openApp(ctx)
                else -> startPlaying(ctx)
            }
            ACTION_NEXT -> PlayerController.next()
            ACTION_PREV -> PlayerController.previous()
            ACTION_LIKE -> PlayerController.current.value?.let { Library.toggleLike(it) }
        }
    }

    /**
     * Play from the widget. The playback service has to be up for the notification and to keep
     * Siren alive in the background, so wake it with a "play" media button when it isn't.
     */
    private fun startPlaying(ctx: Context) {
        if (PlaybackService.running) {
            PlayerController.togglePlay()
            return
        }
        // Restored queues aren't prepared until you press play; get the stream loading now
        val p = PlayerController.player
        if (p.playbackState == androidx.media3.common.Player.STATE_IDLE) p.prepare()
        val intent = Intent(ctx, PlaybackService::class.java)
            .setAction(Intent.ACTION_MEDIA_BUTTON)
            .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY))
        try {
            ContextCompat.startForegroundService(ctx, intent)
        } catch (e: Exception) {
            // Android refused to start it from the background: play anyway
            PlayerController.togglePlay()
        }
    }

    private fun openApp(ctx: Context) {
        try {
            ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------------------------------
    // Drawing
    // ---------------------------------------------------------------------------------------

    suspend fun render(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx) ?: return
        val small = mgr.getAppWidgetIds(ComponentName(ctx, SirenWidgetSmall::class.java))
        val large = mgr.getAppWidgetIds(ComponentName(ctx, SirenWidgetLarge::class.java))
        if (small.isEmpty() && large.isEmpty()) return

        val t = PlayerController.current.value
        val playing = PlayerController.isPlaying.value
        val liked = t != null && Library.isLiked(t)
        if (t == null) {
            artFor = ""
            art = null
            tint = defaultTint
        } else if (t.thumbnail != artFor) {
            artFor = t.thumbnail
            val loaded = loadArt(ctx, t)
            art = loaded?.first
            tint = loaded?.second ?: defaultTint
        }

        if (small.isNotEmpty()) mgr.updateAppWidget(small, build(ctx, R.layout.widget_small, t, playing, liked, large = false))
        if (large.isNotEmpty()) mgr.updateAppWidget(large, build(ctx, R.layout.widget_large, t, playing, liked, large = true))
    }

    private fun build(ctx: Context, layout: Int, t: Track?, playing: Boolean, liked: Boolean, large: Boolean): RemoteViews {
        val v = RemoteViews(ctx.packageName, layout)
        v.setInt(R.id.widget_bg, "setColorFilter", tint)
        v.setTextViewText(R.id.widget_title, t?.title ?: "Siren")
        v.setTextViewText(R.id.widget_artist, t?.artist?.ifBlank { "Unknown artist" } ?: "Tap to start listening")

        val bmp = art
        if (bmp != null) v.setImageViewBitmap(R.id.widget_art, bmp)
        else v.setImageViewResource(R.id.widget_art, R.drawable.widget_art_placeholder)

        v.setImageViewResource(R.id.widget_play, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        v.setContentDescription(R.id.widget_play, if (playing) "Pause" else "Play")

        val openPlayer = PendingIntent.getActivity(
            ctx, 40,
            Intent(ctx, MainActivity::class.java)
                .setAction(if (t != null) MainActivity.ACTION_OPEN_PLAYER else Intent.ACTION_MAIN)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        v.setOnClickPendingIntent(R.id.widget_art, openPlayer)
        v.setOnClickPendingIntent(R.id.widget_open, openPlayer)
        // Nothing queued yet: play opens the app instead
        v.setOnClickPendingIntent(R.id.widget_play, if (t == null) openPlayer else action(ctx, ACTION_PLAY, 41))
        v.setOnClickPendingIntent(R.id.widget_next, action(ctx, ACTION_NEXT, 42))
        v.setOnClickPendingIntent(R.id.widget_prev, action(ctx, ACTION_PREV, 43))

        if (large) {
            v.setImageViewResource(R.id.widget_like, if (liked) R.drawable.ic_w_heart_filled else R.drawable.ic_w_heart)
            v.setContentDescription(R.id.widget_like, if (liked) "Remove from Liked songs" else "Add to Liked songs")
            v.setOnClickPendingIntent(R.id.widget_like, action(ctx, ACTION_LIKE, 44))
        }
        return v
    }

    private fun action(ctx: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, WidgetActionReceiver::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    /** Rounded, square cover + a dark tint pulled from it for the background. */
    private suspend fun loadArt(ctx: Context, t: Track): Pair<Bitmap, Int>? {
        if (t.thumbnail.isBlank()) return null
        return try {
            val req = ImageRequest.Builder(ctx)
                .data(hiRes(t.thumbnail, 300))
                .size(300)
                .allowHardware(false)
                .build()
            val result = ctx.imageLoader.execute(req) as? SuccessResult ?: return null
            withContext(Dispatchers.Default) {
                val src = result.drawable.toBitmap()
                val square = squareCrop(src, videoThumb = t.thumbnail.contains("i.ytimg.com"))
                val sized = Bitmap.createScaledBitmap(square, 256, 256, true)
                val rounded = rounded(sized, 26f)
                rounded to tintFrom(sized)
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Video thumbnails are 4:3 with black bars around a 16:9 picture: crop to the picture. */
    private fun squareCrop(src: Bitmap, videoThumb: Boolean): Bitmap {
        val w = src.width
        val h = src.height
        var side = minOf(w, h)
        if (videoThumb && w * 3 == h * 4) side = (w * 9 / 16).coerceAtMost(h)
        val x = (w - side) / 2
        val y = (h - side) / 2
        return Bitmap.createBitmap(src, x, y, side, side)
    }

    private fun rounded(src: Bitmap, radius: Float): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).apply { setLocalMatrix(Matrix()) }
        }
        Canvas(out).drawRoundRect(RectF(0f, 0f, src.width.toFloat(), src.height.toFloat()), radius, radius, paint)
        return out
    }

    private fun tintFrom(bmp: Bitmap): Int {
        val p = Palette.from(bmp).generate()
        val base = p.darkVibrantSwatch?.rgb ?: p.vibrantSwatch?.rgb ?: p.darkMutedSwatch?.rgb ?: p.dominantSwatch?.rgb ?: return defaultTint
        // Darken it so white text always reads, like the mini player
        return ColorUtils.blendARGB(base, Color.BLACK, 0.45f)
    }
}
