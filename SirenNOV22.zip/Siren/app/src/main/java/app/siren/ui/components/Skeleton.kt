package app.siren.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.siren.ui.theme.Sc

/*
 * Gray stand-ins that pulse while a page loads, so screens never sit empty.
 * One pulse per group (graphicsLayer alpha, no recomposition per frame).
 */

@Composable
private fun pulseAlpha(): Float {
    val t = rememberInfiniteTransition(label = "skeleton")
    val a by t.animateFloat(0.45f, 1f, infiniteRepeatable(tween(750, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "skeletonAlpha")
    return a
}

@Composable
fun Bone(modifier: Modifier, shape: Shape = RoundedCornerShape(6.dp)) {
    Box(modifier.clip(shape).background(Sc.SurfaceHighest))
}

@Composable
private fun Pulsing(content: @Composable () -> Unit) {
    val a = pulseAlpha()
    Box(Modifier.graphicsLayer { alpha = a }) { content() }
}

/** Rows like a song list. */
@Composable
fun SkeletonRows(count: Int = 8, modifier: Modifier = Modifier) {
    Pulsing {
        Column(modifier.fillMaxWidth()) {
            repeat(count) { i ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Bone(Modifier.size(48.dp), RoundedCornerShape(4.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Bone(Modifier.fillMaxWidth(if (i % 3 == 0) 0.7f else if (i % 3 == 1) 0.55f else 0.8f).height(14.dp))
                        Spacer(Modifier.height(8.dp))
                        Bone(Modifier.fillMaxWidth(0.4f).height(11.dp))
                    }
                }
            }
        }
    }
}

/** A section title with a row of square cards. */
@Composable
fun SkeletonShelf(square: Dp = 150.dp, circles: Boolean = false) {
    Pulsing {
        Column(Modifier.fillMaxWidth().padding(top = 18.dp)) {
            Bone(Modifier.padding(start = 16.dp).width(170.dp).height(20.dp))
            Spacer(Modifier.height(14.dp))
            Row(Modifier.padding(start = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                repeat(3) {
                    Column {
                        Bone(Modifier.size(square), if (circles) CircleShape else RoundedCornerShape(6.dp))
                        Spacer(Modifier.height(10.dp))
                        Bone(Modifier.width(square * 0.75f).height(12.dp))
                        Spacer(Modifier.height(6.dp))
                        Bone(Modifier.width(square * 0.5f).height(10.dp))
                    }
                }
            }
        }
    }
}

/** Home's big card (Today's vibe). */
@Composable
fun SkeletonCard() {
    Pulsing {
        Bone(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp).height(124.dp), RoundedCornerShape(10.dp))
    }
}

/** Album / playlist / artist page header: big cover, title, subtitle, then songs. */
@Composable
fun SkeletonPage(round: Boolean = false) {
    Column(Modifier.fillMaxWidth()) {
        Pulsing {
            Column(Modifier.fillMaxWidth().padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Bone(Modifier.size(220.dp), if (round) CircleShape else RoundedCornerShape(6.dp))
                Spacer(Modifier.height(20.dp))
                Bone(Modifier.width(200.dp).height(22.dp))
                Spacer(Modifier.height(10.dp))
                Bone(Modifier.width(130.dp).height(13.dp))
                Spacer(Modifier.height(18.dp))
            }
        }
        SkeletonRows(6)
    }
}
