package app.siren

import app.siren.data.LocalMusic
import app.siren.data.Explicit
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.media3.common.util.UnstableApi
import app.siren.core.Music
import app.siren.core.Net
import app.siren.data.Importer
import app.siren.data.Library
import app.siren.data.Settings
import app.siren.download.Downloads
import app.siren.player.PlayerController
import app.siren.widget.Widgets
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache

@UnstableApi
class SirenApp : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        Settings.init(this)
        app.siren.ui.theme.Sc.oled = Settings.current.pureOled
        Library.init(this)
        Explicit.init(this)
        LocalMusic.init(this)
        Importer.init(this)
        Music.init()
        createChannels()
        PlayerController.init(this)
        Widgets.init(this)
        Downloads.markInterrupted()
        app.siren.player.WeeklyMix.ensureFresh()
        // "Download liked songs": every song you like gets saved for offline
        Library.onLiked = { t -> if (Settings.current.autoDownloadLikes) Downloads.enqueue(this, listOf(t)) }
        Library.onLikedMany = { list -> if (Settings.current.autoDownloadLikes) Downloads.enqueue(this, list) }
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .okHttpClient(Net.client)
            .crossfade(true)
            .diskCache {
                // Bigger artwork cache so album art still shows offline
                DiskCache.Builder()
                    .directory(cacheDir.resolve("artwork"))
                    .maxSizeBytes(200L * 1024 * 1024)
                    .build()
            }
            .respectCacheHeaders(false)
            .build()

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_DOWNLOADS, "Downloads", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_IMPORTS, "Playlist imports", NotificationManager.IMPORTANCE_LOW)
        )
    }

    companion object {
        const val CHANNEL_DOWNLOADS = "downloads"
        const val CHANNEL_IMPORTS = "imports"
    }
}
