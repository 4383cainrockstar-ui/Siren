package app.siren.player

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import app.siren.data.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/** What the phone's equalizer can do: band centers, level range, built-in presets. */
data class EqInfo(
    val centersHz: List<Int>,
    val minMb: Int,
    val maxMb: Int,
    val presets: List<String>,
    val bassBoost: Boolean
)

/**
 * Siren's own equalizer: Android's audio effects attached to the player's audio session, with
 * the levels kept in Settings so they come back every time.
 */
object Eq {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var session = 0
    private var watching = false

    private val _info = MutableStateFlow<EqInfo?>(null)
    /** Null until the effects attach (or if this phone doesn't have them). */
    val info: StateFlow<EqInfo?> = _info.asStateFlow()

    /** Called with the player's audio session (at start and whenever it changes). */
    fun attach(sessionId: Int) {
        if (sessionId <= 0 || sessionId == session) return
        release()
        session = sessionId
        try {
            val e = Equalizer(0, sessionId)
            eq = e
            val range = e.bandLevelRange
            val bands = e.numberOfBands.toInt()
            val presets = (0 until e.numberOfPresets.toInt()).map { e.getPresetName(it.toShort()) }
            val b = try {
                BassBoost(0, sessionId).takeIf { it.strengthSupported }
            } catch (_: Exception) {
                null
            }
            bass = b
            _info.value = EqInfo(
                centersHz = (0 until bands).map { e.getCenterFreq(it.toShort()) / 1000 },
                minMb = range[0].toInt(),
                maxMb = range[1].toInt(),
                presets = presets,
                bassBoost = b != null
            )
        } catch (_: Throwable) {
            // Some phones don't allow app-level effects
            release()
            _info.value = null
        }
        apply()
        if (!watching) {
            watching = true
            scope.launch {
                Settings.state
                    .map { listOf(it.eqEnabled, it.eqBands, it.eqBass) }
                    .distinctUntilChanged()
                    .collect { apply() }
            }
        }
    }

    /** Levels for a built-in preset, so it can be shown on the curve and then tweaked. */
    fun presetLevels(index: Int): List<Int>? {
        val e = eq ?: return null
        return try {
            e.usePreset(index.toShort())
            (0 until e.numberOfBands.toInt()).map { e.getBandLevel(it.toShort()).toInt() }
        } catch (_: Exception) {
            null
        }
    }

    /** Live levels while dragging, before they're saved. */
    fun preview(levels: List<Int>, enabled: Boolean) {
        val e = eq ?: return
        try {
            val range = e.bandLevelRange
            levels.forEachIndexed { i, l ->
                if (i < e.numberOfBands) e.setBandLevel(i.toShort(), l.coerceIn(range[0].toInt(), range[1].toInt()).toShort())
            }
            e.enabled = enabled
        } catch (_: Exception) {
        }
    }

    private fun apply() {
        val s = Settings.current
        val e = eq
        if (e != null) {
            try {
                val bands = e.numberOfBands.toInt()
                val range = e.bandLevelRange
                for (i in 0 until bands) {
                    val level = (s.eqBands.getOrNull(i) ?: 0).coerceIn(range[0].toInt(), range[1].toInt())
                    e.setBandLevel(i.toShort(), level.toShort())
                }
                e.enabled = s.eqEnabled
            } catch (_: Exception) {
            }
        }
        bass?.let { b ->
            try {
                b.setStrength(s.eqBass.coerceIn(0, 1000).toShort())
                b.enabled = s.eqEnabled && s.eqBass > 0
            } catch (_: Exception) {
            }
        }
    }

    private fun release() {
        try {
            eq?.release()
        } catch (_: Exception) {
        }
        try {
            bass?.release()
        } catch (_: Exception) {
        }
        eq = null
        bass = null
        session = 0
    }
}
