package app.siren.ui.screens

import app.siren.ui.components.SkeletonPage
import app.siren.ui.components.SkeletonRows
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.AddCircleOutline
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Radio
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import app.siren.core.ArtistPage
import app.siren.core.ArtistRef
import app.siren.core.CollectionHeader
import app.siren.core.CollectionRef
import app.siren.core.Entry
import app.siren.core.Fmt
import app.siren.core.Music
import app.siren.core.Paged
import app.siren.core.Track
import app.siren.core.hiRes
import app.siren.data.DownloadRecord
import app.siren.data.Library
import app.siren.player.PlayerController
import app.siren.player.RelArtist
import app.siren.player.Station
import app.siren.player.Stations
import app.siren.ui.LocalActions
import app.siren.ui.components.ActionRow
import app.siren.ui.components.ArtistCircle
import app.siren.ui.components.AddToPlaylistDialog
import app.siren.ui.components.Artwork
import app.siren.ui.components.Avatar
import app.siren.ui.components.EmptyState
import app.siren.ui.components.EndReached
import app.siren.ui.components.ErrorBox
import app.siren.ui.components.FollowButton
import app.siren.ui.components.ListDownloadButton
import app.siren.ui.components.SelectionOverlay
import app.siren.ui.components.rememberSongSelection
import app.siren.ui.components.ListHeader
import app.siren.ui.components.ListPage
import app.siren.ui.components.Loading
import app.siren.ui.components.OutlineButton
import app.siren.ui.components.PagerVm
import app.siren.ui.components.SectionHeader
import app.siren.ui.components.SheetRow
import app.siren.ui.components.SquareCard
import app.siren.ui.components.TrackActionsSheet
import app.siren.ui.components.TrackRow
import app.siren.ui.components.rememberArtColor
import app.siren.ui.components.shelf
import app.siren.ui.theme.Sc
import coil.compose.AsyncImage
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabs

// =============================================================================================
// Album / playlist from YouTube Music
// =============================================================================================

class CollectionVm : PagerVm<Track>() {
    var url = ""
        private set
    var header by mutableStateOf<CollectionHeader?>(null)
        private set

    fun open(u: String) {
        if (u == url && started) return
        url = u
        reload()
    }

    override suspend fun first(): Paged<Track> {
        val (h, page) = Music.collection(url)
        header = h
        return page
    }

    override suspend fun more(page: Page): Paged<Track> = Music.collectionMore(url, page)
    override fun keyOf(item: Track): Any = item.videoId

    /** Everything, for Play / Shuffle / Download all on long playlists. */
    suspend fun everything(): List<Track> {
        if (!hasMore) return items
        return try {
            Music.allTracks(url).second
        } catch (e: Exception) {
            items
        }
    }
}

@UnstableApi
@Composable
fun CollectionScreen(url: String) {
    val actions = LocalActions.current
    val vm: CollectionVm = viewModel(key = "col:$url")
    val lib by Library.data.collectAsState()
    val current by PlayerController.current.collectAsState()
    val playing by PlayerController.isPlaying.collectAsState()
    val currentSource by PlayerController.source.collectAsState()
    val playerShuffle by PlayerController.shuffle.collectAsState()
    val listState = rememberLazyListState()
    var menuFor by remember { mutableStateOf<Track?>(null) }
    var more by remember { mutableStateOf(false) }
    var addAll by remember { mutableStateOf<List<Track>?>(null) }
    var localShuffle by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val sel = rememberSongSelection()
    LaunchedEffect(url) { vm.open(url) }
    EndReached(listState) { vm.loadMore() }

    val h = vm.header
    val err = vm.error
    val saved = lib.saved.any { it.url == url || (h != null && it.url == h.ref.url) }
    val name = h?.ref?.name ?: ""
    val tint = rememberArtColor(h?.ref?.thumbnail ?: "", Sc.SurfaceHighest)
    val here = current != null && name.isNotBlank() && currentSource == name
    val shuffle = if (here) playerShuffle else localShuffle
    val doneIds = remember(lib.downloads) {
        lib.downloads.filter { it.status == DownloadRecord.STATUS_DONE }.map { it.track.videoId }.toHashSet()
    }

    fun withAll(block: (List<Track>) -> Unit) {
        scope.launch { block(vm.everything()) }
    }

    ListPage(
        listState, name, tint, onBack = { actions.back() },
        overlay = { SelectionOverlay(sel, vm.items) }
    ) {
        if (h != null) {
            item(key = "header") {
                val count = if (h.ref.count > 0) h.ref.count.toInt() else vm.items.size
                ListHeader(
                    title = h.ref.name,
                    owner = h.ref.author,
                    meta = listOf(
                        if (h.ref.isAlbum) "Album" else "Playlist",
                        Fmt.songs(count),
                        if (!vm.hasMore) Fmt.totalMinutes(vm.items) else ""
                    ).filter { it.isNotBlank() }.joinToString(" • "),
                    tint = tint,
                    cover = {
                        Artwork(
                            h.ref.thumbnail, Modifier.fillMaxSize(),
                            icon = if (h.ref.isAlbum) Icons.Rounded.Album else Icons.AutoMirrored.Rounded.QueueMusic,
                            big = true
                        )
                    }
                )
            }
            item(key = "actions") {
                val count = if (h.ref.count > 0) h.ref.count.toInt() else vm.items.size
                ActionRow(
                    playing = here && playing,
                    shuffle = shuffle,
                    onShuffle = { if (here) PlayerController.toggleShuffle() else localShuffle = !localShuffle },
                    onPlay = {
                        if (here) PlayerController.togglePlay()
                        else withAll { actions.playAll(it, shuffle = shuffle, source = h.ref.name) }
                    }
                ) {
                    IconButton(onClick = { Library.toggleSaved(h.ref.copy(count = count.toLong())) }) {
                        Icon(
                            if (saved) Icons.Rounded.CheckCircle else Icons.Rounded.AddCircleOutline,
                            if (saved) "Remove from Your Library" else "Save to Your Library",
                            tint = if (saved) Sc.Accent else Sc.TextDim,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    ListDownloadButton(vm.items, downloadAll = { withAll { actions.download(it) } })
                    IconButton(onClick = { more = true }) { Icon(Icons.Rounded.MoreVert, "More", tint = Sc.TextDim) }
                }
            }
        }
        when {
            vm.loading && vm.items.isEmpty() -> item(key = "loading") {
                if (h == null) Box(Modifier.statusBarsPadding().padding(top = 40.dp)) { SkeletonPage() } else SkeletonRows(8)
            }
            err != null && vm.items.isEmpty() -> item(key = "error") { Box(Modifier.statusBarsPadding().padding(top = 60.dp)) { ErrorBox(err, onRetry = { vm.reload() }) } }
            vm.items.isEmpty() && vm.started && !vm.loading -> item(key = "empty") {
                EmptyState(Icons.AutoMirrored.Rounded.QueueMusic, "Nothing in here", "This list is empty.")
            }
        }
        val album = h?.ref?.isAlbum == true
        itemsIndexed(vm.items, key = { _, t -> t.videoId }) { i, t ->
            TrackRow(
                track = t,
                number = if (album) i + 1 else null,
                playing = current?.videoId == t.videoId,
                isPlaying = playing,
                downloaded = t.videoId in doneIds,
                subtitle = if (album) t.artist.ifBlank { null } else null,
                onClick = { if (sel.active) sel.toggle(t) else actions.playAll(vm.items, i, source = name) },
                onMore = if (sel.active) null else ({ menuFor = t }),
                onLongClick = { sel.toggle(t) },
                selected = if (sel.active) sel.isSelected(t) else null
            )
        }
        if (vm.loadingMore) item(key = "more") { Loading() }
        h?.description?.takeIf { it.isNotBlank() }?.let { d ->
            item(key = "desc") {
                Text(
                    d, color = Sc.TextDim, fontSize = 13.sp, maxLines = 8, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 18.dp)
                )
            }
        }
    }

    menuFor?.let { t -> TrackActionsSheet(t, onDismiss = { menuFor = null }) }
    addAll?.let { list -> AddToPlaylistDialog(list, onDone = { addAll = null }) }

    if (more && h != null) {
        ModalBottomSheet(
            onDismissRequest = { more = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Sc.Sheet
        ) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Row(Modifier.padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Artwork(h.ref.thumbnail, Modifier.size(48.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(h.ref.name, color = Sc.Text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(h.ref.author, color = Sc.TextDim, fontSize = 13.sp, maxLines = 1)
                    }
                }
                HorizontalDivider(color = Sc.Outline, modifier = Modifier.padding(vertical = 6.dp))
                SheetRow(Icons.AutoMirrored.Rounded.QueueMusic, "Add all to queue") {
                    more = false
                    withAll { PlayerController.addToQueue(it) }
                }
                SheetRow(Icons.AutoMirrored.Rounded.PlaylistAdd, "Copy into one of your playlists") {
                    more = false
                    withAll { addAll = it }
                }
                SheetRow(Icons.Rounded.Shuffle, "Shuffle play") {
                    more = false
                    withAll { actions.playAll(it, shuffle = true, source = h.ref.name) }
                }
                SheetRow(Icons.Rounded.Share, "Share") {
                    more = false
                    actions.shareCollection(h.ref)
                }
            }
        }
    }
}

// =============================================================================================
// Artist
// =============================================================================================

class ArtistVm : ViewModel() {
    var page by mutableStateOf<ArtistPage?>(null)
        private set
    var songs by mutableStateOf<List<Track>>(emptyList())
        private set
    var albums by mutableStateOf<List<CollectionRef>>(emptyList())
        private set
    var videos by mutableStateOf<List<Track>>(emptyList())
        private set
    var playlists by mutableStateOf<List<CollectionRef>>(emptyList())
        private set
    /** "Fans also like": artists related to this one (same source radio uses). */
    var related by mutableStateOf<List<RelArtist>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var loadingMusic by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    private var url = ""

    fun open(u: String, force: Boolean = false) {
        if (u == url && !force) return
        url = u
        viewModelScope.launch {
            loading = true
            error = null
            try {
                val p = Music.artist(u)
                page = p
                loading = false
                related = emptyList()
                launch { related = runCatching { Stations.relatedArtists(p.ref.name) }.getOrDefault(emptyList()).take(16) }
                loadMusic(p)
            } catch (e: Exception) {
                error = Music.friendlyError(e)
            } finally {
                loading = false
            }
        }
    }

    /**
     * Songs, releases and videos. YouTube Music search does the heavy lifting (it knows every
     * artist's catalog); the channel's own tabs fill in whatever search doesn't have.
     */
    private suspend fun loadMusic(p: ArtistPage): Unit = coroutineScope {
        loadingMusic = true
        val name = p.ref.name
        val aUrl = p.ref.url
        fun tab(key: String) = async { p.tabs[key]?.let { runCatching { Music.artistTab(it) }.getOrNull() }?.items ?: emptyList() }
        val chVideos = tab(ChannelTabs.VIDEOS)
        val chAlbums = tab(ChannelTabs.ALBUMS)
        val chPlaylists = tab(ChannelTabs.PLAYLISTS)
        val sSongs = async { Music.artistSongs(name, aUrl) }
        val sAlbums = async { Music.artistAlbums(name, aUrl) }
        val sVideos = async { Music.artistVideos(name, aUrl) }

        val uploads = chVideos.await().filterIsInstance<Entry.Song>().map { e ->
            e.track.copy(artist = e.track.artist.ifBlank { name }, artistUrl = e.track.artistUrl.ifBlank { aUrl })
        }.filter { !it.url.contains("/shorts/") }

        songs = sSongs.await().ifEmpty { uploads }
        loadingMusic = false

        val releases = chAlbums.await().filterIsInstance<Entry.Collection>().map { it.collection }
        albums = (releases + sAlbums.await()).distinctBy { it.url }
        videos = (sVideos.await() + uploads).distinctBy { it.videoId }.filter { v -> songs.none { it.videoId == v.videoId } }.take(30)
        playlists = chPlaylists.await().filterIsInstance<Entry.Collection>().map { it.collection }
    }
}

@UnstableApi
@Composable
fun ArtistScreen(url: String) {
    val actions = LocalActions.current
    val vm: ArtistVm = viewModel(key = "artist:$url")
    val lib by Library.data.collectAsState()
    val current by PlayerController.current.collectAsState()
    val playing by PlayerController.isPlaying.collectAsState()
    val currentSource by PlayerController.source.collectAsState()
    val playerShuffle by PlayerController.shuffle.collectAsState()
    val listState = rememberLazyListState()
    var menuFor by remember { mutableStateOf<Track?>(null) }
    var showAll by remember { mutableStateOf(false) }
    var localShuffle by remember { mutableStateOf(false) }
    LaunchedEffect(url) { vm.open(url) }

    val p = vm.page
    val err = vm.error
    val name = p?.ref?.name ?: ""
    val img = p?.let { it.ref.avatar.ifBlank { it.banner } } ?: ""
    val tint = rememberArtColor(img, Sc.SurfaceHighest)
    val following = p != null && lib.artists.any { it.url.trimEnd('/').substringAfterLast('/') == p.ref.url.trimEnd('/').substringAfterLast('/') }
    val here = current != null && name.isNotBlank() && currentSource == name
    val shuffle = if (here) playerShuffle else localShuffle
    val doneIds = remember(lib.downloads) {
        lib.downloads.filter { it.status == DownloadRecord.STATUS_DONE }.map { it.track.videoId }.toHashSet()
    }

    val sel = rememberSongSelection()
    ListPage(
        listState, name, tint, onBack = { actions.back() },
        overlay = { SelectionOverlay(sel, if (showAll) vm.songs else vm.songs.take(5)) }
    ) {
        if (p != null) {
            item(key = "hero") {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.15f)
                        .background(tint)
                ) {
                    if (img.isNotBlank()) {
                        AsyncImage(
                            model = hiRes(img, 900), contentDescription = null, contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(Brush.verticalGradient(0f to Color.Transparent, 0.55f to Color.Black.copy(alpha = 0.15f), 1f to Sc.Bg))
                    )
                    Text(
                        p.ref.name,
                        color = Sc.Text,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = (-1.5).sp,
                        lineHeight = 46.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
            item(key = "subs") {
                if (p.ref.subscribers > 0) {
                    Text(
                        Fmt.count(p.ref.subscribers) + " subscribers",
                        color = Sc.TextDim, fontSize = 13.sp,
                        modifier = Modifier.padding(start = 16.dp, top = 4.dp)
                    )
                }
            }
            item(key = "actions") {
                ActionRow(
                    playing = here && playing,
                    shuffle = shuffle,
                    onShuffle = { if (here) PlayerController.toggleShuffle() else localShuffle = !localShuffle },
                    onPlay = {
                        when {
                            here -> PlayerController.togglePlay()
                            vm.songs.isEmpty() -> actions.message("No songs found for this artist")
                            else -> actions.playAll(vm.songs, shuffle = shuffle, source = p.ref.name)
                        }
                    }
                ) {
                    Spacer(Modifier.width(12.dp))
                    FollowButton(following, { Library.toggleFollow(p.ref) })
                    IconButton(onClick = { actions.shareArtist(p.ref) }) {
                        Icon(Icons.Rounded.Share, "Share artist", tint = Sc.TextDim)
                    }
                    if (vm.songs.isNotEmpty()) {
                        IconButton(onClick = {
                            PlayerController.playStation(Station.artist(p.ref))
                            actions.openPlayer()
                        }) { Icon(Icons.Rounded.Radio, "Artist radio", tint = Sc.TextDim) }
                    }
                }
            }
            if (vm.songs.isNotEmpty()) {
                item(key = "songsh") {
                    Text("Popular", color = Sc.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 8.dp))
                }
                val shown = if (showAll) vm.songs else vm.songs.take(5)
                itemsIndexed(shown, key = { _, t -> "s:" + t.videoId }) { i, t ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "${i + 1}", color = Sc.TextDim, fontSize = 15.sp,
                            modifier = Modifier
                                .padding(start = 16.dp)
                                .width(20.dp)
                        )
                        TrackRow(
                            track = t,
                            playing = current?.videoId == t.videoId,
                            isPlaying = playing,
                            downloaded = t.videoId in doneIds,
                            subtitle = listOf(t.album, if (t.duration > 0) Fmt.duration(t.duration) else "").filter { it.isNotBlank() }.joinToString(" • ").ifBlank { t.artist },
                            onClick = { if (sel.active) sel.toggle(t) else actions.playAll(vm.songs, i, source = p.ref.name) },
                            onMore = if (sel.active) null else ({ menuFor = t }),
                            onLongClick = { sel.toggle(t) },
                            selected = if (sel.active) sel.isSelected(t) else null,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                if (vm.songs.size > 5) item(key = "seeall") {
                    Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                        OutlineButton(if (showAll) "Show less" else "See more", { showAll = !showAll })
                    }
                }
            } else if (vm.loadingMusic) {
                item(key = "musicloading") { Loading() }
            } else {
                item(key = "nosongs") {
                    Text(
                        "Couldn't find songs for ${p.ref.name}. Pull them up from Search instead.",
                        color = Sc.TextDim, fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                }
            }
            val albumsOnly = vm.albums.filter { it.isAlbum }
            val singlesOnly = vm.albums.filter { !it.isAlbum }
            if (albumsOnly.isNotEmpty() && singlesOnly.isNotEmpty()) {
                shelf("Albums", albumsOnly, key = { it.url }) { c ->
                    SquareCard(
                        c.name, c.author.ifBlank { "Album" }, c.thumbnail,
                        onClick = { actions.collection(c.url) }, icon = Icons.Rounded.Album
                    )
                }
                shelf("Singles & EPs", singlesOnly, key = { it.url }) { c ->
                    SquareCard(
                        c.name, c.author.ifBlank { "Single" }, c.thumbnail,
                        onClick = { actions.collection(c.url) }, icon = Icons.Rounded.Album
                    )
                }
            } else {
                shelf("Albums & singles", vm.albums, key = { it.url }) { c ->
                    SquareCard(
                        c.name, c.author.ifBlank { if (c.isAlbum) "Album" else "Single" }, c.thumbnail,
                        onClick = { actions.collection(c.url) }, icon = Icons.Rounded.Album
                    )
                }
            }
            shelf("Fans also like", vm.related, key = { "fa:" + it.name }) { a ->
                ArtistCircle(ArtistRef(url = "", name = a.name, avatar = a.picture), onClick = { actions.artistNamed(a.name) })
            }
            shelf("Music videos", vm.videos, key = { it.videoId }) { t ->
                VideoCard(t, onClick = { actions.playAll(vm.videos, vm.videos.indexOf(t).coerceAtLeast(0), source = "${p.ref.name} videos") }, onLongClick = { menuFor = t })
            }
            shelf("Playlists", vm.playlists, key = { it.url }) { c ->
                SquareCard(
                    c.name, c.author, c.thumbnail,
                    onClick = { actions.collection(c.url) }
                )
            }
            if (p.description.isNotBlank()) {
                item(key = "abouth") { SectionHeader("About") }
                item(key = "about") {
                    Column(
                        Modifier
                            .padding(horizontal = 16.dp)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Sc.Surface)
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Avatar(p.ref.avatar, 44.dp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(p.ref.name, color = Sc.Text, fontWeight = FontWeight.Bold)
                                if (p.ref.subscribers > 0) Text(Fmt.count(p.ref.subscribers) + " subscribers", color = Sc.TextDim, fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(p.description, color = Sc.TextDim, fontSize = 13.sp, lineHeight = 19.sp, maxLines = 8, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        } else if (vm.loading) {
            item(key = "loading") { Box(Modifier.statusBarsPadding().padding(top = 40.dp)) { SkeletonPage(round = true) } }
        } else if (err != null) {
            item(key = "error") { Box(Modifier.statusBarsPadding().padding(top = 60.dp)) { ErrorBox(err, onRetry = { vm.open(url, force = true) }) } }
        }
    }

    menuFor?.let { t -> TrackActionsSheet(t, onDismiss = { menuFor = null }) }
}

/** 16:9 card for music videos. */
@Composable
private fun VideoCard(t: Track, onClick: () -> Unit, onLongClick: () -> Unit) {
    Column(
        Modifier
            .width(232.dp)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(4.dp))
                .background(Sc.SurfaceHighest)
        ) {
            AsyncImage(
                model = videoThumb(t), contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(t.title, color = Sc.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 17.sp)
        if (t.duration > 0) Text(Fmt.duration(t.duration), color = Sc.TextDim, fontSize = 12.sp)
    }
}

/** Wide video frame (the square album-art crop doesn't suit music videos). */
private fun videoThumb(t: Track): String =
    if (t.videoId.length == 11) "https://i.ytimg.com/vi/${t.videoId}/hqdefault.jpg" else t.thumbnail
