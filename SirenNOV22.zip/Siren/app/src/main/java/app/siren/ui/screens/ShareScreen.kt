package app.siren.ui.screens

import app.siren.ui.components.SirenLoader
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.provider.Telephony
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Headset
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Sms
import androidx.compose.material.icons.rounded.Tag
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import app.siren.core.ArtistRef
import app.siren.core.CollectionRef
import app.siren.core.Fmt
import app.siren.core.Track
import app.siren.core.hiRes
import app.siren.ui.LocalActions
import app.siren.ui.components.Chip
import app.siren.ui.theme.Sc
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Something on the share screen: a song, album, playlist or artist. */
data class ShareItem(
    val kind: String,
    val title: String,
    val subtitle: String,
    val images: List<String>,
    /** Link to send along ("" for playlists made on this phone). */
    val link: String,
    /** Text that goes with the image. */
    val text: String,
    /** Round picture (artists). */
    val round: Boolean = false,
    /** Lyric card lines (empty for everything else). */
    val lyrics: List<String> = emptyList()
) {
    companion object {
        fun song(t: Track): ShareItem {
            if (app.siren.data.LocalMusic.isLocal(t)) {
                return ShareItem("Song", t.title, t.artist, listOf(t.thumbnail), "", "${t.title} – ${t.artist}".trim().removeSuffix(" –"))
            }
            val link = "https://music.youtube.com/watch?v=" + t.videoId
            return ShareItem("Song", t.title, t.artist, listOf(t.thumbnail), link, "${t.title} – ${t.artist}\n$link".trim())
        }

        fun collection(c: CollectionRef): ShareItem {
            val link = musicLink(c.url)
            return ShareItem(
                if (c.isAlbum) "Album" else "Playlist", c.name, c.author, listOf(c.thumbnail), link,
                (c.name + (if (c.author.isNotBlank()) " – " + c.author else "") + "\n" + link).trim()
            )
        }

        fun artist(a: ArtistRef): ShareItem {
            val link = musicLink(a.url)
            return ShareItem("Artist", a.name, "", listOf(a.avatar), link, "${a.name}\n$link".trim(), round = true)
        }

        /** Links open in YouTube Music, not regular YouTube (where there are ads). */
        fun musicLink(url: String): String =
            url.replace("://www.youtube.com/", "://music.youtube.com/")
                .replace("://m.youtube.com/", "://music.youtube.com/")
                .replace("://youtube.com/", "://music.youtube.com/")

        fun lyrics(t: Track, lines: List<String>): ShareItem {
            val link = "https://music.youtube.com/watch?v=" + t.videoId
            val quote = lines.joinToString("\n")
            return ShareItem("Lyrics", t.title, t.artist, listOf(t.thumbnail), link, "\"$quote\"\n— ${t.title}, ${t.artist}\n$link", lyrics = lines)
        }

        fun playlist(name: String, tracks: List<Track>, text: String) = ShareItem(
            "Playlist", name, Fmt.songs(tracks.size),
            tracks.map { it.thumbnail }.filter { it.isNotBlank() }.distinct().take(4), "", text
        )
    }
}

/** Draws the share card image (1080 × 1350) in one of a few styles. */
object ShareCard {
    const val W = 1080
    const val H = 1350
    val STYLES = listOf("Color", "Gradient", "Blur", "Dark")

    /** Loads the artwork (up to 4 for a collage). */
    suspend fun loadArt(ctx: Context, item: ShareItem): List<Bitmap> = withContext(Dispatchers.IO) {
        item.images.take(if (item.images.size >= 4) 4 else 1).mapNotNull { url ->
            try {
                val req = ImageRequest.Builder(ctx).data(hiRes(url, 720)).allowHardware(false).build()
                val r = ctx.imageLoader.execute(req) as? SuccessResult ?: return@mapNotNull null
                r.drawable.toBitmap()
            } catch (_: Exception) {
                null
            }
        }
    }

    /** A strong color from the cover, bright enough to feel like the card's own color. */
    fun baseColor(art: Bitmap?): Int {
        if (art == null) return Sc.AccentDeep.toArgb()
        return try {
            val p = Palette.from(art).maximumColorCount(16).generate()
            val sw = p.vibrantSwatch ?: p.dominantSwatch ?: p.mutedSwatch ?: return Sc.AccentDeep.toArgb()
            val hsl = FloatArray(3)
            ColorUtils.colorToHSL(sw.rgb, hsl)
            hsl[1] = hsl[1].coerceIn(0.25f, 0.75f)
            hsl[2] = hsl[2].coerceIn(0.32f, 0.44f)
            ColorUtils.HSLToColor(hsl)
        } catch (_: Exception) {
            Sc.AccentDeep.toArgb()
        }
    }

    private fun shade(c: Int, f: Float): Int = ColorUtils.blendARGB(c, android.graphics.Color.BLACK, f)

    fun render(item: ShareItem, art: List<Bitmap>, style: Int, base: Int): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val full = RectF(0f, 0f, W.toFloat(), H.toFloat())

        // Background
        when (style) {
            0 -> c.drawColor(base)
            1 -> {
                p.shader = LinearGradient(0f, 0f, 0f, H.toFloat(), intArrayOf(base, shade(base, 0.55f), 0xFF0A0A0A.toInt()), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
                c.drawRect(full, p)
                p.shader = null
            }
            2 -> {
                val a = art.firstOrNull()
                if (a != null) {
                    // Cheap blur: shrink a lot, then stretch back up with filtering
                    val tiny = Bitmap.createScaledBitmap(a, 12, 15, true)
                    val soft = Bitmap.createScaledBitmap(tiny, 120, 150, true)
                    c.drawBitmap(soft, null, full, p)
                    c.drawColor(0x66000000)
                } else c.drawColor(shade(base, 0.3f))
            }
            else -> c.drawColor(0xFF0E0E0E.toInt())
        }

        if (item.lyrics.isNotEmpty()) {
            drawLyricCard(c, item, art, style, base)
            return bmp
        }

        // Card
        val cardW = 760f
        val pad = 40f
        val cover = cardW - pad * 2
        val white = android.graphics.Color.WHITE
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = white
            textSize = 54f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ColorUtils.setAlphaComponent(white, 190)
            textSize = 36f
        }
        val sub = when {
            item.kind == "Song" -> item.subtitle
            item.subtitle.isBlank() -> item.kind
            else -> "${item.kind} · ${item.subtitle}"
        }
        val textW = (cardW - pad * 2).toInt()
        val titleLayout = layout(item.title, titlePaint, textW, 2)
        val subLayout = layout(sub, subPaint, textW, 1)
        val brandH = 44f
        val cardH = pad + cover + 34f + titleLayout.height + 8f + subLayout.height + 34f + brandH + pad
        val left = (W - cardW) / 2f
        val top = (H - cardH) / 2f
        val card = RectF(left, top, left + cardW, top + cardH)
        p.color = when (style) {
            0 -> shade(base, 0.5f)
            1 -> 0x55000000
            2 -> 0x77000000
            else -> 0xFF1C1C1C.toInt()
        }
        c.drawRoundRect(card, 36f, 36f, p)

        // Cover
        val coverRect = RectF(left + pad, top + pad, left + pad + cover, top + pad + cover)
        drawCover(c, item, art, coverRect, shade(base, 0.3f))

        // Title, subtitle
        var y = coverRect.bottom + 34f
        c.save()
        c.translate(left + pad, y)
        titleLayout.draw(c)
        c.restore()
        y += titleLayout.height + 8f
        c.save()
        c.translate(left + pad, y)
        subLayout.draw(c)
        c.restore()
        y += subLayout.height + 34f

        // Siren mark + name
        val markColor = ColorUtils.setAlphaComponent(white, 200)
        drawMark(c, left + pad + brandH / 2f, y + brandH / 2f, brandH, markColor)
        val brand = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = markColor
            textSize = 34f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        c.drawText("Siren", left + pad + brandH + 14f, y + brandH / 2f - (brand.descent() + brand.ascent()) / 2f, brand)
        return bmp
    }

    /** Lyric card: small cover + song at the top, the lines big and bold, Siren at the bottom. */
    private fun drawLyricCard(c: Canvas, item: ShareItem, art: List<Bitmap>, style: Int, base: Int) {
        val white = android.graphics.Color.WHITE
        val cardW = 860f
        val pad = 56f
        val inner = (cardW - pad * 2).toInt()
        val cover = 104f
        val titleP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = white; textSize = 38f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val subP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = ColorUtils.setAlphaComponent(white, 190); textSize = 32f }
        val headW = (inner - cover - 28f).toInt()
        val tl = layout(item.title, titleP, headW, 1)
        val sl = layout(item.subtitle, subP, headW, 1)
        // Lines: biggest size that fits
        var size = 66f
        var body: StaticLayout
        while (true) {
            val bp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = white; textSize = size; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
            body = StaticLayout.Builder.obtain(item.lyrics.joinToString("\n"), 0, item.lyrics.joinToString("\n").length, bp, inner)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL).setLineSpacing(0f, 1.12f).setIncludePad(false).build()
            if (body.height <= 640 || size <= 34f) break
            size -= 4f
        }
        val brandH = 44f
        val cardH = pad + cover + 52f + body.height + 56f + brandH + pad
        val left = (W - cardW) / 2f
        val top = (H - cardH) / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        p.color = when (style) {
            0 -> shade(base, 0.35f)
            1 -> 0x55000000
            2 -> 0x77000000
            else -> 0xFF1C1C1C.toInt()
        }
        c.drawRoundRect(RectF(left, top, left + cardW, top + cardH), 40f, 40f, p)
        // Header
        val cr = RectF(left + pad, top + pad, left + pad + cover, top + pad + cover)
        drawCover(c, item, art.take(1), cr, shade(base, 0.3f))
        val hx = cr.right + 28f
        val hy = cr.top + (cover - tl.height - 6f - sl.height) / 2f
        c.save(); c.translate(hx, hy); tl.draw(c); c.restore()
        c.save(); c.translate(hx, hy + tl.height + 6f); sl.draw(c); c.restore()
        // Lines
        var y = cr.bottom + 52f
        c.save(); c.translate(left + pad, y); body.draw(c); c.restore()
        y += body.height + 56f
        // Siren
        val markColor = ColorUtils.setAlphaComponent(white, 200)
        drawMark(c, left + pad + brandH / 2f, y + brandH / 2f, brandH, markColor)
        val brand = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = markColor; textSize = 34f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        c.drawText("Siren", left + pad + brandH + 14f, y + brandH / 2f - (brand.descent() + brand.ascent()) / 2f, brand)
    }

    private fun layout(text: String, paint: TextPaint, width: Int, lines: Int): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setMaxLines(lines)
            .setEllipsize(TextUtils.TruncateAt.END)
            .setIncludePad(false)
            .build()

    private fun drawCover(c: Canvas, item: ShareItem, art: List<Bitmap>, r: RectF, empty: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        c.save()
        val clip = Path()
        if (item.round) clip.addOval(r, Path.Direction.CW) else clip.addRoundRect(r, 14f, 14f, Path.Direction.CW)
        c.clipPath(clip)
        p.color = empty
        c.drawRect(r, p)
        if (art.size >= 4) {
            val half = r.width() / 2f
            art.take(4).forEachIndexed { i, b ->
                val x = r.left + (i % 2) * half
                val yy = r.top + (i / 2) * half
                c.drawBitmap(b, centerCrop(b), RectF(x, yy, x + half, yy + half), p)
            }
        } else art.firstOrNull()?.let { b -> c.drawBitmap(b, centerCrop(b), r, p) }
        c.restore()
    }

    /** The middle square of a picture (video thumbnails are 16:9). */
    private fun centerCrop(b: Bitmap): Rect {
        val s = minOf(b.width, b.height)
        val x = (b.width - s) / 2
        val y = (b.height - s) / 2
        return Rect(x, y, x + s, y + s)
    }

    /** Siren's mark: a drop landing in water, three flat rings spreading out. */
    private fun drawMark(c: Canvas, cx: Float, cy: Float, s: Float, color: Int) {
        val u = s / 92f
        fun x(v: Float) = cx + (v - 50f) * u
        fun y(v: Float) = cy + (v - 63.5f) * u
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        val rings = listOf(
            floatArrayOf(55f, 20f, 10.5f, 4.6f, 1f),
            floatArrayOf(60f, 31.5f, 16.5f, 3.8f, 0.7f),
            floatArrayOf(65f, 43f, 22.5f, 3.0f, 0.42f)
        )
        val baseA = android.graphics.Color.alpha(color)
        rings.forEach { (ry0, rx, ry, w, a) ->
            p.color = ColorUtils.setAlphaComponent(color, (baseA * a).toInt())
            p.strokeWidth = w * u
            c.drawOval(RectF(x(50f) - rx * u, y(ry0) - ry * u, x(50f) + rx * u, y(ry0) + ry * u), p)
        }
        p.style = Paint.Style.FILL
        p.color = color
        c.drawCircle(x(50f), y(47f), 8f * u, p)
    }

    /** Saves the card where other apps can read it, and returns its content link. */
    suspend fun export(ctx: Context, bmp: Bitmap): Uri = withContext(Dispatchers.IO) {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, "siren-${System.currentTimeMillis()}.png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        FileProvider.getUriForFile(ctx, ctx.packageName + ".share", f)
    }
}

private class ShareTarget(val label: String, val icon: ImageVector, val bg: Brush, val pkg: String?, val kind: Int) {
    companion object {
        const val COPY = 0
        const val APP = 1
        const val MORE = 2
    }
}

private fun installed(ctx: Context, pkg: String?): Boolean {
    if (pkg.isNullOrBlank()) return false
    return try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: Exception) {
        false
    }
}

private fun solid(c: Long) = Brush.linearGradient(listOf(Color(c), Color(c)))

/** Spotify-style share screen: a card made from the cover, then where to send it. */
@Composable
fun ShareScreen(item: ShareItem, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val actions = LocalActions.current
    val scope = rememberCoroutineScope()
    BackHandler(onBack = onClose)

    var art by remember(item) { mutableStateOf<List<Bitmap>?>(null) }
    val cards = remember(item) { mutableStateListOf<Bitmap?>(*arrayOfNulls(ShareCard.STYLES.size)) }
    val pager = rememberPagerState { ShareCard.STYLES.size }
    var editing by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(item) {
        val a = ShareCard.loadArt(ctx, item)
        art = a
        val base = withContext(Dispatchers.Default) { ShareCard.baseColor(a.firstOrNull()) }
        ShareCard.STYLES.indices.forEach { i ->
            cards[i] = withContext(Dispatchers.Default) { ShareCard.render(item, a, i, base) }
        }
    }

    val targets = remember(item) {
        val sms = try {
            Telephony.Sms.getDefaultSmsPackage(ctx)
        } catch (_: Exception) {
            null
        }
        buildList {
            add(ShareTarget(if (item.link.isNotBlank()) "Copy link" else "Copy list", Icons.Rounded.Link, solid(0xFFFFFFFF), null, ShareTarget.COPY))
            add(ShareTarget("WhatsApp", Icons.AutoMirrored.Rounded.Chat, solid(0xFF25D366), "com.whatsapp", ShareTarget.APP))
            add(ShareTarget("Messages", Icons.Rounded.Sms, solid(0xFF1A73E8), sms, ShareTarget.APP))
            add(
                ShareTarget(
                    "Instagram", Icons.Rounded.PhotoCamera,
                    Brush.linearGradient(listOf(Color(0xFFFEDA75), Color(0xFFFA7E1E), Color(0xFFD62976), Color(0xFF962FBF), Color(0xFF4F5BD5))),
                    "com.instagram.android", ShareTarget.APP
                )
            )
            add(ShareTarget("Discord", Icons.Rounded.Headset, solid(0xFF5865F2), "com.discord", ShareTarget.APP))
            add(ShareTarget("Snapchat", Icons.Rounded.PhotoCamera, solid(0xFFFFFC00), "com.snapchat.android", ShareTarget.APP))
            add(ShareTarget("X", Icons.Rounded.Tag, solid(0xFF000000), "com.twitter.android", ShareTarget.APP))
            add(ShareTarget("Messenger", Icons.Rounded.Forum, solid(0xFF0084FF), "com.facebook.orca", ShareTarget.APP))
            add(ShareTarget("More", Icons.Rounded.MoreHoriz, solid(0xFF3A3A3A), null, ShareTarget.MORE))
        }.filter { it.kind != ShareTarget.APP || installed(ctx, it.pkg) }
    }

    fun go(t: ShareTarget) {
        if (t.kind == ShareTarget.COPY) {
            val cm = ctx.getSystemService(ClipboardManager::class.java)
            cm?.setPrimaryClip(ClipData.newPlainText(item.title, item.link.ifBlank { item.text }))
            actions.message(if (item.link.isNotBlank()) "Link copied" else "Song list copied")
            return
        }
        val bmp = cards.getOrNull(pager.currentPage)
        if (bmp == null || busy) {
            actions.message("Making your card…")
            return
        }
        busy = true
        scope.launch {
            try {
                val uri = ShareCard.export(ctx, bmp)
                val send = Intent(Intent.ACTION_SEND)
                    .setType("image/png")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .putExtra(Intent.EXTRA_TEXT, item.text)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                send.clipData = ClipData.newRawUri(item.title, uri)
                val intent = if (t.kind == ShareTarget.APP && t.pkg != null) Intent(send).setPackage(t.pkg)
                else Intent.createChooser(send, "Share").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                try {
                    ctx.startActivity(intent)
                } catch (_: ActivityNotFoundException) {
                    ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                }
            } catch (e: Exception) {
                actions.message("Couldn't share that")
            } finally {
                busy = false
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Sc.Bg)
            .clickable(enabled = false) {}
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Close", tint = Sc.Text, modifier = Modifier.size(28.dp)) }
            Text(
                if (item.kind == "Lyrics") "Share lyrics" else "Share this ${item.kind.lowercase()}",
                color = Sc.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f).padding(end = 48.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            HorizontalPager(pager, modifier = Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 36.dp)) { page ->
                Box(Modifier.fillMaxSize().padding(horizontal = 6.dp, vertical = 12.dp), contentAlignment = Alignment.Center) {
                    val b = cards.getOrNull(page)
                    Box(
                        Modifier
                            .aspectRatio(ShareCard.W / ShareCard.H.toFloat())
                            .clip(RoundedCornerShape(18.dp))
                            .background(Sc.SurfaceHigh),
                        contentAlignment = Alignment.Center
                    ) {
                        if (b != null) Image(b.asImageBitmap(), "Share card, ${ShareCard.STYLES[page]} style", Modifier.fillMaxSize())
                        else SirenLoader(size = 44.dp)
                        Text(
                            "Edit",
                            color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(14.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Color.White)
                                .clickable { editing = !editing }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Page dots
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
            repeat(ShareCard.STYLES.size) { i ->
                Box(
                    Modifier
                        .padding(horizontal = 4.dp)
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(if (pager.currentPage == i) Sc.Text else Sc.TextFaint)
                )
            }
        }
        if (editing) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
            ) {
                ShareCard.STYLES.forEachIndexed { i, name ->
                    Chip(name, pager.currentPage == i, { scope.launch { pager.animateScrollToPage(i) } })
                }
            }
        }

        // Where to send it
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                .background(Sc.SurfaceHigh)
                .padding(top = 10.dp, bottom = 16.dp)
        ) {
            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .size(width = 36.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Sc.TextFaint)
            )
            Spacer(Modifier.height(14.dp))
            LazyRow(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(targets, key = { it.label }) { t ->
                    Column(
                        Modifier
                            .width(78.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { go(t) }
                            .padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(t.bg),
                            contentAlignment = Alignment.Center
                        ) {
                            val dark = t.label == "Copy link" || t.label == "Copy list" || t.label == "Snapchat"
                            Icon(t.icon, null, tint = if (dark) Color.Black else Color.White, modifier = Modifier.size(26.dp))
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(t.label, color = Sc.Text, fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}
