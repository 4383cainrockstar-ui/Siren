package app.siren.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.ContextCompat
import app.siren.core.Music
import app.siren.core.Net
import app.siren.core.Track
import app.siren.core.cleanArtist
import app.siren.core.cleanTitle
import app.siren.core.fallbackThumb
import app.siren.core.makeTrack
import app.siren.core.watchUrl
import app.siren.ui.UiState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.net.URLEncoder
import java.util.UUID

/** One song to bring in: an exact video ID, or title / artist to search for. */
@Serializable
data class ImportItem(
    val videoId: String = "",
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val durationSec: Long = -1,
    /** A plain line of text: title and artist may be mixed up. */
    val loose: Boolean = false
) {
    val label: String
        get() = when {
            title.isNotBlank() && artist.isNotBlank() -> "$title – $artist"
            title.isNotBlank() -> title
            else -> "Video $videoId (removed or private)"
        }
}

/** What a file turned into before importing. [exact]: every song has a video ID. */
data class ParsedList(val name: String, val items: List<ImportItem>, val exact: Boolean = false)

/** A match Siren wasn't confident about, kept for the person to accept or skip. */
@Serializable
data class UnsureItem(val label: String, val track: Track)

@Serializable
data class ImportJob(
    val id: String,
    val playlistId: String,
    val name: String,
    val items: List<ImportItem>,
    val next: Int = 0,
    val matched: Int = 0,
    val missing: List<String> = emptyList(),
    val unsure: List<UnsureItem> = emptyList(),
    val status: String = RUNNING,
    val createdAt: Long = 0
) {
    val total: Int get() = items.size
    val running: Boolean get() = status == RUNNING
    val needsLook: Int get() = missing.size + unsure.size

    companion object {
        const val RUNNING = "running"
        const val DONE = "done"
        const val STOPPED = "stopped"
    }
}

/**
 * Playlist imports that run in the background (see [ImportService]). Jobs are saved after
 * every batch, so if the app is closed or killed the import carries on from where it was.
 * The playlist is created first and fills in, in order, as songs are found.
 */
object Importer {
    enum class Step { MORE, WAIT, FINISHED }

    private const val BATCH = 24
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Mutex()
    private val gate = Semaphore(5)
    private lateinit var file: File

    private val _jobs = MutableStateFlow<List<ImportJob>>(emptyList())
    val jobs: StateFlow<List<ImportJob>> = _jobs.asStateFlow()

    private val _reading = MutableStateFlow(false)
    /** True while a file is being read (before its jobs exist). */
    val reading: StateFlow<Boolean> = _reading.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private val listSer = ListSerializer(ImportJob.serializer())
    private val stuck = java.util.concurrent.ConcurrentHashMap<String, Int>()

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "imports.json")
        _jobs.value = try {
            if (file.exists()) LibraryJson.json.decodeFromString(listSer, file.readText()) else emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save() {
        if (!::file.isInitialized) return
        try {
            val tmp = File(file.parentFile, "imports.json.tmp")
            tmp.writeText(LibraryJson.json.encodeToString(listSer, _jobs.value))
            tmp.renameTo(file)
        } catch (_: Exception) {
        }
    }

    private fun edit(block: (List<ImportJob>) -> List<ImportJob>) {
        _jobs.update(block)
        scope.launch { lock.withLock { save() } }
    }

    private fun editJob(id: String, block: (ImportJob) -> ImportJob) =
        edit { list -> list.map { if (it.id == id) block(it) else it } }

    fun job(id: String): ImportJob? = _jobs.value.firstOrNull { it.id == id }

    fun jobForPlaylist(playlistId: String): ImportJob? = _jobs.value.firstOrNull { it.playlistId == playlistId }

    fun nextRunning(): ImportJob? = _jobs.value.firstOrNull { it.running }

    fun runningCount(): Int = _jobs.value.count { it.running }

    // ---------------- Starting ----------------

    private fun displayName(ctx: Context, uri: Uri): String = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: "Imported"
    } catch (e: Exception) {
        "Imported"
    }

    /** Reads a Takeout zip / CSV, an Exportify CSV (or zip) or a text list, then imports in the background. */
    fun startFile(ctx: Context, uri: Uri) {
        val app = ctx.applicationContext
        scope.launch {
            _reading.value = true
            try {
                val name = displayName(app, uri)
                val lists = app.contentResolver.openInputStream(uri)?.use { ImportParse.read(it, name) }
                    ?: throw IOException("Couldn't read that file")
                if (lists.isEmpty()) {
                    _messages.tryEmit("No songs found in that file")
                    return@launch
                }
                val now = System.currentTimeMillis()
                val created = lists.mapIndexed { i, l ->
                    val pid = Library.createPlaylist(l.name)
                    ImportJob(UUID.randomUUID().toString(), pid, l.name, l.items, createdAt = now + i)
                }
                edit { it + created }
                val songs = created.sumOf { it.total }
                _messages.tryEmit(
                    if (created.size == 1) "Importing ${songs.fmtSongs()} into \"${created[0].name}\". You can leave the app."
                    else "Importing ${created.size} playlists (${songs.fmtSongs()}). You can leave the app."
                )
                if (created.size == 1) UiState.pending.value = UiState.Pending.OpenPlaylist(created[0].playlistId)
                ensureRunning(app)
            } catch (e: Exception) {
                _messages.tryEmit(Music.friendlyError(e))
            } finally {
                _reading.value = false
            }
        }
    }

    /** Copies a YouTube / YouTube Music playlist (any size) into a local playlist. */
    fun startLink(ctx: Context, url: String) {
        scope.launch {
            _reading.value = true
            try {
                val (header, tracks) = Music.allTracks(url, cap = Int.MAX_VALUE)
                if (tracks.isEmpty()) {
                    _messages.tryEmit("That playlist is empty")
                    return@launch
                }
                val name = header.ref.name.ifBlank { "Imported" }
                val id = Library.createPlaylist(name, tracks)
                _messages.tryEmit("Imported ${tracks.size.fmtSongs()} into \"$name\"")
                UiState.pending.value = UiState.Pending.OpenPlaylist(id)
            } catch (e: Exception) {
                _messages.tryEmit(Music.friendlyError(e))
            } finally {
                _reading.value = false
            }
        }
    }

    private fun Int.fmtSongs() = if (this == 1) "1 song" else "$this songs"

    /** Starts (or restarts, after the app was killed) the background import. */
    fun ensureRunning(ctx: Context) {
        if (nextRunning() == null) return
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, ImportService::class.java))
        } catch (_: Exception) {
            // Not allowed from the background on newer Android: it resumes next time Siren opens
        }
    }

    fun stop(jobId: String) = editJob(jobId) { if (it.running) it.copy(status = ImportJob.STOPPED) else it }

    fun stopAll() = edit { list -> list.map { if (it.running) it.copy(status = ImportJob.STOPPED) else it } }

    fun resume(ctx: Context, jobId: String) {
        editJob(jobId) { if (it.status == ImportJob.STOPPED && it.next < it.total) it.copy(status = ImportJob.RUNNING) else it }
        ensureRunning(ctx.applicationContext)
    }

    fun dismiss(jobId: String) = edit { list -> list.filterNot { it.id == jobId } }

    fun acceptUnsure(jobId: String, item: UnsureItem) {
        val j = job(jobId) ?: return
        Library.addToPlaylist(j.playlistId, listOf(item.track))
        editJob(jobId) { it.copy(unsure = it.unsure - item, matched = it.matched + 1) }
        tidy(jobId)
    }

    fun acceptAllUnsure(jobId: String) {
        val j = job(jobId) ?: return
        Library.addToPlaylist(j.playlistId, j.unsure.map { it.track })
        editJob(jobId) { it.copy(unsure = emptyList(), matched = it.matched + j.unsure.size) }
        tidy(jobId)
    }

    fun skipUnsure(jobId: String, item: UnsureItem) {
        editJob(jobId) { it.copy(unsure = it.unsure - item, missing = it.missing + item.label) }
    }

    fun forgetMissing(jobId: String, label: String) {
        editJob(jobId) { it.copy(missing = it.missing - label) }
        tidy(jobId)
    }

    /** A finished import with nothing left to look at goes away. */
    private fun tidy(jobId: String) {
        val j = job(jobId) ?: return
        if (!j.running && j.needsLook == 0 && j.next >= j.total) dismiss(jobId)
    }

    // ---------------- Doing the work (called by ImportService) ----------------

    private sealed interface Res {
        data class Found(val track: Track) : Res
        data class Unsure(val item: UnsureItem) : Res
        data class Missing(val label: String) : Res
        data object Error : Res
    }

    /** Imports the next batch of [jobId]'s songs. */
    suspend fun runBatch(jobId: String): Step {
        val job = job(jobId) ?: return Step.FINISHED
        if (!job.running) return Step.FINISHED
        if (Library.playlist(job.playlistId) == null) {
            // Playlist deleted mid-import: stop quietly
            dismiss(jobId)
            return Step.FINISHED
        }
        if (job.next >= job.total) {
            finish(jobId)
            return Step.FINISHED
        }
        val slice = job.items.subList(job.next, minOf(job.next + BATCH, job.total))
        val results = coroutineScope {
            slice.map { item -> async { gate.withPermit { resolve(item) } } }.awaitAll()
        }
        // Only keep what came before the first network error: the rest is retried after a pause
        val firstError = results.indexOfFirst { it is Res.Error }
        if (firstError == 0) {
            // No progress at all. After a few tries in a row, give up on that one song so a single
            // bad search can't hold the whole import hostage.
            val n = (stuck[jobId] ?: 0) + 1
            stuck[jobId] = n
            if (n >= 4) {
                stuck.remove(jobId)
                editJob(jobId) { j -> j.copy(next = j.next + 1, missing = j.missing + slice[0].label) }
                return Step.MORE
            }
        } else stuck.remove(jobId)
        val usable = if (firstError >= 0) results.subList(0, firstError) else results
        val found = usable.filterIsInstance<Res.Found>().map { it.track }
        if (found.isNotEmpty()) Library.addToPlaylist(job.playlistId, found)
        editJob(jobId) { j ->
            j.copy(
                next = j.next + usable.size,
                matched = j.matched + found.size,
                missing = j.missing + usable.filterIsInstance<Res.Missing>().map { it.label },
                unsure = j.unsure + usable.filterIsInstance<Res.Unsure>().map { it.item }
            )
        }
        val after = job(jobId) ?: return Step.FINISHED
        if (after.next >= after.total) {
            finish(jobId)
            return Step.FINISHED
        }
        if (!after.running) return Step.FINISHED
        return if (firstError >= 0) Step.WAIT else Step.MORE
    }

    private fun finish(jobId: String) {
        editJob(jobId) { it.copy(status = ImportJob.DONE) }
    }

    private suspend fun resolve(item: ImportItem): Res {
        if (item.videoId.isNotEmpty()) {
            if (item.title.isNotBlank()) {
                val url = watchUrl(item.videoId)
                return Res.Found(
                    Track(
                        url = url,
                        title = cleanTitle(item.title),
                        artist = cleanArtist(item.artist),
                        thumbnail = fallbackThumb(url),
                        album = item.album
                    )
                )
            }
            return byId(item)
        }
        return when (val r = Matcher.match(item)) {
            is Matcher.Result.Found -> Res.Found(r.track)
            is Matcher.Result.Unsure -> Res.Unsure(UnsureItem(item.label, r.best))
            Matcher.Result.Missing -> Res.Missing(item.label)
            Matcher.Result.Error -> Res.Error
        }
    }

    /** Title and channel for a video ID. oEmbed is one tiny request; the full lookup is the fallback. */
    private suspend fun byId(item: ImportItem): Res {
        val id = item.videoId
        val url = watchUrl(id)
        val o = oEmbed(url)
        if (o is OEmbed.Ok) return Res.Found(makeTrack(url, o.title, o.author, o.authorUrl, "", -1))
        if (o is OEmbed.Offline) return Res.Error
        return try {
            Res.Found(Music.stream(id).toTrackSafe())
        } catch (e: Exception) {
            if (e is java.net.UnknownHostException || e is java.net.SocketTimeoutException) Res.Error
            else Res.Missing(item.label)
        }
    }

    private fun org.schabi.newpipe.extractor.stream.StreamInfo.toTrackSafe(): Track =
        makeTrack(url ?: "", name ?: "", uploaderName ?: "", uploaderUrl ?: "", "", duration)

    private sealed interface OEmbed {
        data class Ok(val title: String, val author: String, val authorUrl: String) : OEmbed
        data object Gone : OEmbed
        data object Offline : OEmbed
    }

    private fun oEmbed(videoUrl: String): OEmbed = try {
        val req = Request.Builder()
            .url("https://www.youtube.com/oembed?format=json&url=" + URLEncoder.encode(videoUrl, "UTF-8"))
            .header("User-Agent", Net.USER_AGENT)
            .build()
        Net.client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) OEmbed.Gone
            else {
                val o = LibraryJson.json.parseToJsonElement(resp.body?.string().orEmpty()).jsonObject
                val title = o["title"]?.jsonPrimitive?.content.orEmpty()
                if (title.isBlank()) OEmbed.Gone
                else OEmbed.Ok(title, o["author_name"]?.jsonPrimitive?.content.orEmpty(), o["author_url"]?.jsonPrimitive?.content.orEmpty())
            }
        }
    } catch (e: java.net.UnknownHostException) {
        OEmbed.Offline
    } catch (e: java.net.SocketTimeoutException) {
        OEmbed.Offline
    } catch (e: Exception) {
        OEmbed.Gone
    }
}
