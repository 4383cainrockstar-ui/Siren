package app.siren.ui.screens

import androidx.compose.ui.graphics.Brush
import app.siren.ui.components.SirenLoader
import androidx.compose.material.icons.rounded.PhoneAndroid
import app.siren.data.LocalMusic
import app.siren.ui.components.pressClick
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.ArrowCircleDown
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.automirrored.rounded.ViewList
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import app.siren.core.ArtistRef
import app.siren.core.CollectionRef
import app.siren.core.Fmt
import app.siren.core.Music
import app.siren.core.Track
import app.siren.data.DownloadRecord
import app.siren.data.ImportExport
import app.siren.data.Importer
import app.siren.data.Library
import app.siren.data.LocalPlaylist
import app.siren.download.Downloads
import app.siren.player.PlayerController
import app.siren.ui.LocalActions
import app.siren.ui.Routes
import app.siren.ui.components.ActionRow
import app.siren.ui.components.ArtistRow
import app.siren.ui.components.Artwork
import app.siren.ui.components.Avatar
import app.siren.ui.components.BrandCover
import app.siren.ui.components.Chip
import app.siren.ui.components.ClearChip
import app.siren.ui.components.CollectionRow
import app.siren.ui.components.ConfirmDialog
import app.siren.ui.components.DeleteRow
import app.siren.ui.components.DlState
import app.siren.ui.components.EmptyState
import app.siren.ui.components.FindBar
import app.siren.ui.components.ListDownloadButton
import app.siren.ui.components.SelectionOverlay
import app.siren.ui.components.rememberSongSelection
import app.siren.ui.components.ListHeader
import app.siren.ui.components.ListPage
import app.siren.ui.components.LibraryRow
import app.siren.ui.components.NameDialog
import app.siren.ui.components.PrimaryButton
import app.siren.ui.components.RemoveFromHistoryRow
import app.siren.ui.components.SheetRow
import app.siren.ui.components.SirenMark
import app.siren.ui.components.SongSort
import app.siren.ui.components.SortPill
import app.siren.ui.components.TopBar
import app.siren.ui.components.TrackActionsSheet
import app.siren.ui.components.TrackRow
import app.siren.ui.components.downloadState
import app.siren.ui.components.rememberArtColor
import app.siren.ui.theme.Sc
import kotlinx.coroutines.launch
import java.util.Calendar

// =============================================================================================
// Your Library
// =============================================================================================

private enum class LibFilter(val label: String) { PLAYLISTS("Playlists"), ALBUMS("Albums"), ARTISTS("Artists"), DOWNLOADED("Downloaded") }

/** Everything that can show up in Your Library. */
private sealed class LibItem(val key: String, val name: String) {
    data object Liked : LibItem("liked", "Liked songs")
    data object Offline : LibItem("downloads", "Downloads")
    data object Device : LibItem("device", "On this device")
    class Playlist(val p: LocalPlaylist) : LibItem("p:" + p.id, p.name)
    class Folder(name: String, val playlists: List<LocalPlaylist>) : LibItem("f:$name", name)
    class Saved(val c: CollectionRef) : LibItem("c:" + c.url, c.name)
    class Artist(val a: ArtistRef) : LibItem("a:" + a.url, a.name)
}

@UnstableApi
@Composable
fun LibraryScreen() {
    val actions = LocalActions.current
    val ctxLib = LocalContext.current
    val lib by Library.data.collectAsState()
    val source by PlayerController.source.collectAsState()
    val current by PlayerController.current.collectAsState()
    var filter by rememberSaveable { mutableStateOf<LibFilter?>(null) }
    var alphabetical by rememberSaveable { mutableStateOf(false) }
    var grid by rememberSaveable { mutableStateOf(false) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var addMenu by remember { mutableStateOf(false) }
    var newPlaylist by remember { mutableStateOf(false) }
    var importing by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<LocalPlaylist?>(null) }

    val doneIds = remember(lib.downloads) {
        lib.downloads.filter { it.status == DownloadRecord.STATUS_DONE }.map { it.track.videoId }.toHashSet()
    }
    fun allOffline(tracks: List<Track>) = tracks.isNotEmpty() && tracks.all { it.videoId in doneIds }

    val localTracks by LocalMusic.tracks.collectAsState()
    val localFolders by LocalMusic.folders.collectAsState()
    val hasLocal = localFolders.isNotEmpty()
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            LocalMusic.addFolder(ctxLib, uri)
            actions.open(Routes.DEVICE)
        }
    }
    val libItems = remember(lib, filter, alphabetical, query, doneIds, hasLocal) {
        val pinned = buildList<LibItem> {
            if (filter == null || filter == LibFilter.PLAYLISTS || (filter == LibFilter.DOWNLOADED && allOffline(lib.liked))) add(LibItem.Liked)
            if (filter == null || filter == LibFilter.DOWNLOADED) add(LibItem.Offline)
            if (hasLocal && (filter == null || filter == LibFilter.DOWNLOADED || filter == LibFilter.PLAYLISTS)) add(LibItem.Device)
        }
        val playlists = lib.playlists.sortedByDescending { it.updatedAt }.map { LibItem.Playlist(it) }
        // Playlists filed in a folder show as the folder (searching shows them all, flat)
        val folderItems = lib.playlists.filter { it.folder.isNotBlank() }.groupBy { it.folder }
            .map { (n, l) -> LibItem.Folder(n, l.sortedByDescending { it.updatedAt }) }.sortedBy { it.name.lowercase() }
        val topLevel: List<LibItem> =
            if (query.isNotBlank()) playlists
            else folderItems + lib.playlists.filter { it.folder.isBlank() }.sortedByDescending { it.updatedAt }.map { LibItem.Playlist(it) }
        val rest: List<LibItem> = when (filter) {
            null -> topLevel + lib.saved.map { LibItem.Saved(it) } + lib.artists.map { LibItem.Artist(it) }
            LibFilter.PLAYLISTS -> topLevel + lib.saved.filter { !it.isAlbum }.map { LibItem.Saved(it) }
            LibFilter.ALBUMS -> lib.saved.filter { it.isAlbum }.map { LibItem.Saved(it) }
            LibFilter.ARTISTS -> lib.artists.map { LibItem.Artist(it) }
            LibFilter.DOWNLOADED -> playlists.filter { allOffline(it.p.tracks) }
        }
        val sorted = if (alphabetical) rest.sortedBy { it.name.lowercase() } else rest
        val all = pinned + sorted
        if (query.isBlank()) all else all.filter { it.name.contains(query.trim(), ignoreCase = true) }
    }

    val open: (LibItem) -> Unit = { item ->
        when (item) {
            LibItem.Liked -> actions.open(Routes.LIKED)
            LibItem.Offline -> actions.open(Routes.DOWNLOADS)
            LibItem.Device -> actions.open(Routes.DEVICE)
            is LibItem.Playlist -> actions.local(item.p.id)
            is LibItem.Folder -> actions.folder(item.name)
            is LibItem.Saved -> actions.collection(item.c.url)
            is LibItem.Artist -> actions.artist(item.a.url)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(start = 16.dp, end = 4.dp, top = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SirenMark(size = 30.dp)
            Spacer(Modifier.width(12.dp))
            Text("Your Library", color = Sc.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp, modifier = Modifier.weight(1f))
            IconButton(onClick = { searching = !searching; if (!searching) query = "" }) {
                Icon(if (searching) Icons.Rounded.Close else Icons.Rounded.Search, "Search your library", tint = Sc.Text)
            }
            IconButton(onClick = { addMenu = true }) { Icon(Icons.Rounded.Add, "Create", tint = Sc.Text, modifier = Modifier.size(28.dp)) }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val f = filter
            if (f != null) {
                item { ClearChip { filter = null } }
                item { Chip(f.label, true, { filter = null }) }
            } else {
                items(LibFilter.entries) { opt -> Chip(opt.label, false, { filter = opt }) }
            }
        }

        if (searching) {
            FindBar(query, { query = it }, "Search Your Library", Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp))
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 8.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable { alphabetical = !alphabetical }
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.SwapVert, null, tint = Sc.Text, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (alphabetical) "Alphabetical" else "Recents", color = Sc.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { grid = !grid }) {
                Icon(if (grid) Icons.AutoMirrored.Rounded.ViewList else Icons.Rounded.GridView, if (grid) "List view" else "Grid view", tint = Sc.Text, modifier = Modifier.size(20.dp))
            }
        }

        val playingKey = when {
            current == null -> null
            source == "Liked songs" -> "liked"
            source == "Downloads" -> "downloads"
            else -> lib.playlists.firstOrNull { it.name == source }?.let { "p:" + it.id }
                ?: lib.saved.firstOrNull { it.name == source }?.let { "c:" + it.url }
        }

        if (lib.playlists.isEmpty() && lib.saved.isEmpty() && lib.artists.isEmpty() && filter == null && query.isBlank()) {
            // Nothing of your own yet: point at the two ways in
            LazyColumn(Modifier.fillMaxSize()) {
                items(libItems, key = { it.key }) { item -> Box(Modifier.animateItem()) { LibListRow(item, lib.liked.size, doneIds.size, playingKey == item.key, open, null)  }}
                item {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Bring your music over", color = Sc.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Import from Spotify (Exportify) or YouTube Music (Google Takeout), paste a playlist link, or use a text list.",
                            color = Sc.TextDim, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(Modifier.height(18.dp))
                        PrimaryButton("Import playlist", { importing = true }, icon = Icons.Rounded.FileUpload)
                        Spacer(Modifier.height(10.dp))
                        TextButton(onClick = { newPlaylist = true }) { Text("Create a playlist", color = Sc.Text, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        } else if (grid) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 28.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(libItems, key = { it.key }) { item ->
                    LibGridCell(item, lib.liked.size, doneIds.size, open, onLong = { (item as? LibItem.Playlist)?.let { menuFor = it.p } })
                }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
                items(libItems, key = { it.key }) { item ->
                    LibListRow(item, lib.liked.size, doneIds.size, playingKey == item.key, open, onLong = { (item as? LibItem.Playlist)?.let { menuFor = it.p } })
                }
                if (libItems.isEmpty()) item {
                    EmptyState(Icons.Rounded.Search, "Nothing here", if (query.isNotBlank()) "Nothing in your library matches \"$query\"." else "Nothing in this filter yet.")
                }
            }
        }
    }

    if (addMenu) {
        ModalBottomSheet(
            onDismissRequest = { addMenu = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Sc.Sheet
        ) {
            Column(Modifier.padding(bottom = 24.dp)) {
                SheetRow(Icons.AutoMirrored.Rounded.PlaylistAdd, "Create playlist") { addMenu = false; newPlaylist = true }
                SheetRow(Icons.Rounded.FileUpload, "Import playlists (Spotify, YouTube Music, link)") { addMenu = false; importing = true }
                SheetRow(Icons.Rounded.CreateNewFolder, "Add a music folder from this phone") { addMenu = false; pickFolder.launch(null) }
            }
        }
    }
    if (newPlaylist) {
        NameDialog("Give your playlist a name", "", onDismiss = { newPlaylist = false }) { name ->
            val id = Library.createPlaylist(name)
            newPlaylist = false
            actions.local(id)
        }
    }
    if (importing) ImportSheet(onDismiss = { importing = false })
    menuFor?.let { p -> PlaylistQuickSheet(p, onDismiss = { menuFor = null }) }
}

@Composable
private fun LibCover(item: LibItem, modifier: Modifier = Modifier) {
    when (item) {
        LibItem.Liked -> BrandCover(Icons.Rounded.Favorite, Sc.likedCover, modifier)
        LibItem.Offline -> BrandCover(Icons.Rounded.ArrowCircleDown, Sc.downloadsCover, modifier)
        LibItem.Device -> BrandCover(Icons.Rounded.PhoneAndroid, DEVICE_COVER, modifier)
        is LibItem.Playlist -> PlaylistCover(item.p.tracks, modifier)
        is LibItem.Folder -> PlaylistCover(item.playlists.flatMap { it.tracks.take(1) }, modifier)
        is LibItem.Saved -> Artwork(item.c.thumbnail, modifier, icon = Icons.Rounded.Album)
        is LibItem.Artist -> Avatar(item.a.avatar, 64.dp, modifier)
    }
}

private fun libSubtitle(item: LibItem, liked: Int, offline: Int): String = when (item) {
    LibItem.Liked -> "Playlist • " + Fmt.songs(liked)
    LibItem.Offline -> "Playlist • " + Fmt.songs(offline)
    LibItem.Device -> "Music files • " + Fmt.songs(LocalMusic.tracks.value.size)
    is LibItem.Playlist -> "Playlist • " + Fmt.songs(item.p.tracks.size)
    is LibItem.Folder -> "Folder • " + item.playlists.size + if (item.playlists.size == 1) " playlist" else " playlists"
    is LibItem.Saved -> listOf(if (item.c.isAlbum) "Album" else "Playlist", item.c.author).filter { it.isNotBlank() }.joinToString(" • ")
    is LibItem.Artist -> "Artist"
}

@Composable
private fun LibListRow(item: LibItem, liked: Int, offline: Int, playing: Boolean, open: (LibItem) -> Unit, onLong: (() -> Unit)?) {
    LibraryRow(
        title = item.name,
        subtitle = libSubtitle(item, liked, offline),
        onClick = { open(item) },
        circle = item is LibItem.Artist,
        pinned = item is LibItem.Liked || item is LibItem.Offline || item is LibItem.Device,
        playing = playing,
        onLongClick = onLong,
        cover = { if (item is LibItem.Artist) Avatar(item.a.avatar, 64.dp) else LibCover(item, Modifier.fillMaxSize()) }
    )
}

@Composable
private fun LibGridCell(item: LibItem, liked: Int, offline: Int, open: (LibItem) -> Unit, onLong: () -> Unit) {
    Column(
        Modifier.pressClick(onLongClick = onLong, onClick = { open(item) }),
        horizontalAlignment = if (item is LibItem.Artist) Alignment.CenterHorizontally else Alignment.Start
    ) {
        if (item is LibItem.Artist) {
            androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth()) {
                Avatar(item.a.avatar, maxWidth)
            }
        } else {
            LibCover(item, Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(6.dp))
        Text(item.name, color = Sc.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(libSubtitle(item, liked, offline), color = Sc.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Long-press on a playlist in Your Library. */
@UnstableApi
@Composable
private fun PlaylistQuickSheet(p: LocalPlaylist, onDismiss: () -> Unit) {
    val actions = LocalActions.current
    var confirm by remember { mutableStateOf(false) }
    var pick by remember { mutableStateOf(false) }
    if (pick) {
        FolderPickerSheet(p, onDismiss = { pick = false; onDismiss() })
        return
    }
    if (confirm) {
        ConfirmDialog("Delete \"${p.name}\"?", "The playlist goes. The songs stay wherever else you saved them.", "Delete", onDismiss = { confirm = false; onDismiss() }) {
            Library.deletePlaylist(p.id)
        }
        return
    }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Sc.Sheet
    ) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Artwork(p.tracks.firstOrNull()?.thumbnail ?: "", Modifier.size(48.dp), icon = Icons.AutoMirrored.Rounded.QueueMusic)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(p.name, color = Sc.Text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(Fmt.songs(p.tracks.size), color = Sc.TextDim, fontSize = 13.sp)
                }
            }
            HorizontalDivider(color = Sc.Outline, modifier = Modifier.padding(vertical = 6.dp))
            if (p.tracks.isNotEmpty()) {
                SheetRow(Icons.Rounded.PlayArrow, "Play") { actions.playAll(p.tracks, source = p.name); onDismiss() }
                SheetRow(Icons.Rounded.Shuffle, "Shuffle") { actions.playAll(p.tracks, shuffle = true, source = p.name); onDismiss() }
                SheetRow(Icons.Rounded.Download, "Download all") { actions.download(p.tracks); onDismiss() }
                SheetRow(Icons.AutoMirrored.Rounded.QueueMusic, "Add all to queue") { PlayerController.addToQueue(p.tracks); onDismiss() }
                SheetRow(Icons.Rounded.Share, "Share") { actions.shareTracks(p.name, p.tracks); onDismiss() }
            }
            val dups = Library.duplicateCount(p.id)
            if (dups > 0) SheetRow(Icons.Rounded.ContentCopy, "Remove $dups duplicate " + if (dups == 1) "song" else "songs") {
                val n = Library.removeDuplicates(p.id)
                actions.message("Removed $n duplicate " + if (n == 1) "song" else "songs")
                onDismiss()
            }
            SheetRow(Icons.Rounded.Folder, if (p.folder.isBlank()) "Move to folder" else "Folder: ${p.folder}") { pick = true }
            SheetRow(Icons.Rounded.Delete, "Delete playlist", tint = Sc.Error) { confirm = true }
        }
    }
}

// =============================================================================================
// Song lists: Liked songs, your playlists
// =============================================================================================

/**
 * Shared page for a list of songs: color header, download / shuffle / play row,
 * find + sort, then the songs.
 */
@UnstableApi
@Composable
fun SongListPage(
    title: String,
    owner: String,
    meta: String,
    tracks: List<Track>,
    source: String,
    tint: Color,
    cover: @Composable () -> Unit,
    empty: @Composable () -> Unit,
    sortable: Boolean = true,
    leftActions: @Composable RowScope.() -> Unit = {},
    topActions: @Composable RowScope.() -> Unit = {},
    extraMenu: (@Composable (Track, Int, () -> Unit) -> Unit)? = null,
    customOrder: Boolean = true,
    banner: (@Composable () -> Unit)? = null
) {
    val actions = LocalActions.current
    val current by PlayerController.current.collectAsState()
    val playing by PlayerController.isPlaying.collectAsState()
    val currentSource by PlayerController.source.collectAsState()
    val playerShuffle by PlayerController.shuffle.collectAsState()
    val lib by Library.data.collectAsState()
    val state = rememberLazyListState()
    var menuFor by remember { mutableStateOf<Pair<Track, Int>?>(null) }
    var find by rememberSaveable { mutableStateOf("") }
    var sort by rememberSaveable { mutableStateOf(if (customOrder) SongSort.CUSTOM else SongSort.RECENT) }
    var localShuffle by remember { mutableStateOf(false) }
    val sel = rememberSongSelection()

    val here = current != null && currentSource == source
    val shuffle = if (here) playerShuffle else localShuffle
    val ordered = remember(tracks, sort) { sort.order(tracks, recentFirst = !customOrder) }
    val shown = remember(ordered, find) {
        if (find.isBlank()) ordered.withIndex().toList()
        else ordered.withIndex().filter { (_, t) -> t.title.contains(find, true) || t.artist.contains(find, true) || t.album.contains(find, true) }
    }
    val doneIds = remember(lib.downloads) {
        lib.downloads.filter { it.status == DownloadRecord.STATUS_DONE }.map { it.track.videoId }.toHashSet()
    }

    ListPage(
        state, title, tint, onBack = { actions.back() }, topActions = topActions,
        overlay = { SelectionOverlay(sel, shown.map { it.value }) }
    ) {
        item(key = "header") {
            ListHeader(title = title, owner = owner, meta = meta, tint = tint, cover = cover)
        }
        item(key = "actions") {
            ActionRow(
                playing = here && playing,
                shuffle = shuffle,
                onShuffle = { if (here) PlayerController.toggleShuffle() else localShuffle = !localShuffle },
                onPlay = {
                    when {
                        here -> PlayerController.togglePlay()
                        ordered.isEmpty() -> actions.message("Nothing to play yet")
                        else -> actions.playAll(ordered, shuffle = shuffle, source = source)
                    }
                },
                left = leftActions
            )
        }
        if (banner != null) item(key = "banner") { banner() }
        if (tracks.size > 6 && sortable) {
            item(key = "find") {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FindBar(find, { find = it }, "Find in $title", Modifier.weight(1f))
                    SortPill(sort.label, { sort = sort.next(customOrder) })
                }
            }
        }
        if (tracks.isEmpty()) item(key = "empty") { empty() }
        items(shown, key = { (i, t) -> t.videoId + "#" + i }) { (i, t) -> Box(Modifier.animateItem()) {
            TrackRow(
                track = t,
                playing = current?.videoId == t.videoId,
                isPlaying = playing,
                downloaded = t.videoId in doneIds,
                onClick = { if (sel.active) sel.toggle(t) else actions.playAll(ordered, i, shuffle = false, source = source) },
                onMore = if (sel.active) null else ({ menuFor = t to i }),
                onLongClick = { sel.toggle(t) },
                selected = if (sel.active) sel.isSelected(t) else null
            )
         }}
        if (find.isNotBlank() && shown.isEmpty()) item(key = "nofind") {
            Text("No songs match \"$find\"", color = Sc.TextDim, modifier = Modifier.padding(24.dp))
        }
    }

    menuFor?.let { (t, i) ->
        // Menu actions that reorder use the position in the stored list, not the sorted view
        val storedIndex = if (sort == SongSort.CUSTOM) i else tracks.indexOfFirst { it.videoId == t.videoId }
        TrackActionsSheet(
            t,
            onDismiss = { menuFor = null },
            extra = { close -> extraMenu?.invoke(t, if (sort == SongSort.CUSTOM) storedIndex else -1, close) }
        )
    }
}

@UnstableApi
@Composable
fun LikedScreen() {
    val lib by Library.data.collectAsState()
    val tracks = lib.liked
    SongListPage(
        title = "Liked songs",
        owner = "",
        meta = listOf(Fmt.songs(tracks.size), Fmt.totalMinutes(tracks)).filter { it.isNotBlank() }.joinToString(" • "),
        tracks = tracks,
        source = "Liked songs",
        tint = Color(0xFF7A1530),
        cover = { BrandCover(Icons.Rounded.Favorite, Sc.likedCover, Modifier.fillMaxSize()) },
        empty = { EmptyState(Icons.Rounded.Favorite, "Songs you like show up here", "Tap + on the player, or long-press any song.") },
        leftActions = { ListDownloadButton(tracks) },
        customOrder = false
    )
}

@UnstableApi
@Composable
fun LocalPlaylistScreen(id: String) {
    val actions = LocalActions.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val lib by Library.data.collectAsState()
    val p = lib.playlists.firstOrNull { it.id == id }
    var rename by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var pickFolder by remember { mutableStateOf(false) }

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        val pl = p
        if (uri != null && pl != null) scope.launch {
            try {
                ImportExport.exportPlaylistCsv(ctx, pl, uri)
                actions.message("Exported ${pl.name}")
            } catch (e: Exception) {
                actions.message(Music.friendlyError(e))
            }
        }
    }

    if (p == null) {
        Column(Modifier.fillMaxSize()) {
            TopBar("Playlist", onBack = { actions.back() })
            EmptyState(Icons.AutoMirrored.Rounded.QueueMusic, "Playlist not found", "It may have been deleted.")
        }
        return
    }

    val tracks = p.tracks
    val importJobs by Importer.jobs.collectAsState()
    val importing = importJobs.any { it.playlistId == p.id && it.running }
    val art = tracks.firstOrNull()?.thumbnail ?: ""
    val tint = rememberArtColor(art, Sc.SurfaceHighest)
    SongListPage(
        title = p.name,
        owner = "You",
        meta = listOf("Playlist", Fmt.songs(tracks.size), Fmt.totalMinutes(tracks)).filter { it.isNotBlank() }.joinToString(" • "),
        tracks = tracks,
        source = p.name,
        tint = tint,
        cover = { PlaylistCover(tracks, Modifier.fillMaxSize()) },
        empty = {
            if (importing) EmptyState(Icons.Rounded.MusicNote, "Finding your songs…", "They show up here as they're found.")
            else EmptyState(Icons.Rounded.MusicNote, "Let's fill this up", "Long-press any song and choose \"Add to playlist\".", action = {
                PrimaryButton("Find songs", { actions.tab(Routes.SEARCH) }, icon = Icons.Rounded.Search)
            })
        },
        banner = { ImportBanner(p.id) },
        leftActions = {
            ListDownloadButton(tracks)
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Playlist options", tint = Sc.TextDim) }
        },
        extraMenu = { t, i, close ->
            if (i > 0) SheetRow(Icons.Rounded.ArrowUpward, "Move up") { Library.movePlaylistItem(p.id, i, i - 1); close() }
            if (i >= 0 && i < tracks.size - 1) SheetRow(Icons.Rounded.ArrowDownward, "Move down") { Library.movePlaylistItem(p.id, i, i + 1); close() }
            DeleteRow("Remove from this playlist", close) { Library.removeFromPlaylist(p.id, t) }
        }
    )

    if (menu) {
        ModalBottomSheet(
            onDismissRequest = { menu = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Sc.Sheet
        ) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Text(p.name, color = Sc.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
                HorizontalDivider(color = Sc.Outline, modifier = Modifier.padding(vertical = 6.dp))
                SheetRow(Icons.Rounded.Edit, "Rename") { menu = false; rename = true }
                if (tracks.isNotEmpty()) {
                    SheetRow(Icons.Rounded.Download, "Download all") { actions.download(tracks); menu = false }
                    SheetRow(Icons.AutoMirrored.Rounded.QueueMusic, "Add all to queue") { PlayerController.addToQueue(tracks); menu = false }
                    SheetRow(Icons.Rounded.Share, "Share") { actions.shareTracks(p.name, tracks); menu = false }
                    SheetRow(Icons.Rounded.FileDownload, "Export as CSV") {
                        menu = false
                        exporter.launch(p.name.replace(Regex("[^A-Za-z0-9 _-]"), "").ifBlank { "playlist" } + ".csv")
                    }
                }
                val dups = Library.duplicateCount(p.id)
                if (dups > 0) SheetRow(Icons.Rounded.ContentCopy, "Remove $dups duplicate " + if (dups == 1) "song" else "songs") {
                    menu = false
                    val n = Library.removeDuplicates(p.id)
                    actions.message("Removed $n duplicate " + if (n == 1) "song" else "songs")
                }
                SheetRow(Icons.Rounded.Folder, if (p.folder.isBlank()) "Move to folder" else "Folder: ${p.folder}") { menu = false; pickFolder = true }
                SheetRow(Icons.Rounded.Delete, "Delete playlist", tint = Sc.Error) { menu = false; confirmDelete = true }
            }
        }
    }
    if (pickFolder) FolderPickerSheet(p, onDismiss = { pickFolder = false })
    if (rename) {
        NameDialog("Rename playlist", p.name, onDismiss = { rename = false }) {
            Library.renamePlaylist(p.id, it)
            rename = false
        }
    }
    if (confirmDelete) {
        ConfirmDialog("Delete \"${p.name}\"?", "The playlist goes. The songs stay wherever else you saved them.", "Delete", onDismiss = { confirmDelete = false }) {
            Library.deletePlaylist(p.id)
            actions.back()
        }
    }
}

/** Pick (or make) the folder a playlist is filed in. */
@UnstableApi
@Composable
private fun FolderPickerSheet(p: LocalPlaylist, onDismiss: () -> Unit) {
    val lib by Library.data.collectAsState()
    var newFolder by remember { mutableStateOf(false) }
    if (newFolder) {
        NameDialog("New folder", "", onDismiss = { newFolder = false }) { name ->
            if (name.isNotBlank()) Library.setFolder(p.id, name)
            newFolder = false
            onDismiss()
        }
        return
    }
    val folders = remember(lib.playlists) { Library.folders() }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Sc.Sheet
    ) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Text("Move \"${p.name}\" to", color = Sc.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            HorizontalDivider(color = Sc.Outline, modifier = Modifier.padding(vertical = 6.dp))
            SheetRow(Icons.Rounded.CreateNewFolder, "New folder…") { newFolder = true }
            folders.forEach { f ->
                SheetRow(Icons.Rounded.Folder, f, tint = if (p.folder == f) Sc.Accent else Sc.Text) {
                    Library.setFolder(p.id, f)
                    onDismiss()
                }
            }
            if (p.folder.isNotBlank()) SheetRow(Icons.Rounded.Close, "Take out of \"${p.folder}\"") {
                Library.setFolder(p.id, "")
                onDismiss()
            }
        }
    }
}

/** The playlists inside one folder of Your Library. */
@UnstableApi
@Composable
fun FolderScreen(name: String) {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    val inFolder = lib.playlists.filter { it.folder == name }.sortedByDescending { it.updatedAt }
    var rename by remember { mutableStateOf(false) }
    var removeFolder by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<LocalPlaylist?>(null) }

    Column(Modifier.fillMaxSize()) {
        TopBar(name, onBack = { actions.back() }) {
            IconButton(onClick = { rename = true }) { Icon(Icons.Rounded.Edit, "Rename folder", tint = Sc.Text) }
            IconButton(onClick = { removeFolder = true }) { Icon(Icons.Rounded.Delete, "Remove folder", tint = Sc.Text) }
        }
        if (inFolder.isEmpty()) {
            EmptyState(Icons.Rounded.Folder, "Empty folder", "Move playlists in from their menu (long-press a playlist).")
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
                items(inFolder, key = { it.id }) { p -> Box(Modifier.animateItem()) {
                    LibraryRow(
                        title = p.name,
                        subtitle = "Playlist • " + Fmt.songs(p.tracks.size),
                        onClick = { actions.local(p.id) },
                        onLongClick = { menuFor = p },
                        cover = { PlaylistCover(p.tracks, Modifier.fillMaxSize()) }
                    )
                 }}
            }
        }
    }
    menuFor?.let { PlaylistQuickSheet(it, onDismiss = { menuFor = null }) }
    if (rename) {
        NameDialog("Rename folder", name, onDismiss = { rename = false }) {
            Library.renameFolder(name, it)
            rename = false
            actions.back()
        }
    }
    if (removeFolder) {
        ConfirmDialog("Remove folder \"$name\"?", "The playlists stay in your library, just not in a folder.", "Remove", onDismiss = { removeFolder = false }) {
            Library.ungroupFolder(name)
            removeFolder = false
            actions.back()
        }
    }
}

/** A 2x2 mosaic of the first four covers, or a single cover for short playlists. */
@Composable
fun PlaylistCover(tracks: List<Track>, modifier: Modifier = Modifier) {
    val arts = tracks.map { it.thumbnail }.filter { it.isNotBlank() }.distinct()
    if (arts.size < 4) {
        Artwork(arts.firstOrNull() ?: "", modifier, icon = Icons.AutoMirrored.Rounded.QueueMusic, big = true)
    } else {
        Column(modifier.clip(RoundedCornerShape(4.dp))) {
            Row(Modifier.weight(1f)) {
                Artwork(arts[0], Modifier.weight(1f), corner = 0.dp)
                Artwork(arts[1], Modifier.weight(1f), corner = 0.dp)
            }
            Row(Modifier.weight(1f)) {
                Artwork(arts[2], Modifier.weight(1f), corner = 0.dp)
                Artwork(arts[3], Modifier.weight(1f), corner = 0.dp)
            }
        }
    }
}

// =============================================================================================
// Downloads
// =============================================================================================

@UnstableApi
@Composable
fun DownloadsScreen() {
    val actions = LocalActions.current
    val ctx = LocalContext.current
    val lib by Library.data.collectAsState()
    val current by PlayerController.current.collectAsState()
    val playing by PlayerController.isPlaying.collectAsState()
    val currentSource by PlayerController.source.collectAsState()
    val playerShuffle by PlayerController.shuffle.collectAsState()
    val state = rememberLazyListState()
    var menuFor by remember { mutableStateOf<DownloadRecord?>(null) }
    var localShuffle by remember { mutableStateOf(false) }
    var find by rememberSaveable { mutableStateOf("") }
    val done = lib.downloads.filter { it.status == DownloadRecord.STATUS_DONE }.map { it.track }
    val active = lib.downloads.count { it.status == DownloadRecord.STATUS_RUNNING || it.status == DownloadRecord.STATUS_QUEUED }
    val failed = lib.downloads.filter { it.status == DownloadRecord.STATUS_FAILED }
    val sel = rememberSongSelection()
    val here = current != null && currentSource == "Downloads"
    val shuffle = if (here) playerShuffle else localShuffle
    val shown = if (find.isBlank()) lib.downloads
    else lib.downloads.filter { it.track.title.contains(find, true) || it.track.artist.contains(find, true) }

    ListPage(
        state, "Downloads", Color(0xFF2A2A2A), onBack = { actions.back() },
        overlay = { SelectionOverlay(sel, shown.map { it.track }) }
    ) {
        item(key = "header") {
            ListHeader(
                title = "Downloads",
                owner = "",
                meta = listOfNotNull(
                    Fmt.songs(done.size),
                    Fmt.bytes(lib.downloads.sumOf { it.sizeBytes }).ifBlank { null },
                    if (active > 0) "$active downloading" else null
                ).joinToString(" • ") + "\nSaved to Music/Siren • plays with no connection",
                tint = Color(0xFF3A3A3A),
                cover = { BrandCover(Icons.Rounded.ArrowCircleDown, Sc.downloadsCover, Modifier.fillMaxSize()) }
            )
        }
        if (active > 0) item(key = "cancel") {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("$active waiting or downloading", color = Sc.TextDim, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Box(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Sc.Surface)
                        .clickable {
                            Downloads.cancelAll(ctx)
                            actions.message("Downloads stopped")
                        }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text("Cancel all", color = Sc.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        item(key = "actions") {
            ActionRow(
                playing = here && playing,
                shuffle = shuffle,
                onShuffle = { if (here) PlayerController.toggleShuffle() else localShuffle = !localShuffle },
                onPlay = {
                    when {
                        here -> PlayerController.togglePlay()
                        done.isEmpty() -> actions.message("Nothing downloaded yet")
                        else -> actions.playAll(done, shuffle = shuffle, source = "Downloads")
                    }
                }
            ) {
                if (failed.isNotEmpty()) {
                    IconButton(onClick = { failed.forEach { Downloads.retry(ctx, it) } }) {
                        Icon(Icons.Rounded.Refresh, "Retry failed downloads", tint = Sc.TextDim, modifier = Modifier.size(28.dp))
                    }
                }
            }
        }
        if (lib.downloads.size > 6) {
            item(key = "find") {
                FindBar(find, { find = it }, "Find in downloads", Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp))
            }
        }
        if (lib.downloads.isEmpty()) item(key = "empty") {
            EmptyState(Icons.Rounded.Download, "Nothing downloaded", "Tap the download button on any playlist or album, or long-press a song.")
        }
        items(shown, key = { it.id }) { r -> Box(Modifier.animateItem()) {
            val status = when (r.status) {
                DownloadRecord.STATUS_DONE -> listOf(r.track.artist, Fmt.bytes(r.sizeBytes)).filter { it.isNotBlank() }.joinToString(" • ")
                DownloadRecord.STATUS_RUNNING -> "Downloading " + (r.progress * 100).toInt() + "%"
                DownloadRecord.STATUS_QUEUED -> r.error.ifBlank { "Waiting…" }
                else -> r.error.ifBlank { "Failed" } + " • tap to retry"
            }
            TrackRow(
                track = r.track,
                playing = current?.videoId == r.track.videoId,
                isPlaying = playing,
                subtitle = status,
                downloaded = r.status == DownloadRecord.STATUS_DONE,
                onClick = {
                    when {
                        sel.active -> sel.toggle(r.track)
                        r.status == DownloadRecord.STATUS_DONE -> actions.playAll(done, done.indexOfFirst { it.videoId == r.track.videoId }.coerceAtLeast(0), source = "Downloads")
                        r.status == DownloadRecord.STATUS_FAILED -> Downloads.retry(ctx, r)
                        else -> Unit
                    }
                },
                onMore = if (sel.active) null else ({ menuFor = r }),
                onLongClick = { sel.toggle(r.track) },
                selected = if (sel.active) sel.isSelected(r.track) else null,
                trailing = {
                    when (r.status) {
                        DownloadRecord.STATUS_RUNNING, DownloadRecord.STATUS_QUEUED ->
                            CircularProgressIndicator(
                                progress = { r.progress },
                                color = Sc.Accent, trackColor = Sc.SurfaceHighest, strokeWidth = 2.dp,
                                modifier = Modifier.size(20.dp)
                            )
                        DownloadRecord.STATUS_FAILED -> Icon(Icons.Rounded.ErrorOutline, "Failed", tint = Sc.Error, modifier = Modifier.size(20.dp))
                        else -> Unit
                    }
                }
            )
         }}
    }

    menuFor?.let { r ->
        ModalBottomSheet(
            onDismissRequest = { menuFor = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = Sc.Sheet
        ) {
            Column(Modifier.padding(bottom = 24.dp)) {
                Text(r.track.title, color = Sc.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
                HorizontalDivider(color = Sc.Outline, modifier = Modifier.padding(vertical = 6.dp))
                if (r.status == DownloadRecord.STATUS_FAILED) {
                    SheetRow(Icons.Rounded.Refresh, "Retry") { Downloads.retry(ctx, r); menuFor = null }
                }
                if (r.status == DownloadRecord.STATUS_DONE) {
                    SheetRow(Icons.Rounded.SkipNext, "Play next") { PlayerController.playNext(listOf(r.track)); menuFor = null }
                    SheetRow(Icons.AutoMirrored.Rounded.QueueMusic, "Add to queue") { PlayerController.addToQueue(listOf(r.track)); menuFor = null }
                    SheetRow(Icons.Rounded.Delete, "Delete download", tint = Sc.Error) { Downloads.remove(ctx, r, deleteFile = true); menuFor = null }
                    SheetRow(Icons.Rounded.DeleteSweep, "Remove from list (keep the file)") { Downloads.remove(ctx, r, deleteFile = false); menuFor = null }
                } else {
                    SheetRow(Icons.Rounded.Close, "Cancel download", tint = Sc.Error) { Downloads.remove(ctx, r, deleteFile = false); menuFor = null }
                }
            }
        }
    }
}

// =============================================================================================
// History, artists, saved
// =============================================================================================

private fun dayBucket(epoch: Long): String {
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = epoch }
    val days = ((startOfDay(now) - startOfDay(then)) / 86_400_000L).toInt()
    return when {
        days <= 0 -> "Today"
        days == 1 -> "Yesterday"
        days < 7 -> "This week"
        days < 31 -> "This month"
        else -> "Earlier"
    }
}

private fun startOfDay(c: Calendar): Long {
    val x = c.clone() as Calendar
    x.set(Calendar.HOUR_OF_DAY, 0)
    x.set(Calendar.MINUTE, 0)
    x.set(Calendar.SECOND, 0)
    x.set(Calendar.MILLISECOND, 0)
    return x.timeInMillis
}

@UnstableApi
@Composable
fun HistoryScreen() {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    val current by PlayerController.current.collectAsState()
    val playing by PlayerController.isPlaying.collectAsState()
    var menuFor by remember { mutableStateOf<Track?>(null) }
    var confirm by remember { mutableStateOf(false) }
    val tracks = lib.history.map { it.track }
    val groups = remember(lib.history) { lib.history.withIndex().groupBy { dayBucket(it.value.lastPlayed) } }
    val sel = rememberSongSelection()

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize()) {
        TopBar("Recently played", onBack = { actions.back() }) {
            if (lib.history.isNotEmpty()) TextButton(onClick = { confirm = true }) { Text("Clear", color = Sc.Text, fontWeight = FontWeight.Bold) }
        }
        if (lib.history.isEmpty()) {
            EmptyState(Icons.Rounded.History, "Nothing played yet", "Songs you play show up here.")
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
                groups.forEach { (label, rows) ->
                    item(key = "g:$label") {
                        Text(label, color = Sc.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 6.dp))
                    }
                    items(rows, key = { it.value.track.videoId }) { (i, h) -> Box(Modifier.animateItem()) {
                        TrackRow(
                            track = h.track,
                            playing = current?.videoId == h.track.videoId,
                            isPlaying = playing,
                            subtitle = listOf(h.track.artist, if (h.plays > 1) "${h.plays} plays" else "").filter { it.isNotBlank() }.joinToString(" • "),
                            onClick = { if (sel.active) sel.toggle(h.track) else actions.playAll(tracks, i, source = "Recently played") },
                            onMore = if (sel.active) null else ({ menuFor = h.track }),
                            onLongClick = { sel.toggle(h.track) },
                            selected = if (sel.active) sel.isSelected(h.track) else null
                        )
                     }}
                }
            }
        }
    }
    SelectionOverlay(sel, tracks)
    }
    menuFor?.let { t ->
        TrackActionsSheet(t, onDismiss = { menuFor = null }, extra = { close -> RemoveFromHistoryRow(t, close) })
    }
    if (confirm) {
        ConfirmDialog("Clear listening history?", "This also resets Quick picks and Your mixes on Home.", "Clear", onDismiss = { confirm = false }) {
            Library.clearHistory()
        }
    }
}

@UnstableApi
@Composable
fun ArtistsScreen() {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    Column(Modifier.fillMaxSize()) {
        TopBar("Artists", onBack = { actions.back() })
        if (lib.artists.isEmpty()) {
            EmptyState(Icons.Rounded.Person, "Not following anyone", "Open an artist and tap Follow. Their new songs show up on Home.")
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
                items(lib.artists.sortedBy { it.name.lowercase() }, key = { it.url }) { a -> Box(Modifier.animateItem()) {
                    ArtistRow(a, onClick = { actions.artist(a.url) })
                 }}
            }
        }
    }
}

@UnstableApi
@Composable
fun SavedScreen() {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    Column(Modifier.fillMaxSize()) {
        TopBar("Albums & playlists", onBack = { actions.back() })
        if (lib.saved.isEmpty()) {
            EmptyState(Icons.Rounded.Album, "Nothing saved", "Open any album or YouTube Music playlist and tap Save.")
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
                items(lib.saved, key = { it.url }) { c -> Box(Modifier.animateItem()) {
                    CollectionRow(c, onClick = { actions.collection(c.url) })
                 }}
            }
        }
    }
}

private val DEVICE_COVER = Brush.linearGradient(listOf(Color(0xFF2B2B33), Color(0xFF0A0A0C)))

/** Songs from folders on the phone. */
@UnstableApi
@Composable
fun LocalFilesScreen() {
    val ctx = LocalContext.current
    val tracks by LocalMusic.tracks.collectAsState()
    val folders by LocalMusic.folders.collectAsState()
    val scan by LocalMusic.scan.collectAsState()
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) LocalMusic.addFolder(ctx, uri)
    }
    SongListPage(
        title = "On this device",
        owner = "",
        meta = listOf(Fmt.songs(tracks.size), Fmt.totalMinutes(tracks)).filter { it.isNotBlank() }.joinToString(" • "),
        tracks = tracks,
        source = "On this device",
        tint = Color(0xFF2B2B33),
        cover = { BrandCover(Icons.Rounded.PhoneAndroid, DEVICE_COVER, Modifier.fillMaxSize()) },
        empty = {
            EmptyState(
                Icons.Rounded.Folder,
                if (scan.running) "Looking for music…" else "Play music files from your phone",
                if (scan.running) "Found ${scan.found} songs so far." else "Pick a folder (like Music or Download) and Siren adds the songs in it, covers and all. They play offline.",
                action = if (scan.running) null else ({ PrimaryButton("Add a folder", { pick.launch(null) }) })
            )
        },
        customOrder = false,
        banner = { LocalFolders(folders, scan, onAdd = { pick.launch(null) }) }
    )
}

/** The folders Siren reads music from, with add / rescan / remove. Used here and in Settings. */
@Composable
fun LocalFolders(folders: List<LocalMusic.Folder>, scan: LocalMusic.Scan, onAdd: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        if (scan.running) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                SirenLoader(size = 26.dp)
                Spacer(Modifier.width(10.dp))
                Text("Reading your music… ${scan.found} songs", color = Sc.TextDim, fontSize = 13.sp)
            }
        }
        folders.forEach { f ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Folder, null, tint = Sc.TextDim, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text(f.name, color = Sc.Text, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                IconButton(onClick = { LocalMusic.removeFolder(ctx, f.uri) }) {
                    Icon(Icons.Rounded.Close, "Stop using ${f.name}", tint = Sc.TextDim, modifier = Modifier.size(18.dp))
                }
            }
        }
        if (folders.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp, bottom = 6.dp)) {
                Chip("Add folder", false, onAdd)
                Chip(if (scan.running) "Scanning…" else "Rescan", false, { LocalMusic.rescan(ctx) })
            }
        }
    }
}
