package app.siren.data

import app.siren.core.videoIdFromUrl
import java.io.BufferedInputStream
import java.io.InputStream
import java.util.Locale
import java.util.zip.ZipInputStream

/**
 * Reads playlist files into [ParsedList]s:
 *  - Google Takeout (YouTube Music): a playlist CSV, or the whole Takeout .zip. These carry
 *    exact video IDs, so no searching is needed.
 *  - Exportify (Spotify): CSV with title, artists, album, length. Matched by search.
 *  - Siren's own CSV export (has YouTube links, so exact).
 *  - Plain text lists ("Artist - Song", or links), one per line.
 */
object ImportParse {

    private val idOnly = Regex("^[A-Za-z0-9_-]{11}$")

    /** Reads a file (CSV, text or zip). [fileName] names the playlist when there's one list. */
    fun read(input: InputStream, fileName: String): List<ParsedList> {
        val buffered = BufferedInputStream(input)
        buffered.mark(8)
        val head = ByteArray(4)
        val n = buffered.read(head)
        buffered.reset()
        val isZip = n == 4 && head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte() &&
            head[2].toInt() == 3 && head[3].toInt() == 4
        return if (isZip) readZip(buffered) else {
            val text = buffered.readBytes().toString(Charsets.UTF_8)
            val list = parseText(text, prettyName(fileName))
            if (list.items.isEmpty()) emptyList() else listOf(list)
        }
    }

    private fun readZip(input: InputStream): List<ParsedList> {
        val out = ArrayList<ParsedList>()
        ZipInputStream(input).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (e.isDirectory) continue
                val path = e.name.replace('\\', '/')
                val base = path.substringAfterLast('/')
                val lower = path.lowercase(Locale.ROOT)
                val baseLower = base.lowercase(Locale.ROOT)
                val isText = baseLower.endsWith(".csv") || baseLower.endsWith(".txt")
                // playlists.csv in Takeout is the list of playlists (names, dates), not songs
                if (!isText || baseLower == "playlists.csv") continue
                // Small files only: playlists are text, anything huge is something else
                val bytes = zip.readBytes().takeIf { it.size < 32 * 1024 * 1024 } ?: continue
                val list = parseText(bytes.toString(Charsets.UTF_8), prettyName(base))
                if (list.items.isEmpty()) continue
                val fromPlaylistFolder = lower.split('/').dropLast(1).any { it.contains("playlist") } ||
                    lower.contains("music library songs") || lower.contains("music (library")
                // Takeout also has comments/history CSVs with video IDs: only take real playlists.
                // Search-type lists (Exportify's "Export all" zip) are always playlists.
                if (list.exact && !fromPlaylistFolder) continue
                out += list
            }
        }
        return out
    }

    /** "Chill Mix-videos.csv" -> "Chill Mix", "liked_songs.csv" -> "Liked songs" */
    fun prettyName(file: String): String {
        var n = file.substringAfterLast('/').substringBeforeLast('.')
        n = n.removeSuffix("-videos").removeSuffix(" videos").removeSuffix("-Videos")
        if (!n.contains(' ') && n.contains('_')) n = n.replace('_', ' ')
        n = n.trim()
        if (n.isEmpty()) return "Imported"
        return n.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
    }

    fun parseText(raw: String, name: String): ParsedList {
        val text = raw.removePrefix("﻿")
        val firstLine = text.lineSequence().firstOrNull { it.isNotBlank() } ?: return ParsedList(name, emptyList())
        val sep = when {
            firstLine.count { it == '\t' } >= 1 -> '\t'
            firstLine.count { it == ',' } >= 1 -> ','
            firstLine.count { it == ';' } >= 1 -> ';'
            else -> null
        }
        if (sep != null) {
            val rows = parseCsv(text, sep).filter { r -> r.any { it.isNotBlank() } }
            fromRows(rows, name)?.let { return it }
        }
        return fromLines(text, name)
    }

    private fun norm(h: String) = h.trim().lowercase(Locale.ROOT)

    private fun fromRows(rows: List<List<String>>, name: String): ParsedList? {
        if (rows.isEmpty()) return null
        // Takeout puts the header a few rows down in older exports, so look for it
        val headerAt = rows.take(40).indexOfFirst { r -> r.any { norm(it) in VIDEO_ID_HEADERS } }
        if (headerAt >= 0) {
            val header = rows[headerAt].map(::norm)
            val idCol = header.indexOfFirst { it in VIDEO_ID_HEADERS }
            val titleCol = header.indexOfFirst { it in TITLE_HEADERS }
            val artistCol = header.indexOfFirst { it in ARTIST_HEADERS }
            val albumCol = header.indexOfFirst { it in ALBUM_HEADERS }
            val items = rows.drop(headerAt + 1).mapNotNull { r ->
                val cell = r.getOrNull(idCol)?.trim().orEmpty()
                val id = if (idOnly.matches(cell)) cell else videoIdFromUrl(cell) ?: return@mapNotNull null
                ImportItem(
                    videoId = id,
                    title = r.getOrNull(titleCol)?.trim().orEmpty(),
                    artist = r.getOrNull(artistCol)?.trim().orEmpty(),
                    album = r.getOrNull(albumCol)?.trim().orEmpty()
                )
            }
            return ParsedList(name, items.distinctBy { it.videoId }, exact = true)
        }

        val header = rows[0].map(::norm)
        val titleCol = header.indexOfFirst { it in TITLE_HEADERS }
        if (titleCol < 0) return null
        val artistCol = header.indexOfFirst { it in ARTIST_HEADERS }
        val albumCol = header.indexOfFirst { it in ALBUM_HEADERS }
        val msCol = header.indexOfFirst { it == "duration (ms)" || it == "duration_ms" || it == "track duration (ms)" }
        val secCol = header.indexOfFirst { it == "duration (s)" || it == "duration" || it == "time" }
        val urlCol = header.indexOfFirst { it == "url" || it == "youtube url" || it == "link" || it == "track url" }
        val items = rows.drop(1).mapNotNull { r ->
            val title = r.getOrNull(titleCol)?.trim().orEmpty()
            if (title.isEmpty()) return@mapNotNull null
            val artist = r.getOrNull(artistCol)?.trim().orEmpty()
            val dur = when {
                msCol >= 0 -> r.getOrNull(msCol)?.trim()?.toLongOrNull()?.div(1000) ?: -1
                secCol >= 0 -> parseDuration(r.getOrNull(secCol).orEmpty())
                else -> -1
            }
            // Siren's own export carries the YouTube link: that's an exact match
            val id = r.getOrNull(urlCol)?.let { videoIdFromUrl(it) }.orEmpty()
            ImportItem(
                videoId = id,
                title = title,
                artist = artist,
                album = r.getOrNull(albumCol)?.trim().orEmpty(),
                durationSec = dur
            )
        }
        return ParsedList(name, items, exact = items.isNotEmpty() && items.all { it.videoId.isNotEmpty() })
    }

    /** "3:45", "225", "225000" (ms) -> seconds */
    private fun parseDuration(s: String): Long {
        val t = s.trim()
        if (t.isEmpty()) return -1
        if (t.contains(':')) {
            return t.split(':').fold(0L) { acc, p -> acc * 60 + (p.trim().toLongOrNull() ?: return -1) }
        }
        val v = t.toDoubleOrNull()?.toLong() ?: return -1
        return if (v > 20_000) v / 1000 else v
    }

    private fun fromLines(text: String, name: String): ParsedList {
        val items = text.lines().map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .map { line ->
                val id = videoIdFromUrl(line) ?: line.takeIf { idOnly.matches(it) }
                if (id != null) ImportItem(videoId = id)
                else {
                    // "Artist - Song" is the usual shape; keep both halves and let matching decide
                    val dash = line.indexOf(" - ")
                    if (dash > 0) ImportItem(title = line.substring(dash + 3).trim(), artist = line.substring(0, dash).trim(), loose = true)
                    else ImportItem(title = line, loose = true)
                }
            }
        return ParsedList(name, items, exact = items.isNotEmpty() && items.all { it.videoId.isNotEmpty() })
    }

    /** RFC 4180 CSV: quotes, doubled quotes, separators and line breaks inside quotes. */
    fun parseCsv(text: String, sep: Char): List<List<String>> {
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val sb = StringBuilder()
        var quoted = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            when {
                quoted && c == '"' && i + 1 < text.length && text[i + 1] == '"' -> {
                    sb.append('"'); i++
                }
                c == '"' -> quoted = !quoted
                !quoted && c == sep -> {
                    row += sb.toString().trim(); sb.clear()
                }
                !quoted && (c == '\n' || c == '\r') -> {
                    if (c == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    row += sb.toString().trim(); sb.clear()
                    rows += row
                    row = ArrayList()
                }
                else -> sb.append(c)
            }
            i++
        }
        if (sb.isNotEmpty() || row.isNotEmpty()) {
            row += sb.toString().trim()
            rows += row
        }
        return rows
    }

    private val VIDEO_ID_HEADERS = setOf("video id", "video_id", "videoid", "youtube id", "youtube video id")
    private val TITLE_HEADERS = setOf(
        "track name", "track_name", "name", "title", "song", "song name", "song title", "track", "track title"
    )
    private val ARTIST_HEADERS = setOf(
        "artist name(s)", "artist names", "artist name", "artist_name", "artist", "artists", "artist(s)",
        "artist name 1", "artist 1", "album artist"
    )
    private val ALBUM_HEADERS = setOf("album name", "album", "album title", "album_name")
}
