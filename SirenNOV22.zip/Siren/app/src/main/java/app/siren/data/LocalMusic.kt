package app.siren.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import app.siren.core.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import java.io.File
import java.security.MessageDigest

/**
 * Music files on the phone: you pick folders, Siren reads the songs in them (title, artist,
 * album, length and cover from the files' tags) and they show up as "On this device".
 * They play straight from the files, offline, and work everywhere other songs do.
 *
 * A local song is a normal [Track] whose url is "local:<document uri>".
 */
object LocalMusic {
    const val PREFIX = "local:"

    @Serializable
    data class Folder(val uri: String, val name: String)

    @Serializable
    private data class Entry(val folder: String, val doc: String, val modified: Long, val track: Track)

    @Serializable
    private data class Store(val folders: List<Folder> = emptyList(), val entries: List<Entry> = emptyList())

    /** Scan progress: songs found so far, and whether it's still going. */
    data class Scan(val found: Int, val running: Boolean)

    private val _folders = MutableStateFlow<List<Folder>>(emptyList())
    val folders: StateFlow<List<Folder>> = _folders.asStateFlow()

    private val _tracks = MutableStateFlow<List<Track>>(emptyList())
    val tracks: StateFlow<List<Track>> = _tracks.asStateFlow()

    private val _scan = MutableStateFlow(Scan(0, false))
    val scan: StateFlow<Scan> = _scan.asStateFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var entries: List<Entry> = emptyList()
    private var file: File? = null
    private var artDir: File? = null
    private var scanJob: Job? = null

    private val AUDIO_EXT = setOf("mp3", "m4a", "aac", "flac", "ogg", "oga", "opus", "wav", "wma", "alac", "aiff", "aif", "mka", "weba")

    fun isLocal(t: Track): Boolean = t.url.startsWith(PREFIX)
    fun isLocalId(id: String): Boolean = id.startsWith(PREFIX)

    /** The file to play for a local song. */
    fun playUri(t: Track): Uri = Uri.parse(t.url.removePrefix(PREFIX))

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "local_music.json")
        artDir = File(ctx.cacheDir, "local-art").apply { mkdirs() }
        try {
            val f = file
            if (f != null && f.exists()) {
                val s = LibraryJson.json.decodeFromString(Store.serializer(), f.readText())
                entries = s.entries
                _folders.value = s.folders
                publish()
            }
        } catch (_: Exception) {
        }
        // Quietly pick up new files each time the app starts
        if (_folders.value.isNotEmpty()) rescan(ctx, quiet = true)
    }

    /** Adds a folder you picked (keeps permission to read it) and scans it. */
    fun addFolder(ctx: Context, tree: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        val name = folderName(tree)
        if (_folders.value.none { it.uri == tree.toString() }) {
            _folders.value = _folders.value + Folder(tree.toString(), name)
            save()
        }
        rescan(ctx)
    }

    fun removeFolder(ctx: Context, uri: String) {
        try {
            ctx.contentResolver.releasePersistableUriPermission(Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        _folders.value = _folders.value.filterNot { it.uri == uri }
        entries = entries.filterNot { it.folder == uri }
        publish()
        save()
    }

    /** Looks through every folder again: new songs are added, deleted ones drop off. */
    fun rescan(ctx: Context, quiet: Boolean = false) {
        if (scanJob?.isActive == true) return
        val app = ctx.applicationContext
        scanJob = scope.launch {
            if (!quiet) _scan.value = Scan(0, true)
            val old = entries.associateBy { it.doc }
            val next = ArrayList<Entry>()
            for (f in _folders.value) {
                val tree = Uri.parse(f.uri)
                val rootDoc = try {
                    DocumentsContract.getTreeDocumentId(tree)
                } catch (_: Exception) {
                    continue
                }
                walk(app, tree, rootDoc, depth = 0) { docId, displayName, modified ->
                    val doc = DocumentsContract.buildDocumentUriUsingTree(tree, docId).toString()
                    val prev = old[doc]
                    val e = if (prev != null && prev.modified == modified) prev
                    else read(app, f.uri, doc, displayName, modified)
                    if (e != null) {
                        next += e
                        if (!quiet && next.size % 25 == 0) _scan.value = Scan(next.size, true)
                    }
                }
            }
            entries = next
            publish()
            save()
            _scan.value = Scan(next.size, false)
        }
    }

    private fun walk(ctx: Context, tree: Uri, docId: String, depth: Int, onFile: (String, String, Long) -> Unit) {
        if (depth > 12) return
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        val dirs = ArrayList<String>()
        try {
            ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val mime = c.getString(1).orEmpty()
                    val name = c.getString(2).orEmpty()
                    val modified = if (c.isNull(3)) 0L else c.getLong(3)
                    when {
                        mime == DocumentsContract.Document.MIME_TYPE_DIR -> if (!name.startsWith(".")) dirs += id
                        mime.startsWith("audio/") || name.substringAfterLast('.', "").lowercase() in AUDIO_EXT -> onFile(id, name, modified)
                    }
                }
            }
        } catch (_: Exception) {
        }
        dirs.forEach { walk(ctx, tree, it, depth + 1, onFile) }
    }

    /** Reads one file's tags and cover. Null if it isn't playable audio. */
    private fun read(ctx: Context, folder: String, doc: String, displayName: String, modified: Long): Entry? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, Uri.parse(doc))
            val hasAudio = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
            if (hasAudio != null && hasAudio != "yes") return null
            val base = displayName.substringBeforeLast('.')
            val title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.trim().orEmpty().ifBlank { base }
            val artist = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?: r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST))?.trim().orEmpty()
            val album = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)?.trim().orEmpty()
            val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: -1L
            val art = r.embeddedPicture?.let { saveArt(doc, it) }.orEmpty()
            Entry(
                folder, doc, modified,
                Track(
                    url = PREFIX + doc,
                    title = title,
                    artist = artist.ifBlank { guessArtist(base) },
                    thumbnail = art,
                    duration = if (durMs > 0) durMs / 1000 else -1,
                    album = album
                )
            )
        } catch (_: Exception) {
            null
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }

    /** "Artist - Title.mp3" files with no tags: use the part before the dash. */
    private fun guessArtist(base: String): String =
        if (base.contains(" - ")) base.substringBefore(" - ").trim() else ""

    private fun saveArt(doc: String, bytes: ByteArray): String? {
        val dir = artDir ?: return null
        return try {
            val f = File(dir, sha1(doc) + ".jpg")
            if (!f.exists()) {
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                var sample = 1
                while (opts.outWidth / (sample * 2) >= 600) sample *= 2
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            }
            Uri.fromFile(f).toString()
        } catch (_: Exception) {
            null
        }
    }

    private fun folderName(tree: Uri): String = try {
        val id = DocumentsContract.getTreeDocumentId(tree)
        val path = id.substringAfter(':', id)
        path.substringAfterLast('/').ifBlank { if (id.startsWith("primary")) "Internal storage" else id }
    } catch (_: Exception) {
        "Folder"
    }

    private fun publish() {
        _tracks.value = entries.map { it.track }.sortedWith(compareBy({ it.artist.lowercase() }, { it.album.lowercase() }, { it.title.lowercase() }))
    }

    private fun save() {
        val f = file ?: return
        try {
            f.writeText(LibraryJson.json.encodeToString(Store.serializer(), Store(_folders.value, entries)))
        } catch (_: Exception) {
        }
    }

    private fun sha1(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
