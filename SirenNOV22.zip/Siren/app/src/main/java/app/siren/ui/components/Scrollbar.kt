package app.siren.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/**
 * A draggable scroll bar on the right edge of a long list. It's faint while the list sits still,
 * brighter while it scrolls, and you can grab it and drag to jump anywhere in the list.
 * Shorter lists (under [minItems] rows) don't get one.
 */
fun Modifier.fastScroll(state: LazyListState, minItems: Int = 30): Modifier = composed {
    val scope = rememberCoroutineScope()
    var dragging by remember { mutableStateOf(false) }
    val active = dragging || state.isScrollInProgress
    val alpha by animateFloatAsState(
        targetValue = if (active) 0.95f else 0.38f,
        animationSpec = tween(durationMillis = if (active) 120 else 700, delayMillis = if (active) 0 else 900),
        label = "scrollbar"
    )

    fun fraction(): Float {
        val info = state.layoutInfo
        val total = info.totalItemsCount
        val vis = info.visibleItemsInfo.size
        if (total <= vis || total == 0) return 0f
        return (state.firstVisibleItemIndex.toFloat() / (total - vis)).coerceIn(0f, 1f)
    }

    this
        .pointerInput(state, minItems) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                val total = state.layoutInfo.totalItemsCount
                if (total < minItems) return@awaitEachGesture
                val thumbH = 64.dp.toPx()
                val zone = 26.dp.toPx()
                val top = fraction() * (size.height - thumbH)
                val onThumb = down.position.x >= size.width - zone &&
                    down.position.y >= top - 14.dp.toPx() && down.position.y <= top + thumbH + 14.dp.toPx()
                if (!onThumb) return@awaitEachGesture
                down.consume()
                dragging = true
                fun jump(y: Float) {
                    val f = ((y - thumbH / 2f) / (size.height - thumbH)).coerceIn(0f, 1f)
                    val idx = ((total - 1) * f).toInt().coerceIn(0, total - 1)
                    scope.launch { state.scrollToItem(idx) }
                }
                jump(down.position.y)
                drag(down.id) { change ->
                    change.consume()
                    jump(change.position.y)
                }
                dragging = false
            }
        }
        .drawWithContent {
            drawContent()
            val total = state.layoutInfo.totalItemsCount
            if (total < minItems) return@drawWithContent
            val thumbH = 64.dp.toPx()
            val w = (if (dragging) 8.dp else 5.dp).toPx()
            val top = fraction() * (size.height - thumbH)
            drawRoundRect(
                color = Color.White.copy(alpha = alpha),
                topLeft = Offset(size.width - w - 3.dp.toPx(), top),
                size = Size(w, thumbH),
                cornerRadius = CornerRadius(w / 2f, w / 2f)
            )
        }
}
