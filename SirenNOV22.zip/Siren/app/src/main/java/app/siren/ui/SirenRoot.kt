package app.siren.ui

import androidx.compose.runtime.SideEffect
import app.siren.ui.screens.LocalFilesScreen
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.runtime.mutableStateOf
import app.siren.ui.screens.ShareItem
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideInHorizontally
import app.siren.ui.components.SirenLoader
import app.siren.ui.components.LikeButton
import app.siren.ui.components.rememberRippleState
import app.siren.ui.components.waveSource
import app.siren.ui.components.distortionWave
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.siren.core.Track
import app.siren.data.Importer
import app.siren.data.Library
import app.siren.player.PlayerController
import app.siren.ui.components.Artwork
import app.siren.ui.components.rememberArtColor
import app.siren.ui.screens.ArtistScreen
import app.siren.ui.screens.ArtistsScreen
import app.siren.ui.screens.CollectionScreen
import app.siren.ui.screens.DownloadsScreen
import app.siren.ui.screens.EqualizerScreen
import app.siren.ui.screens.HistoryScreen
import app.siren.ui.screens.HomeScreen
import app.siren.ui.screens.LibraryScreen
import app.siren.ui.screens.LikedScreen
import app.siren.ui.screens.FolderScreen
import app.siren.ui.screens.LocalPlaylistScreen
import app.siren.ui.screens.NowPlaying
import app.siren.ui.screens.SavedScreen
import app.siren.ui.screens.SearchScreen
import app.siren.ui.screens.SettingsScreen
import app.siren.ui.screens.CarMode
import app.siren.ui.screens.ShareScreen
import app.siren.ui.screens.isBluetooth
import app.siren.data.Settings
import app.siren.ui.theme.Sc
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@UnstableApi
@Composable
fun SirenRoot() {
    val nav = rememberNavController()
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val ctx = LocalContext.current
    val actions = remember(nav) { Actions(nav, scope, snackbar, ctx) }
    val playerOpen by UiState.playerOpen.collectAsState()
    val pending by UiState.pending.collectAsState()
    val current by PlayerController.current.collectAsState()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val carMode by UiState.carMode.collectAsState()
    val shareItem by UiState.share.collectAsState()

    // Car mode opens itself when a Bluetooth device you marked as your car connects
    DisposableEffect(Unit) {
        val am = ctx.getSystemService(android.media.AudioManager::class.java)
        fun names(list: Array<out android.media.AudioDeviceInfo>) =
            list.filter { isBluetooth(it) }.map { it.productName?.toString().orEmpty().trim() }
        val cb = object : android.media.AudioDeviceCallback() {
            override fun onAudioDevicesAdded(added: Array<out android.media.AudioDeviceInfo>) {
                val s = Settings.current
                if (!s.carAutoOpen || s.carDevices.isEmpty() || UiState.carAutoOpened) return
                if (names(added).any { it in s.carDevices }) {
                    UiState.carAutoOpened = true
                    UiState.carMode.value = true
                }
            }

            override fun onAudioDevicesRemoved(removed: Array<out android.media.AudioDeviceInfo>) {
                // Car gone: next time it connects, car mode can open again
                if (names(removed).any { it in Settings.current.carDevices }) UiState.carAutoOpened = false
            }
        }
        try {
            am?.registerAudioDeviceCallback(cb, null)
        } catch (_: Exception) {
        }
        onDispose {
            try {
                am?.unregisterAudioDeviceCallback(cb)
            } catch (_: Exception) {
            }
        }
    }

    LaunchedEffect(Unit) {
        PlayerController.messages.collect { actions.message(it) }
    }
    LaunchedEffect(Unit) {
        Importer.messages.collect { actions.message(it) }
    }

    LaunchedEffect(pending) {
        when (val p = pending) {
            is UiState.Pending.Link -> actions.link(p.url)
            UiState.Pending.OpenPlayer -> if (PlayerController.current.value != null) actions.openPlayer()
            UiState.Pending.OpenDownloads -> actions.open(Routes.DOWNLOADS)
            is UiState.Pending.OpenPlaylist -> if (Library.playlist(p.id) != null) actions.local(p.id)
            is UiState.Pending.Voice -> {
                PlayerController.playVoice(p.query, p.focus, p.artist, p.playlist)
                actions.openPlayer()
            }
            null -> Unit
        }
        if (pending != null) UiState.pending.value = null
    }

    BackHandler(enabled = playerOpen) { UiState.playerOpen.value = false }

    CompositionLocalProvider(LocalActions provides actions) {
        // The distortion wave lives on this root, so a ripple can bend the whole screen
        Box(Modifier.fillMaxSize().background(Sc.Bg).distortionWave()) {
            Scaffold(
                containerColor = Sc.Bg,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                bottomBar = {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .background(Sc.Bg)
                            .navigationBarsPadding()
                    ) {
                        AnimatedVisibility(
                            visible = current != null,
                            enter = expandVertically() + fadeIn(),
                            exit = shrinkVertically() + fadeOut()
                        ) {
                            val c = current
                            if (c != null) MiniPlayer(c, onOpen = { actions.openPlayer() })
                        }
                        BottomBar(route) { actions.tab(it) }
                    }
                }
            ) { inner ->
                NavHost(
                    navController = nav,
                    startDestination = Routes.HOME,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = inner.calculateBottomPadding())
                        // Edge-to-edge apps don't get resized for the keyboard, so make room for it
                        // here (minus the space the tabs and mini player already take)
                        .consumeWindowInsets(PaddingValues(bottom = inner.calculateBottomPadding()))
                        .imePadding(),
                    // Tabs cross-fade; pages you open (artist, album, playlist…) slide in from the right
                    enterTransition = {
                        if (targetState.destination.route in TAB_ROUTES) fadeIn(tween(150))
                        else slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { it / 3 } + fadeIn(tween(200))
                    },
                    exitTransition = {
                        if (targetState.destination.route in TAB_ROUTES) fadeOut(tween(100))
                        else slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { -it / 10 } + fadeOut(tween(220))
                    },
                    popEnterTransition = {
                        if (initialState.destination.route in TAB_ROUTES) fadeIn(tween(150))
                        else slideInHorizontally(tween(240, easing = FastOutSlowInEasing)) { -it / 10 } + fadeIn(tween(180))
                    },
                    popExitTransition = {
                        if (initialState.destination.route in TAB_ROUTES) fadeOut(tween(100))
                        else slideOutHorizontally(tween(220, easing = FastOutSlowInEasing)) { it / 3 } + fadeOut(tween(170))
                    }
                ) {
                    composable(Routes.HOME) { HomeScreen() }
                    composable(Routes.SEARCH) { SearchScreen() }
                    composable(Routes.LIBRARY) { LibraryScreen() }
                    composable(Routes.LIKED) { LikedScreen() }
                    composable(Routes.DOWNLOADS) { DownloadsScreen() }
                    composable(Routes.HISTORY) { HistoryScreen() }
                    composable(Routes.ARTISTS) { ArtistsScreen() }
                    composable(Routes.SAVED) { SavedScreen() }
                    composable(Routes.SETTINGS) { SettingsScreen() }
                    composable(Routes.EQUALIZER) { EqualizerScreen() }
                    composable(Routes.DEVICE) { LocalFilesScreen() }
                    composable(
                        Routes.ARTIST,
                        arguments = listOf(navArgument("url") { type = NavType.StringType })
                    ) { e -> ArtistScreen(e.arguments?.getString("url") ?: "") }
                    composable(
                        Routes.COLLECTION,
                        arguments = listOf(navArgument("url") { type = NavType.StringType })
                    ) { e -> CollectionScreen(e.arguments?.getString("url") ?: "") }
                    composable(
                        Routes.LOCAL,
                        arguments = listOf(navArgument("id") { type = NavType.StringType })
                    ) { e -> LocalPlaylistScreen(e.arguments?.getString("id") ?: "") }
                    composable(
                        Routes.FOLDER,
                        arguments = listOf(navArgument("name") { type = NavType.StringType })
                    ) { e -> FolderScreen(e.arguments?.getString("name") ?: "") }
                }
            }

            AnimatedVisibility(
                visible = playerOpen && current != null,
                enter = slideInVertically(tween(300)) { it } + fadeIn(tween(160)),
                exit = slideOutVertically(tween(260)) { it } + fadeOut(tween(200)),
                modifier = Modifier.zIndex(2f)
            ) {
                NowPlaying(onClose = { UiState.playerOpen.value = false })
            }

            AnimatedVisibility(
                visible = carMode,
                enter = slideInVertically(tween(300, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(160)),
                exit = slideOutVertically(tween(240)) { it } + fadeOut(tween(200)),
                modifier = Modifier.zIndex(2.4f)
            ) {
                CarMode(onClose = { UiState.carMode.value = false })
            }
            // Keep the last item around so the share screen can slide away with its content
            var lastShare by remember { mutableStateOf<ShareItem?>(null) }
            val shareShown = shareItem ?: lastShare
            SideEffect { if (shareItem != null) lastShare = shareItem }
            AnimatedVisibility(
                visible = shareItem != null,
                enter = slideInVertically(tween(300, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(160)),
                exit = slideOutVertically(tween(240)) { it } + fadeOut(tween(200)),
                modifier = Modifier.zIndex(2.5f)
            ) {
                shareShown?.let { item -> ShareScreen(item, onClose = { UiState.share.value = null }) }
            }

            // Above everything, including the full-screen player
            SnackbarHost(
                snackbar,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = when {
                        playerOpen || carMode || shareItem != null -> 24.dp
                        current != null -> 136.dp   // above the mini player and tabs
                        else -> 72.dp               // just above the tabs
                    })
                    .zIndex(3f)
            ) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = Color.White,
                    contentColor = Color.Black,
                    actionColor = Sc.AccentDeep,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun BottomBar(route: String?, onTab: (String) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(60.dp)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val home = route == Routes.HOME
        val search = route == Routes.SEARCH
        val library = route == Routes.LIBRARY
        NavItem(if (home) Icons.Rounded.Home else Icons.Outlined.Home, "Home", home) { onTab(Routes.HOME) }
        NavItem(Icons.Rounded.Search, "Search", search) { onTab(Routes.SEARCH) }
        NavItem(if (library) Icons.Rounded.LibraryMusic else Icons.Outlined.LibraryMusic, "Your Library", library) { onTab(Routes.LIBRARY) }
    }
}

@Composable
private fun RowScope.NavItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .weight(1f)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = if (selected) Sc.Text else Sc.TextDim, modifier = Modifier.size(26.dp))
        Spacer(Modifier.height(3.dp))
        Text(
            label,
            color = if (selected) Sc.Text else Sc.TextDim,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

/** Spotify-style mini player: tinted with the cover's color, swipe sideways to skip, swipe up to open. */
@UnstableApi
@Composable
private fun MiniPlayer(t: Track, onOpen: () -> Unit) {
    val playing by PlayerController.isPlaying.collectAsState()
    val buffering by PlayerController.buffering.collectAsState()
    val lib by Library.data.collectAsState()
    val liked = lib.liked.any { it.videoId == t.videoId }
    val tint = rememberArtColor(t.thumbnail, Sc.SurfaceHighest)
    val scope = rememberCoroutineScope()
    val drag = remember { Animatable(0f) }
    var progress by remember { mutableFloatStateOf(0f) }
    val playRipple = rememberRippleState(520)
    val addedRipple = rememberRippleState(560)
    LaunchedEffect(Unit) { PlayerController.added.collect { addedRipple.fire(0.8f) } }

    LaunchedEffect(t.videoId) {
        drag.snapTo(0f)
        while (true) {
            val p = PlayerController.player
            val d = p.duration
            progress = if (d != C.TIME_UNSET && d > 0) (p.currentPosition.toFloat() / d).coerceIn(0f, 1f) else 0f
            delay(500)
        }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(tint)
            .clickable(onClick = onOpen)
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, dy -> if (dy < -12) onOpen() }
            }
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(start = 8.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Rings spread from the cover when songs are added to the queue
            Box(Modifier.size(40.dp).waveSource(addedRipple)) {
                Artwork(t.thumbnail, Modifier.size(40.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(
                Modifier
                    .weight(1f)
                    .offset { IntOffset(drag.value.roundToInt(), 0) }
                    .graphicsLayer { alpha = 1f - (kotlin.math.abs(drag.value) / 400f).coerceIn(0f, 0.7f) }
                    .pointerInput(t.videoId) {
                        detectHorizontalDragGestures(
                            onDragEnd = {
                                val v = drag.value
                                scope.launch {
                                    when {
                                        v < -120 -> PlayerController.next()
                                        v > 120 -> PlayerController.previous()
                                    }
                                    drag.animateTo(0f, tween(180))
                                }
                            },
                            onDragCancel = { scope.launch { drag.animateTo(0f) } },
                            onHorizontalDrag = { _, d -> scope.launch { drag.snapTo(drag.value + d) } }
                        )
                    }
            ) {
                Text(t.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t.artist, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            LikeButton(liked, 24.dp, Color.White) { Library.toggleLike(t) }
            Box(Modifier.size(44.dp).waveSource(playRipple), contentAlignment = Alignment.Center) {
                if (buffering && !playing) {
                    SirenLoader(size = 28.dp, color = Color.White)
                } else {
                    IconButton(onClick = {
                        playRipple.fire(if (playing) 0.55f else 1f)
                        PlayerController.togglePlay()
                    }) {
                        Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (playing) "Pause" else "Play", tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                }
            }
        }
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                .height(2.dp)
                .clip(RoundedCornerShape(1.dp))
                .background(Color.White.copy(alpha = 0.22f))
        ) {
            Box(
                Modifier
                    .fillMaxWidth(progress)
                    .height(2.dp)
                    .background(Color.White)
            )
        }
    }
}

/** The bottom-bar tabs (they cross-fade; everything else slides). */
private val TAB_ROUTES = setOf(Routes.HOME, Routes.SEARCH, Routes.LIBRARY)
