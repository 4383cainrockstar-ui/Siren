package app.siren.ui.components

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.composed
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import app.siren.data.Settings
import kotlinx.coroutines.flow.collectLatest

/*
 * Siren's distortion wave: a shockwave that spreads across the whole screen from the button you
 * tapped, bending the pixels as it goes (with a slight color split on the crest).
 *
 * It's a small AGSL shader on the app's root layer, so it works on Android 13+. The effect is
 * only attached while a wave is running; the rest of the time the layer is untouched and free.
 */
object Wave {
    const val DURATION_MS = 900

    internal val progress = Animatable(0f)

    var trigger by mutableIntStateOf(0)
        private set

    /** Where the wave starts, in window pixels. */
    internal var origin = Offset.Zero

    /** How hard it bends: 1 = full, less for quieter moments (pause, skip). */
    internal var strength = 1f

    /** The front moves in toward [origin] instead of out from it. */
    internal var inward = false

    fun fire(origin: Offset, strength: Float = 1f, inward: Boolean = false) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (!Settings.current.rippleEffects) return
        if (origin == Offset.Unspecified) return
        this.origin = origin
        this.strength = strength
        this.inward = inward
        trigger++
    }
}

private const val WAVE_AGSL = """
uniform shader content;
uniform float2 size;
uniform float2 origin;
uniform float time;
uniform float amp;
uniform float inward;

half4 main(float2 coord) {
    float2 d = coord - origin;
    float dist = length(d);
    float2 dir = d / max(dist, 0.001);

    // How far the front has to travel to leave the screen from this origin
    float reach = length(float2(max(origin.x, size.x - origin.x), max(origin.y, size.y - origin.y))) + 160.0;
    float t = mix(time, 1.0 - time, inward);
    float front = t * reach;

    // A ring that's thicker the further it has gone
    float width = 70.0 + 0.16 * reach * t;
    float x = (dist - front) / width;
    float env = exp(-x * x * 1.6);
    float fade = 1.0 - smoothstep(0.5, 1.0, time);

    // Crest and trough, like a drop hitting water
    float push = sin(x * 4.2) * env * fade;
    float off = amp * push;

    float2 hi = float2(0.5, 0.5);
    float2 lo = size - float2(0.5, 0.5);
    half4 c = content.eval(clamp(coord - dir * off, hi, lo));
    half r = content.eval(clamp(coord - dir * off * 1.35, hi, lo)).r;
    half b = content.eval(clamp(coord - dir * off * 0.65, hi, lo)).b;

    half3 rgb = half3(r, c.g, b) + half3(0.045 * env * fade);
    return half4(rgb, c.a);
}
"""

/**
 * Put this on the app's root. Any button that calls Wave.fire(...) (see [waveSource]) makes the
 * whole screen ripple from that button. On Android before 13 it does nothing.
 */
fun Modifier.distortionWave(): Modifier =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) composed { waveLayer() } else this

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
private fun Modifier.waveLayer(): Modifier {
    val shader = remember { RuntimeShader(WAVE_AGSL) }
    var host by remember { mutableStateOf(Offset.Zero) }
    // Read outside composition, so firing a wave never recomposes the app
    LaunchedEffect(Unit) {
        snapshotFlow { Wave.trigger }.collectLatest { t ->
            if (t > 0) {
                Wave.progress.snapTo(0f)
                Wave.progress.animateTo(1f, tween(Wave.DURATION_MS, easing = LinearEasing))
                Wave.progress.snapTo(0f)
            }
        }
    }
    return this
        .onGloballyPositioned { host = it.positionInWindow() }
        .graphicsLayer {
            val p = Wave.progress.value
            if (p > 0.001f && p < 0.999f) {
                shader.setFloatUniform("size", size.width, size.height)
                shader.setFloatUniform("origin", Wave.origin.x - host.x, Wave.origin.y - host.y)
                shader.setFloatUniform("time", p)
                shader.setFloatUniform("amp", 15f * density * Wave.strength)
                shader.setFloatUniform("inward", if (Wave.inward) 1f else 0f)
                renderEffect = RenderEffect.createRuntimeShaderEffect(shader, "content").asComposeRenderEffect()
            } else {
                renderEffect = null
            }
        }
}
