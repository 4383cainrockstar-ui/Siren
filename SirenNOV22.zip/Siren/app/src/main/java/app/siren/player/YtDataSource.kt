package app.siren.player

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.HttpDataSource
import app.siren.core.Net
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.schabi.newpipe.extractor.services.youtube.YoutubeParsingHelper
import java.io.IOException
import java.io.InputStream

/**
 * HTTP data source for googlevideo.com audio, using the same tricks as NewPipe:
 *  - byte ranges go in a `range=` URL parameter (no Range header) and are fetched in
 *    1 MB chunks, which is what keeps YouTube from throttling the connection
 *  - a request counter `rn=` is appended
 *  - playback requests are POSTs with the tiny body YouTube's own clients send
 * Other URLs are plain GETs with a Range header.
 */
@UnstableApi
class YtDataSource : BaseDataSource(true) {

    class Factory : DataSource.Factory {
        override fun createDataSource(): DataSource = YtDataSource()
    }

    private var spec: DataSpec? = null
    private var response: Response? = null
    private var stream: InputStream? = null
    private var opened = false

    private var baseUrl = ""
    private var chunked = false
    private var nextPos = 0L        // absolute position of the next byte to request
    private var endPos = 0L         // absolute last byte (inclusive) we were asked for
    private var chunkLeft = 0L      // bytes left in the currently open chunk
    private var bytesLeft = C.LENGTH_UNSET.toLong()
    private var requestNumber = 0
    private var chunkGot = 0L

    override fun open(dataSpec: DataSpec): Long {
        spec = dataSpec
        transferInitializing(dataSpec)
        val uri = dataSpec.uri
        baseUrl = uri.toString()
        val isPlayback = uri.path?.startsWith("/videoplayback") == true
        val clen = uri.getQueryParameter("clen")?.toLongOrNull() ?: -1L

        if (isPlayback && clen > 0) {
            chunked = true
            val start = dataSpec.position
            if (start >= clen) {
                // Asking past the end: report an empty read rather than an HTTP error
                bytesLeft = 0
                opened = true
                transferStarted(dataSpec)
                return 0
            }
            endPos = if (dataSpec.length != C.LENGTH_UNSET.toLong()) {
                minOf(clen - 1, start + dataSpec.length - 1)
            } else clen - 1
            nextPos = start
            bytesLeft = endPos - start + 1
            openChunk()
        } else {
            chunked = false
            bytesLeft = openPlain(dataSpec, isPlayback)
        }
        opened = true
        transferStarted(dataSpec)
        return bytesLeft
    }

    private fun builderFor(url: String): Request.Builder {
        val b = Request.Builder().url(url)
            .header("User-Agent", if (isVisionOs(url)) YoutubeParsingHelper.getVisionOsUserAgent(null) else Net.USER_AGENT)
            .header("Accept-Encoding", "identity")
        if (isWeb(url)) {
            b.header("Origin", "https://www.youtube.com")
            b.header("Referer", "https://www.youtube.com/")
            b.header("Sec-Fetch-Dest", "empty")
            b.header("Sec-Fetch-Mode", "cors")
            b.header("Sec-Fetch-Site", "cross-site")
        }
        spec?.httpRequestHeaders?.forEach { (k, v) -> b.header(k, v) }
        return b
    }

    private fun execute(req: Request, type: Int): Response {
        val ds = spec!!
        val resp = try {
            Net.client.newCall(req).execute()
        } catch (e: IOException) {
            throw HttpDataSource.HttpDataSourceException.createForIOException(e, ds, type)
        }
        if (!resp.isSuccessful) {
            val body = try {
                resp.body?.bytes() ?: ByteArray(0)
            } catch (e: Exception) {
                ByteArray(0)
            }
            val headers = resp.headers.toMultimap()
            val code = resp.code
            val msg = resp.message
            resp.close()
            throw HttpDataSource.InvalidResponseCodeException(code, msg, null, headers, ds, body)
        }
        return resp
    }

    private fun openChunk() {
        closeResponse()
        val chunkEnd = minOf(endPos, nextPos + CHUNK - 1)
        var url = baseUrl
        if (!url.contains("&rn=")) url += "&rn=$requestNumber"
        requestNumber++
        url += "&range=$nextPos-$chunkEnd"
        val req = builderFor(url).post(POST_BODY.toRequestBody()).build()
        val resp = execute(req, HttpDataSource.HttpDataSourceException.TYPE_OPEN)
        response = resp
        stream = resp.body?.byteStream() ?: throw IOException("Empty response body")
        chunkLeft = chunkEnd - nextPos + 1
        chunkGot = 0
    }

    private fun openPlain(dataSpec: DataSpec, isPlayback: Boolean): Long {
        val position = dataSpec.position
        val length = dataSpec.length
        var url = baseUrl
        if (isPlayback && !url.contains("&rn=")) url += "&rn=${requestNumber++}"
        val b = builderFor(url)
        if (position != 0L || length != C.LENGTH_UNSET.toLong()) {
            val end = if (length != C.LENGTH_UNSET.toLong()) (position + length - 1).toString() else ""
            b.header("Range", "bytes=$position-$end")
        }
        if (isPlayback) b.post(POST_BODY.toRequestBody()) else b.get()
        val resp = execute(b.build(), HttpDataSource.HttpDataSourceException.TYPE_OPEN)
        response = resp
        val body = resp.body ?: throw IOException("Empty response body")
        val input = body.byteStream()
        stream = input
        val skip = if (resp.code == 200 && position != 0L) position else 0L
        if (skip > 0) skipFully(input, skip)
        return if (length != C.LENGTH_UNSET.toLong()) length else {
            val cl = body.contentLength()
            if (cl != -1L) cl - skip else C.LENGTH_UNSET.toLong()
        }
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (bytesLeft == 0L) return C.RESULT_END_OF_INPUT
        if (chunked && chunkLeft <= 0L) {
            if (nextPos > endPos) return C.RESULT_END_OF_INPUT
            openChunk()
        }
        val input = stream ?: return C.RESULT_END_OF_INPUT
        var want = length.toLong()
        if (bytesLeft != C.LENGTH_UNSET.toLong()) want = minOf(want, bytesLeft)
        if (chunked) want = minOf(want, chunkLeft)
        val n = try {
            input.read(buffer, offset, want.toInt())
        } catch (e: IOException) {
            throw HttpDataSource.HttpDataSourceException.createForIOException(
                e, spec!!, HttpDataSource.HttpDataSourceException.TYPE_READ
            )
        }
        if (n == -1) {
            if (chunked && bytesLeft > 0) {
                if (chunkGot == 0L) throw IOException("Server closed the connection early")
                // Server sent a short chunk: carry on from where it stopped
                chunkLeft = 0
                return read(buffer, offset, length)
            }
            return C.RESULT_END_OF_INPUT
        }
        if (bytesLeft != C.LENGTH_UNSET.toLong()) bytesLeft -= n
        if (chunked) {
            chunkLeft -= n
            chunkGot += n
            nextPos += n
        }
        bytesTransferred(n)
        return n
    }

    override fun getUri(): Uri? = spec?.uri

    override fun getResponseHeaders(): Map<String, List<String>> =
        response?.headers?.toMultimap() ?: emptyMap()

    private fun closeResponse() {
        try {
            stream?.close()
        } catch (_: Exception) {
        }
        try {
            response?.close()
        } catch (_: Exception) {
        }
        stream = null
        response = null
    }

    override fun close() {
        closeResponse()
        if (opened) {
            opened = false
            transferEnded()
        }
    }

    private fun skipFully(input: InputStream, count: Long) {
        var left = count
        val buf = ByteArray(16 * 1024)
        while (left > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n == -1) throw IOException("Unexpected end of stream while skipping")
            left -= n
        }
    }

    companion object {
        private const val CHUNK = 1024L * 1024L
        private val POST_BODY = byteArrayOf(0x78, 0)

        private fun isWeb(url: String) = try {
            YoutubeParsingHelper.isWebStreamingUrl(url)
        } catch (e: Exception) {
            false
        }

        private fun isVisionOs(url: String) = try {
            YoutubeParsingHelper.isVisionOsStreamingUrl(url)
        } catch (e: Exception) {
            false
        }
    }
}
