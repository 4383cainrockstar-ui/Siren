package app.siren.player

import kotlinx.coroutines.withContext
import app.siren.data.Library
import app.siren.data.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.concurrent.atomic.AtomicBoolean

/**
 * "Your weekly mix": one playlist with a fixed id that is rebuilt in place every Monday, so you
 * never end up with a pile of old ones. Mostly songs you haven't heard, plus a few you know.
 */
object WeeklyMix {
    const val ID = "weekly-mix"
    const val NAME = "Your weekly mix"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val running = AtomicBoolean(false)

    /** The Monday that starts this week, as yyyy-MM-dd. */
    fun weekKey(): String {
        val c = Calendar.getInstance()
        val sinceMonday = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7
        c.add(Calendar.DAY_OF_YEAR, -sinceMonday)
        return "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    private fun due(force: Boolean): Boolean {
        val st = Settings.current
        if (!st.weeklyMix && !force) return false
        val lib = Library.value
        if (lib.history.isEmpty() && lib.liked.isEmpty()) return false
        return force || Library.playlist(ID) == null || st.weeklyMixWeek != weekKey()
    }

    /**
     * Builds this week's mix if it hasn't been built yet (or [force]). Safe to call as often as you
     * like. [onDone] (main thread) gets true when a new mix was saved, false when it couldn't be.
     */
    fun ensureFresh(force: Boolean = false, onDone: ((Boolean) -> Unit)? = null) {
        if (!Settings.current.weeklyMix && !force) return
        if (!running.compareAndSet(false, true)) {
            onDone?.let { cb -> scope.launch(Dispatchers.Main) { cb(false) } }
            return
        }
        scope.launch {
            var ok = false
            try {
                // Let the app finish starting first (and the library finish loading)
                if (!force) delay(4000)
                if (!due(force)) return@launch
                val tracks = Discover.weekly()
                if (tracks.size >= 12) {
                    Library.upsertAutoPlaylist(ID, NAME, tracks)
                    Settings.update { it.copy(weeklyMixWeek = weekKey()) }
                    ok = true
                }
            } catch (_: Exception) {
            } finally {
                running.set(false)
                onDone?.let { cb -> withContext(Dispatchers.Main) { cb(ok) } }
            }
        }
    }
}
