package app.siren

import android.Manifest
import android.app.SearchManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.siren.core.Music
import app.siren.data.Importer
import app.siren.player.PlaybackService
import app.siren.ui.SirenRoot
import app.siren.ui.UiState
import app.siren.ui.theme.SirenTheme
import com.google.common.util.concurrent.ListenableFuture

@UnstableApi
class MainActivity : ComponentActivity() {

    private var controllerFuture: ListenableFuture<MediaController>? = null

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        handleIntent(intent)

        setContent {
            SirenTheme {
                SirenRoot()
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onStart() {
        super.onStart()
        // Binding a controller brings up the media session service, which owns the notification.
        if (controllerFuture == null) {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            controllerFuture = MediaController.Builder(this, token).buildAsync()
        }
        // An import that was cut off (app killed, phone restarted) picks up where it stopped
        Importer.ensureRunning(this)
        app.siren.player.WeeklyMix.ensureFresh()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        when (intent.action) {
            ACTION_OPEN_PLAYER -> UiState.pending.value = UiState.Pending.OpenPlayer
            ACTION_OPEN_DOWNLOADS -> UiState.pending.value = UiState.Pending.OpenDownloads
            ACTION_OPEN_PLAYLIST -> intent.getStringExtra(EXTRA_PLAYLIST)?.let {
                UiState.pending.value = UiState.Pending.OpenPlaylist(it)
            }
            MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH -> UiState.pending.value = UiState.Pending.Voice(
                query = intent.getStringExtra(SearchManager.QUERY).orEmpty(),
                focus = intent.getStringExtra(MediaStore.EXTRA_MEDIA_FOCUS).orEmpty(),
                artist = intent.getStringExtra(MediaStore.EXTRA_MEDIA_ARTIST).orEmpty(),
                playlist = intent.getStringExtra("android.intent.extra.playlist").orEmpty()
            )
            Intent.ACTION_SEND -> Music.extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT))?.let {
                UiState.pending.value = UiState.Pending.Link(it)
            }
            Intent.ACTION_VIEW -> Music.extractUrl(intent.dataString)?.let {
                UiState.pending.value = UiState.Pending.Link(it)
            }
        }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_OPEN_PLAYER = "app.siren.OPEN_PLAYER"
        const val ACTION_OPEN_DOWNLOADS = "app.siren.OPEN_DOWNLOADS"
        const val ACTION_OPEN_PLAYLIST = "app.siren.OPEN_PLAYLIST"
        const val EXTRA_PLAYLIST = "playlist"
    }
}
