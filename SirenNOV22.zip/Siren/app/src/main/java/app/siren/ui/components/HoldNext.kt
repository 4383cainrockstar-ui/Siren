package app.siren.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.siren.ui.theme.Sc

/** How long to hold Next before it hides the artist. */
const val HOLD_TO_HIDE_MS = 3000

/**
 * The Next button. Tap: next song. Hold for 3 seconds (when [onHold] is set): a ring fills
 * around it, the phone buzzes, and [onHold] runs (skip + hide the artist).
 */
@Composable
fun HoldNextButton(
    size: Dp,
    iconSize: Dp,
    onNext: () -> Unit,
    onHold: (() -> Unit)?,
    modifier: Modifier = Modifier,
    tint: Color = Sc.Text,
    ring: Color = Sc.Accent
) {
    val haptics = LocalHapticFeedback.current
    val next by rememberUpdatedState(onNext)
    val hold by rememberUpdatedState(onHold)
    var holding by remember { mutableStateOf(false) }
    val progress = remember { Animatable(0f) }
    val rp = rememberRippleState(460)
    // A normal tap: a quick ring, then next
    val tap: () -> Unit = {
        rp.fire(0.75f)
        next()
    }

    LaunchedEffect(holding) {
        if (holding) {
            progress.snapTo(0f)
            progress.animateTo(1f, tween(HOLD_TO_HIDE_MS, easing = LinearEasing))
        } else {
            progress.snapTo(0f)
        }
    }

    // The rings live on a wrapper so the button's own clip doesn't cut them off
    Box(modifier.size(size).waveSource(rp), contentAlignment = Alignment.Center) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .scale(if (holding) 0.92f else 1f)
            .semantics { contentDescription = if (onHold != null) "Next. Hold 3 seconds to hide this artist" else "Next" }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown()
                    if (hold == null) {
                        if (waitForUpOrCancellation() != null) tap()
                        return@awaitEachGesture
                    }
                    holding = true
                    var timedOut = true
                    val up = withTimeoutOrNull(HOLD_TO_HIDE_MS.toLong()) {
                        val u = waitForUpOrCancellation()
                        timedOut = false
                        u
                    }
                    holding = false
                    if (timedOut) {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        hold?.invoke()
                        // Swallow the rest of this press
                        waitForUpOrCancellation()
                    } else if (up != null) {
                        tap()
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val p = progress.value
            // Only shows once it's clearly a hold, so normal taps don't flash a ring
            if (p > 0.08f) {
                val w = this.size.minDimension * 0.07f
                drawArc(
                    ring.copy(alpha = 0.25f), 0f, 360f, false,
                    topLeft = androidx.compose.ui.geometry.Offset(w / 2, w / 2),
                    size = androidx.compose.ui.geometry.Size(this.size.width - w, this.size.height - w),
                    style = Stroke(w)
                )
                drawArc(
                    ring, -90f, 360f * p, false,
                    topLeft = androidx.compose.ui.geometry.Offset(w / 2, w / 2),
                    size = androidx.compose.ui.geometry.Size(this.size.width - w, this.size.height - w),
                    style = Stroke(w, cap = StrokeCap.Round)
                )
            }
        }
        Icon(Icons.Rounded.SkipNext, null, tint = tint, modifier = Modifier.size(iconSize))
    }
    }
}
