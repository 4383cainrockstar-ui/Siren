package app.siren.player

import android.media.audiofx.AudioEffect
import android.media.audiofx.DynamicsProcessing
import android.os.Build
import androidx.annotation.RequiresApi
import app.siren.data.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * "Normalize volume": a limiter on the player's audio session. It lifts the whole signal and
 * caps the peaks, so quiet songs come up and loud ones stop jumping out. Needs Android 9+.
 */
object Leveler {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var effect: AudioEffect? = null
    private var session = 0
    private var watching = false

    /** Called with the player's audio session (at start and whenever it changes). */
    fun attach(sessionId: Int) {
        if (sessionId <= 0) return
        if (sessionId != session) {
            release()
            session = sessionId
        }
        apply()
        if (!watching) {
            watching = true
            scope.launch {
                Settings.state
                    .map { listOf(it.normalize, it.normalizeLevel) }
                    .distinctUntilChanged()
                    .collect { apply() }
            }
        }
    }

    private fun apply() {
        release()
        if (Build.VERSION.SDK_INT < 28 || session <= 0) return
        val st = Settings.current
        if (!st.normalize) return
        // threshold (dB) and make-up gain (dB): peaks land near -7 to -8 dB at every level
        val (threshold, gain) = when (st.normalizeLevel) {
            0 -> -10f to 3f
            2 -> -18f to 10f
            else -> -14f to 6f
        }
        try {
            effect = build(session, threshold, gain)
        } catch (_: Throwable) {
            // Some phones don't allow app-level effects
            release()
        }
    }

    @RequiresApi(28)
    private fun build(session: Int, threshold: Float, gain: Float): AudioEffect {
        val cfg = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_TIME_RESOLUTION, 2,
            false, 0, false, 0, false, 0, true
        ).build()
        val dp = DynamicsProcessing(0, session, cfg)
        dp.setLimiterAllChannelsTo(DynamicsProcessing.Limiter(true, true, 0, 5f, 250f, 10f, threshold, gain))
        dp.setEnabled(true)
        return dp
    }

    private fun release() {
        try {
            effect?.release()
        } catch (_: Throwable) {
        }
        effect = null
    }
}
