package app.siren.player

import app.siren.core.ArtistRef
import app.siren.core.Entry
import app.siren.core.Music
import app.siren.core.Net
import app.siren.core.Track
import app.siren.core.cleanArtist
import app.siren.data.Library
import app.siren.data.LibraryJson
import app.siren.data.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.URLEncoder
import java.util.Locale

/**
 * A radio station, Pandora style. Radio means "music related to what you started it from":
 * mostly OTHER artists that sound like it, with the starting artist only now and then.
 * Never runs out, and thumbs steer it.
 */
@Serializable
data class Station(
    val kind: String,
    val name: String,
    val artistUrl: String = "",
    val query: String = "",
    val seed: Track? = null,
    val thumbnail: String = "",
    /** Thumbs up: played more often and used as seeds. */
    val liked: List<Track> = emptyList(),
    /** Thumbs down: never again on this station. */
    val banned: List<String> = emptyList(),
    /** Artist -> thumbs down count. One cools them off, two drops them. */
    val cooled: Map<String, Int> = emptyMap(),
    /** Recently played on this station, not repeated for a while. */
    val played: List<String> = emptyList(),
    /** How many genre playlists have been used so far. */
    val sourcesUsed: Int = 0,
    /** Related artists already featured, so each refill brings in different ones. */
    val usedArtists: List<String> = emptyList()
) {
    val title: String get() = if (kind == SONG) "$name radio" else "$name Radio"

    companion object {
        const val ARTIST = "artist"
        const val GENRE = "genre"
        const val SONG = "song"

        fun artist(a: ArtistRef) = Station(ARTIST, a.name, artistUrl = a.url, thumbnail = a.avatar)
        fun artist(name: String, url: String, thumb: String = "") = Station(ARTIST, name, artistUrl = url, thumbnail = thumb)
        fun genre(q: String) = Station(GENRE, q.trim().replaceFirstChar { it.titlecase(Locale.ROOT) }, query = q.trim())
        fun song(t: Track) = Station(SONG, t.title, seed = t, thumbnail = t.thumbnail)
    }
}

/** A related artist from Deezer: name and picture. */
data class RelArtist(val name: String, val picture: String)

object Stations {
    private const val BATCH = 25

    /** No artist twice within this many songs. */
    private const val GAP = 6

    /** "Drake, 21 Savage" / "Daft Punk - Topic" -> "drake" / "daft punk" */
    fun artistKey(a: String): String =
        cleanArtist(a).lowercase(Locale.ROOT).split(",", " & ", " x ", " feat", " ft.", " with ").first().trim()

    private fun norm(s: String) = s.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    /** "soulja boy radio" -> an artist station if that's an artist, otherwise a genre / mood station. */
    suspend fun resolve(text: String): Station {
        val name = text.replace(Regex("(?i)\\bradio\\b|\\bstation\\b"), " ").replace(Regex("\\s+"), " ").trim()
        if (name.isEmpty()) return Station.genre("Hits")
        val artist = try {
            Music.search(name, Music.ARTISTS).items.filterIsInstance<Entry.Artist>().firstOrNull()?.artist
        } catch (e: Exception) {
            null
        }
        if (artist != null) {
            val a = norm(artist.name)
            val q = norm(name)
            if (a == q || (q.length >= 4 && (a.startsWith(q) || q.startsWith(a)))) return Station.artist(artist)
        }
        return Station.genre(name)
    }

    // ---------------- Sources ----------------

    private val radioCache = LinkedHashMap<String, List<Track>>()
    private val artistCache = LinkedHashMap<String, List<Track>>()
    private val playlistCache = LinkedHashMap<String, List<String>>()
    private val relatedCache = LinkedHashMap<String, List<RelArtist>>()

    private fun <K, V> trim(m: LinkedHashMap<K, V>, max: Int) {
        while (m.size > max) m.remove(m.keys.first())
    }

    internal suspend fun radio(t: Track): List<Track> = synchronized(radioCache) { radioCache[t.videoId] } ?: try {
        Music.radio(t)
    } catch (e: Exception) {
        emptyList()
    }.also { r -> if (r.isNotEmpty()) synchronized(radioCache) { radioCache[t.videoId] = r; trim(radioCache, 30) } }

    /** An artist's most popular songs (YouTube Music search). */
    internal suspend fun topSongs(name: String, url: String = ""): List<Track> {
        val key = artistKey(name)
        synchronized(artistCache) { artistCache[key] }?.let { return it }
        val songs = try {
            Music.artistSongs(cleanArtist(name), url, limit = 20)
        } catch (e: Exception) {
            emptyList()
        }
        if (songs.isNotEmpty()) synchronized(artistCache) { artistCache[key] = songs; trim(artistCache, 60) }
        return songs
    }

    /**
     * Artists that sound like [name], closest first. From Deezer's public "related artists"
     * (no account or key needed), which is what makes radio actually branch out. Falls back to
     * the other artists in YouTube's mix if Deezer doesn't know them.
     */
    private suspend fun related(name: String): List<String> = relatedArtists(name).map { it.name }

    /** Like [related], with each artist's picture (for "Artists you might like"). */
    internal suspend fun relatedArtists(name: String): List<RelArtist> {
        val key = artistKey(name)
        synchronized(relatedCache) { relatedCache[key] }?.let { return it }
        val found = withContext<List<RelArtist>>(Dispatchers.IO) {
            try {
                val q = URLEncoder.encode(cleanArtist(name), "UTF-8")
                val search = Net.getText("https://api.deezer.com/search/artist?limit=3&q=$q") ?: return@withContext emptyList()
                val hits = LibraryJson.json.parseToJsonElement(search).jsonObject["data"]?.jsonArray ?: return@withContext emptyList()
                val want = norm(cleanArtist(name))
                val objs = hits.map { it.jsonObject }
                fun nameOf(o: kotlinx.serialization.json.JsonObject) = norm(o["name"]?.jsonPrimitive?.content.orEmpty())
                val hit = objs.firstOrNull { nameOf(it) == want }
                    ?: objs.firstOrNull { val n = nameOf(it); n.isNotEmpty() && want.length >= 4 && (n.startsWith(want) || want.startsWith(n)) }
                    ?: return@withContext emptyList()
                val id = hit["id"]?.jsonPrimitive?.content ?: return@withContext emptyList()
                val rel = Net.getText("https://api.deezer.com/artist/$id/related?limit=40") ?: return@withContext emptyList()
                LibraryJson.json.parseToJsonElement(rel).jsonObject["data"]?.jsonArray
                    ?.mapNotNull { el ->
                        val o = el.jsonObject
                        val n = o["name"]?.jsonPrimitive?.content.orEmpty()
                        if (n.isBlank()) null
                        else RelArtist(n, (o["picture_big"] ?: o["picture_medium"])?.jsonPrimitive?.content.orEmpty())
                    } ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
        }
        if (found.isNotEmpty()) synchronized(relatedCache) { relatedCache[key] = found; trim(relatedCache, 40) }
        return found
    }

    private suspend fun genrePlaylists(q: String): List<String> {
        synchronized(playlistCache) { playlistCache[q] }?.let { return it }
        val urls = try {
            Music.search(q, Music.PLAYLISTS).items.filterIsInstance<Entry.Collection>().map { it.collection.url }
        } catch (e: Exception) {
            emptyList()
        }
        if (urls.isNotEmpty()) synchronized(playlistCache) { playlistCache[q] = urls; trim(playlistCache, 20) }
        return urls
    }

    class Pool {
        /** Songs by the artist the station started from (played only now and then). */
        val main = ArrayList<Track>()
        /** Everything else. */
        val others = ArrayList<Track>()
    }

    // ---------------- Building batches ----------------

    /**
     * The next stretch of the station. [recent] is what played lately (for seeds and spacing),
     * [queued] what's already lined up. Returns the station with updated bookkeeping too.
     */
    suspend fun batch(st: Station, recent: List<Track>, queued: Set<String>): Pair<Station, List<Track>> = coroutineScope {
        val variety = Settings.current.smartVariety.coerceIn(0, 4)
        val pool = Pool()
        var next = st
        val seedPicks = (st.liked.shuffled().take(2) + recent.takeLast(6).shuffled().take(2)).distinctBy { it.videoId }

        if (st.kind == Station.GENRE) {
            // Several playlists for the genre mixed together, a couple more each refill
            val urls = genrePlaylists(st.query.ifBlank { st.name })
            val take = if (st.sourcesUsed == 0) 4 else 2
            val from = st.sourcesUsed % maxOf(urls.size, 1)
            val chosen = (urls.drop(from) + urls.take(from)).take(take)
            next = next.copy(sourcesUsed = st.sourcesUsed + chosen.size)
            pool.others += chosen.map { u ->
                async {
                    try {
                        Music.collection(u).second.items
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
            }.awaitAll().flatten()
            if (seedPicks.isNotEmpty()) pool.others += seedPicks.take(2).map { async { radio(it) } }.awaitAll().flatten()
            return@coroutineScope next to arrange(next, pool, recent, queued, mainKey = "")
        }

        // Artist and song stations: built around the artist they started from
        val seed = st.seed
        val mainName = if (st.kind == Station.ARTIST) st.name else seed?.artist.orEmpty()
        val mainUrl = if (st.kind == Station.ARTIST) st.artistUrl else seed?.artistUrl.orEmpty()
        val mainKey = artistKey(mainName)

        val mainSongs = async { if (mainName.isNotBlank()) topSongs(mainName, mainUrl) else emptyList() }
        val relatedNames = async { if (mainName.isNotBlank()) related(mainName) else emptyList() }
        // Song-level "sounds like this": YouTube's mix of the seed song (and thumbs-up songs)
        val radioSeeds = (listOfNotNull(seed) + seedPicks).distinctBy { it.videoId }.take(3)
        val radios = radioSeeds.map { async { radio(it) } }.awaitAll().flatten()
        pool.main += mainSongs.await()

        // Which related artists to feature this time. Familiar sticks to the closest few,
        // Adventurous reaches down the list. Ones already featured wait their turn.
        var names = relatedNames.await()
        if (names.isEmpty()) {
            // No related-artist data: use the other artists in YouTube's mix
            names = radios.map { it.artist }.filter { artistKey(it) != mainKey && artistKey(it).isNotEmpty() }
                .groupBy { artistKey(it) }.entries.sortedByDescending { it.value.size }.map { it.value.first() }
        }
        val reach = listOf(8, 12, 18, 28, 40)[variety]
        val used = st.usedArtists.toHashSet()
        val candidates = names.take(reach)
            .filter { artistKey(it) != mainKey && (st.cooled[artistKey(it)] ?: 0) < 2 }
        val fresh = candidates.filter { artistKey(it) !in used }
        val pick = (fresh.shuffled() + candidates.filter { artistKey(it) in used }.shuffled()).take(8).toMutableList()
        // Adventurous: one hop further, an artist related to a related artist
        if (variety >= 3 && candidates.isNotEmpty()) {
            val hop = related(candidates.random()).filter { n -> artistKey(n) != mainKey && names.none { artistKey(it) == artistKey(n) } }
            hop.shuffled().take(2).forEach { pick += it }
        }
        next = next.copy(
            usedArtists = (st.usedArtists + pick.map { artistKey(it) }).takeLast(maxOf(10, candidates.size - 4))
        )
        val songsEach = listOf(5, 6, 8, 10, 12)[variety]
        val relatedSongs = pick.map { n -> async { topSongs(n).take(songsEach).shuffled().take(3) } }.awaitAll().flatten()

        // Interleave: related artists' songs and the song-level mix, minus the main artist
        val mixOthers = radios.filter { artistKey(it.artist) != mainKey }
        val merged = ArrayList<Track>()
        val a = relatedSongs.shuffled().iterator()
        val b = mixOthers.iterator()
        while (a.hasNext() || b.hasNext()) {
            if (a.hasNext()) merged += a.next()
            if (a.hasNext()) merged += a.next()
            if (b.hasNext()) merged += b.next()
        }
        pool.others += merged
        pool.main += radios.filter { artistKey(it.artist) == mainKey }
        next to arrange(next, pool, recent, queued, mainKey)
    }

    /**
     * Orders a pool like a radio station: no artist twice within [GAP] songs, at most a couple of
     * songs per artist per refill, and the station's own artist only every so often.
     * If the rules can't be met it stops early (the next refill comes sooner) rather than
     * falling back to the same artist again.
     */
    fun arrange(st: Station, pool: Pool, recent: List<Track>, queued: Set<String>, mainKey: String): List<Track> {
        val variety = Settings.current.smartVariety.coerceIn(0, 4)
        val playedSet = st.played.toHashSet()
        val banned = st.banned.toHashSet()
        val heardLately = Library.value.history.take(40).map { it.track.videoId }.toHashSet()
        val likedIds = st.liked.map { it.videoId }.toHashSet()
        // Artists you hid never come up (unless it's the station you picked yourself)
        val hidden = Library.hiddenKeys() - mainKey

        fun ok(t: Track): Boolean {
            val id = t.videoId
            if (id in banned || id in playedSet || id in queued) return false
            if (hidden.isNotEmpty() && artistKey(t.artist) in hidden) return false
            if (t.duration > 600 || t.duration in 1L..59L) return false
            return (st.cooled[artistKey(t.artist)] ?: 0) < 2
        }

        fun ranked(list: List<Track>): ArrayList<Track> {
            val unique = list.distinctBy { it.videoId }.filter(::ok)
            val scored = unique.mapIndexed { i, t ->
                var s = 1.0 - i.toDouble() / maxOf(unique.size, 1) + Math.random() * 0.8
                if (t.videoId in likedIds) s += 0.4
                if (t.videoId in heardLately) s -= 0.5
                if ((st.cooled[artistKey(t.artist)] ?: 0) == 1) s -= 0.6
                s to t
            }
            return ArrayList(scored.sortedByDescending { it.first }.map { it.second })
        }

        val main = if (mainKey.isNotEmpty()) ranked(pool.main) else ArrayList()
        val others = ranked(pool.others.filter { mainKey.isEmpty() || artistKey(it.artist) != mainKey })

        // How often the starting artist comes back: Familiar every 5th song … Adventurous every 12th
        val mainEvery = if (st.kind == Station.ARTIST) listOf(5, 6, 8, 10, 12)[variety] else listOf(6, 8, 10, 12, 15)[variety]
        val perArtist = 2
        val out = ArrayList<Track>()
        val window = ArrayDeque(recent.takeLast(GAP).map { artistKey(it.artist) })
        val counts = HashMap<String, Int>()
        val tail = recent.takeLast(mainEvery)
        val lastMain = tail.indexOfLast { artistKey(it.artist) == mainKey }
        // An artist station opens with the artist; after that they're a guest
        var sinceMain = when {
            mainKey.isEmpty() -> 0
            lastMain >= 0 -> tail.size - 1 - lastMain
            recent.isEmpty() && st.kind == Station.ARTIST -> mainEvery
            else -> mainEvery / 2
        }

        fun push(t: Track) {
            val k = artistKey(t.artist)
            out += t
            window.addLast(k)
            while (window.size > GAP) window.removeFirst()
            counts[k] = (counts[k] ?: 0) + 1
        }

        while (out.size < BATCH) {
            if (mainKey.isNotEmpty() && main.isNotEmpty() && sinceMain >= mainEvery - 1 && mainKey !in window.toList().takeLast(GAP - 1)) {
                push(main.removeAt(0))
                sinceMain = 0
                continue
            }
            val idx = others.indexOfFirst { t ->
                val k = artistKey(t.artist)
                k !in window && (counts[k] ?: 0) < perArtist
            }
            if (idx < 0) break
            push(others.removeAt(idx))
            sinceMain++
        }
        if (out.isEmpty()) {
            // Very thin pool (niche artist): relax the spacing rather than play nothing
            val rest = (others + main).filter { it.videoId !in queued && artistKey(it.artist) !in hidden }
            return ArrayList(rest.take(10))
        }
        return out
    }
}
