package app.siren.player

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaSession
import app.siren.MainActivity
import app.siren.data.Library
import app.siren.data.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Hosts the media session: background playback, the notification, lockscreen,
 * headset / Bluetooth buttons, and Android Auto (browse, search, voice, controls).
 */
@UnstableApi
class PlaybackService : MediaLibraryService() {
    private var session: MediaLibrarySession? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onCreate() {
        super.onCreate()
        PlayerController.init(applicationContext)
        val open = Intent(this, MainActivity::class.java)
            .setAction(MainActivity.ACTION_OPEN_PLAYER)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            this, 1, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val s = MediaLibrarySession.Builder(this, SessionPlayer(PlayerController.player), AutoLibrary(scope))
            .setSessionActivity(pi)
            .setCustomLayout(AutoLibrary.layout(false, false, false, 0, Settings.current))
            .build()
        session = s
        running = true

        // Extra buttons next to the controls (like, shuffle / smart shuffle, repeat), kept in sync
        scope.launch {
            val liked = combine(PlayerController.current, Library.data) { t, lib ->
                t != null && lib.liked.any { it.videoId == t.videoId }
            }.distinctUntilChanged()
            val buttons = Settings.state
                .map { Triple(it.autoLikeButton, it.autoShuffleButton, it.autoRepeatButton) }
                .distinctUntilChanged()
            combine(liked, PlayerController.shuffle, PlayerController.smart, PlayerController.repeat, buttons) { l, sh, sm, rp, b ->
                listOf(l, sh, sm, rp, b)
            }.distinctUntilChanged().collect {
                val p = PlayerController
                s.setCustomLayout(AutoLibrary.layout(it[0] as Boolean, p.shuffle.value, p.smart.value, p.repeat.value, Settings.current))
            }
        }

        // List / grid changed in Settings: ask the car to reload the tabs
        scope.launch {
            Settings.state
                .map { listOf(it.autoGridHome, it.autoGridLiked, it.autoGridPlaylists, it.autoGridSongs, it.autoGridDownloads) }
                .distinctUntilChanged()
                .drop(1)
                .collect {
                    s.notifyChildrenChanged(AutoLibrary.ROOT, 4, null)
                    s.notifyChildrenChanged(AutoLibrary.PLAYLISTS, Library.value.playlists.size + Library.value.saved.size, null)
                }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        running = false
        scope.cancel()
        // The player is app-wide; only the session goes away with the service.
        session?.release()
        session = null
        super.onDestroy()
    }

    companion object {
        /** True while the service is up (used by the home screen widget). */
        @Volatile
        var running = false
            private set
    }
}
