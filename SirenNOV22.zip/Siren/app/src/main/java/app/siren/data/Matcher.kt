package app.siren.data

import app.siren.core.Entry
import app.siren.core.Music
import app.siren.core.Track
import app.siren.core.cleanArtist
import java.text.Normalizer
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

/**
 * Finds the YouTube Music version of a song from its title / artist / length (Exportify, text
 * lists). Searches YouTube Music's Songs first (real tracks, not lyric videos or covers), scores
 * every result, and only accepts a clear match. Close-but-unsure results come back as [Unsure]
 * so the person can decide, instead of the wrong song slipping in.
 */
object Matcher {

    sealed interface Result {
        data class Found(val track: Track) : Result
        data class Unsure(val best: Track) : Result
        data object Missing : Result
        /** Every search failed (no connection, rate limited): try again later. */
        data object Error : Result
    }

    private const val ACCEPT = 0.72
    private const val MAYBE = 0.45

    suspend fun match(item: ImportItem): Result {
        val artists = splitArtists(item.artist)
        val q = listOf(item.title, artists.firstOrNull() ?: item.artist).filter { it.isNotBlank() }.joinToString(" ")
        if (q.isBlank()) return Result.Missing

        var best: Track? = null
        var bestScore = -1.0
        var failures = 0
        var tries = 0
        for (filter in listOf(Music.SONGS, Music.VIDEOS)) {
            tries++
            val results = try {
                Music.search(q, filter).items.filterIsInstance<Entry.Song>().map { it.track }.take(10)
            } catch (e: Exception) {
                failures++
                emptyList()
            }
            results.forEachIndexed { i, t ->
                // Videos are a fallback: a small nudge toward Songs results on a tie
                val s = score(item, artists, t) + (if (i == 0) 0.03 else 0.0) - (if (filter == Music.VIDEOS) 0.04 else 0.0)
                if (s > bestScore) {
                    bestScore = s
                    best = t
                }
            }
            if (bestScore >= ACCEPT) break
        }
        if (failures == tries) return Result.Error
        val b = best ?: return Result.Missing
        return when {
            bestScore >= ACCEPT -> Result.Found(b.copy(album = b.album.ifBlank { item.album }))
            bestScore >= MAYBE -> Result.Unsure(b)
            else -> Result.Missing
        }
    }

    // ---------------- Scoring ----------------

    private val variantWords = listOf(
        "live", "cover", "karaoke", "instrumental", "remix", "acoustic", "sped", "slowed", "nightcore",
        "reverb", "8d", "demo", "lofi", "piano", "orchestral", "mashup", "bass boosted", "tribute", "reprise"
    )

    private fun score(item: ImportItem, artists: List<String>, t: Track): Double {
        val srcTitle = norm(item.title)
        val candTitle = norm(t.title)
        val candArtist = norm(cleanArtist(t.artist))

        if (item.loose && artists.isEmpty()) {
            // A plain line of text: how much of it does the result cover?
            val want = tokens(srcTitle)
            val have = tokens("$candTitle $candArtist")
            if (want.isEmpty()) return 0.0
            return want.count { it in have }.toDouble() / want.size - variantPenalty(srcTitle, candTitle)
        }

        val titleS = titleScore(core(item.title), core(t.title))
        val artistS = if (artists.isEmpty()) 0.6 else artistScore(artists, candArtist, candTitle)
        val durS = if (item.durationSec > 0 && t.duration > 0) {
            when (abs(item.durationSec - t.duration)) {
                in 0L..3L -> 1.0
                in 4L..8L -> 0.8
                in 9L..20L -> 0.4
                in 21L..40L -> 0.0
                else -> -0.6
            }
        } else 0.6
        var s = 0.5 * titleS + 0.3 * artistS + 0.2 * durS - variantPenalty(srcTitle, candTitle)
        // A title that doesn't match, or a clearly different artist, is never a confident pick
        if (titleS < 0.6 || (artists.isNotEmpty() && artistS < 0.5)) s = minOf(s, ACCEPT - 0.01)
        return s
    }

    private fun variantPenalty(src: String, cand: String): Double {
        val srcT = " $src "
        val candT = " $cand "
        val extra = variantWords.count { w -> candT.contains(" $w ") && !srcT.contains(" $w ") }
        return minOf(0.5, extra * 0.35)
    }

    private fun titleScore(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        if (a == b) return 1.0
        val ta = tokens(a)
        val tb = tokens(b)
        if (ta.isEmpty() || tb.isEmpty()) return 0.0
        val common = ta.count { it in tb }.toDouble()
        val overlap = common / max(ta.size, tb.size)
        val contained = ta.all { it in tb } || tb.all { it in ta }
        return if (contained) max(overlap, 0.85) else overlap
    }

    private fun artistScore(artists: List<String>, candArtist: String, candTitle: String): Double {
        if (candArtist.isEmpty()) return if (artists.any { candTitle.contains(it) }) 0.8 else 0.3
        val padded = " $candArtist "
        for (a in artists) {
            if (a.isEmpty()) continue
            if (a == candArtist || padded.contains(" $a ") || " $a ".contains(padded)) return 1.0
        }
        // Featured artist credited in the title instead
        if (artists.any { it.isNotEmpty() && " $candTitle ".contains(" $it ") }) return 0.7
        val want = tokens(artists.first())
        val have = tokens(candArtist)
        if (want.isEmpty()) return 0.3
        return 0.6 * want.count { it in have } / want.size
    }

    /** "Song (feat. X) - 2011 Remaster" -> "song" */
    private fun core(title: String): String {
        var t = title
        t = t.replace(Regex("\\s*[(\\[][^)\\]]*[)\\]]"), " ")
        val dash = t.indexOf(" - ")
        if (dash > 0) t = t.substring(0, dash)
        t = t.replace(Regex("\\s(feat\\.?|ft\\.?|featuring|with)\\s.*$", RegexOption.IGNORE_CASE), "")
        return norm(t)
    }

    private fun splitArtists(raw: String): List<String> {
        if (raw.isBlank()) return emptyList()
        val whole = norm(raw)
        val parts = raw.split(',', ';', '&', '/').map { norm(it) }.filter { it.isNotEmpty() }
        // Keep the full string too: "Tyler, The Creator" splits badly
        return (parts + whole).distinct()
    }

    private fun tokens(s: String): Set<String> = s.split(' ').filter { it.isNotEmpty() }.toSet()

    fun norm(s: String): String {
        val n = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        return n.lowercase(Locale.ROOT)
            .replace("&", " and ")
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
    }
}
