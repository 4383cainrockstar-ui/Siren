package app.siren.data

import android.content.Context
import app.siren.core.Net
import app.siren.core.Track
import app.siren.core.cleanArtist
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Explicit versions by default.
 *
 * Many songs exist on YouTube Music twice: explicit and clean, with the same title. The extractor
 * Siren uses can't tell them apart, so this reads YouTube Music's own "E" badge (the same search
 * the website does) and:
 *  - remembers which songs are explicit (the E badge in lists and Android Auto),
 *  - finds the explicit twin of a clean song, so playback and downloads quietly use the explicit
 *    audio. The clean one is only used when there's no explicit version.
 *
 * Results are cached on disk, so each song is looked up once.
 */
object Explicit {

    @Serializable
    private data class Store(
        val explicit: Map<String, Boolean> = emptyMap(),
        /** videoId -> explicit twin's videoId ("" = checked, none). */
        val twins: Map<String, String> = emptyMap()
    )

    private val flags = ConcurrentHashMap<String, Boolean>()
    private val twins = ConcurrentHashMap<String, String>()
    /** Title/artist of songs that are queued, so a twin can be looked up by id alone. */
    private val known = ConcurrentHashMap<String, Pair<String, String>>()
    private var file: File? = null
    @Volatile private var dirty = false

    private val http: OkHttpClient by lazy {
        Net.client.newBuilder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .build()
    }

    fun init(ctx: Context) {
        val f = File(ctx.filesDir, "explicit.json")
        file = f
        try {
            if (f.exists()) {
                val s = LibraryJson.json.decodeFromString(Store.serializer(), f.readText())
                flags.putAll(s.explicit)
                twins.putAll(s.twins)
            }
        } catch (_: Exception) {
        }
    }

    /** Writes the cache if anything changed (cheap to call often). */
    fun save() {
        if (!dirty) return
        dirty = false
        val f = file ?: return
        try {
            // Keep it from growing forever
            val ex = if (flags.size > 8000) flags.entries.take(6000).associate { it.key to it.value } else HashMap(flags)
            val tw = if (twins.size > 8000) twins.entries.take(6000).associate { it.key to it.value } else HashMap(twins)
            f.writeText(LibraryJson.json.encodeToString(Store.serializer(), Store(ex, tw)))
        } catch (_: Exception) {
        }
    }

    fun isExplicit(videoId: String): Boolean = flags[videoId] == true

    /** Lets the explicit lookup work for queued songs (it needs the title and artist). */
    fun register(t: Track) {
        if (t.videoId.isNotBlank() && t.title.isNotBlank()) known[t.videoId] = t.title to t.artist
    }

    // ---------------- matching ----------------

    private val noise = Regex("(?i)\\s*[\\(\\[](clean|explicit|dirty|radio edit|clean version|explicit version|edited|censored)[\\)\\]]")
    private val feat = Regex("(?i)\\s*[\\(\\[]?(feat\\.?|ft\\.?|featuring|with)\\s.*$")

    /** "Song (feat. X) [Clean]" -> "song" */
    fun titleKey(title: String): String =
        title.replace(noise, "").replace(feat, "").lowercase()
            .replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun artistKey(artist: String): String =
        cleanArtist(artist).lowercase().split(",", " & ", " x ", " feat", " ft.", " and ").first()
            .replace(Regex("[^\\p{L}\\p{N} ]"), "").trim()

    private fun looksClean(title: String): Boolean =
        Regex("(?i)[\\(\\[](clean|radio edit|clean version|edited|censored)[\\)\\]]").containsMatchIn(title)

    // ---------------- YouTube Music search (songs) ----------------

    class Hit(val videoId: String, val title: String, val artist: String, val explicit: Boolean)

    private const val SONGS_PARAMS = "EgWKAQIIAWoMEA4QChADEAQQCRAF"

    /** YouTube Music's song search with explicit badges. Empty on any failure. Blocking. */
    fun searchSongs(query: String): List<Hit> {
        if (query.isBlank()) return emptyList()
        return try {
            val body = buildJsonObject {
                putJsonObject("context") {
                    putJsonObject("client") {
                        put("clientName", "WEB_REMIX")
                        put("clientVersion", "1.20241118.01.00")
                        put("hl", "en")
                        put("gl", "US")
                    }
                }
                put("query", query)
                put("params", SONGS_PARAMS)
            }.toString()
            val req = Request.Builder()
                .url("https://music.youtube.com/youtubei/v1/search?prettyPrint=false")
                .header("User-Agent", Net.USER_AGENT)
                .header("Origin", "https://music.youtube.com")
                .header("Referer", "https://music.youtube.com/")
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()
            val text = http.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.string() else null } ?: return emptyList()
            val root = LibraryJson.json.parseToJsonElement(text)
            val out = ArrayList<Hit>()
            collect(root, out)
            out.forEach { h -> if (flags.put(h.videoId, h.explicit) != h.explicit) dirty = true }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun collect(e: JsonElement, out: MutableList<Hit>) {
        when (e) {
            is JsonObject -> {
                val r = e["musicResponsiveListItemRenderer"]
                if (r is JsonObject) {
                    parseRow(r)?.let { out += it }
                    return
                }
                e.values.forEach { collect(it, out) }
            }
            is JsonArray -> e.forEach { collect(it, out) }
            else -> Unit
        }
    }

    private fun parseRow(r: JsonObject): Hit? {
        val id = findString(r["playlistItemData"], "videoId") ?: findString(r["overlay"], "videoId") ?: return null
        val cols = r["flexColumns"] as? JsonArray ?: return null
        val title = runsText(cols.getOrNull(0)) ?: return null
        val artist = runsFirst(cols.getOrNull(1)) ?: ""
        val explicit = r["badges"]?.toString()?.contains("MUSIC_EXPLICIT_BADGE") == true
        return Hit(id, title, artist, explicit)
    }

    private fun runsOf(col: JsonElement?): JsonArray? {
        val c = (col as? JsonObject)?.get("musicResponsiveListItemFlexColumnRenderer") as? JsonObject ?: return null
        return ((c["text"] as? JsonObject)?.get("runs")) as? JsonArray
    }

    private fun runsText(col: JsonElement?): String? =
        runsOf(col)?.joinToString("") { ((it as? JsonObject)?.get("text"))?.jsonPrimitive?.content ?: "" }?.takeIf { it.isNotBlank() }

    private fun runsFirst(col: JsonElement?): String? =
        runsOf(col)?.firstOrNull()?.let { ((it as? JsonObject)?.get("text"))?.jsonPrimitive?.content }

    private fun findString(e: JsonElement?, key: String): String? {
        when (e) {
            is JsonObject -> {
                e[key]?.let { v -> runCatching { v.jsonPrimitive.content }.getOrNull()?.let { return it } }
                for (v in e.values) findString(v, key)?.let { return it }
            }
            is JsonArray -> for (v in e) findString(v, key)?.let { return it }
            else -> Unit
        }
        return null
    }

    // ---------------- twins ----------------

    /**
     * The id to actually play for [videoId]: its explicit twin when it's the clean version and an
     * explicit one exists, otherwise itself. Blocking (network on first sight), so call it off the
     * main thread. Never throws.
     */
    fun playableId(videoId: String, track: Track? = null): String {
        if (!Settings.current.preferExplicit) return videoId
        twins[videoId]?.let { return it.ifBlank { videoId } }
        if (flags[videoId] == true) return videoId
        val (title, artist) = track?.let { it.title to it.artist } ?: known[videoId] ?: return videoId
        val hits = searchSongs("$title ${cleanArtist(artist)}")
        if (hits.isEmpty()) return videoId // offline or blocked: try again another time
        val tk = titleKey(title)
        val ak = artistKey(artist)
        val me = hits.firstOrNull { it.videoId == videoId }
        val twin = if (me?.explicit == true) null else hits.firstOrNull {
            it.explicit && it.videoId != videoId && titleKey(it.title) == tk &&
                (ak.isEmpty() || artistKey(it.artist) == ak || artistKey(it.artist).contains(ak) || ak.contains(artistKey(it.artist)))
        }
        // Only remember "no twin" when we actually saw this song (or it's clearly a clean edit)
        if (twin != null) {
            twins[videoId] = twin.videoId
            dirty = true
            save()
            return twin.videoId
        }
        if (me != null || looksClean(title)) {
            twins[videoId] = ""
            dirty = true
        }
        return videoId
    }

    /**
     * For a list of search results: drops a clean song when its explicit twin is also in the list,
     * so you see (and play) the explicit one.
     */
    fun preferExplicit(tracks: List<Track>): List<Track> {
        if (!Settings.current.preferExplicit) return tracks
        val explicitKeys = tracks.filter { flags[it.videoId] == true }.map { titleKey(it.title) + "|" + artistKey(it.artist) }.toHashSet()
        if (explicitKeys.isEmpty()) return tracks
        return tracks.filterNot { t ->
            flags[t.videoId] == false && (titleKey(t.title) + "|" + artistKey(t.artist)) in explicitKeys
        }
    }
}
