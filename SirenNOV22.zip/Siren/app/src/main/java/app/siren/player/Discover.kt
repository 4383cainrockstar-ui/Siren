package app.siren.player

import app.siren.core.Track
import app.siren.data.Library
import app.siren.data.withoutHidden
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.util.Calendar
import kotlin.random.Random

/** A Daily Mix: one of your artists plus the ones around them. Plays as a station. */
data class DailyMix(val number: Int, val anchor: String, val anchorTrack: Track, val names: List<String>, val image: String)

/** "Because you like Kanye West": songs from artists related to one you play a lot. */
data class Because(val artist: String, val tracks: List<Track>)

data class HomeFeed(
    /** Songs you haven't heard from artists related to the ones you play. */
    val forYou: List<Track> = emptyList(),
    val vibeTitle: String = "",
    val vibeSubtitle: String = "",
    /** Today's vibe: your songs for this time of day mixed with new ones. */
    val vibe: List<Track> = emptyList(),
    val mixes: List<DailyMix> = emptyList(),
    val because: List<Because> = emptyList(),
    /** Artists you might like (you don't play them yet). */
    val suggested: List<RelArtist> = emptyList()
)

/**
 * Home's "made for you" sections, from what you play and like plus related-artist data
 * (the same source radio uses). Nothing leaves the phone except the lookups themselves.
 */
object Discover {

    private class Taste(val name: String, val track: Track, var score: Double)

    private fun bucket(hour: Int) = when (hour) {
        in 5..11 -> 0
        in 12..16 -> 1
        in 17..21 -> 2
        else -> 3
    }

    private val vibeNames = listOf(
        "Morning boost" to "Easing into the day with music you like and some new finds",
        "Afternoon flow" to "Keep the day moving: your favorites and fresh picks",
        "Evening wind-down" to "Slower, smoother picks for tonight",
        "Late night" to "For the late hours, picked from what you play at night"
    )

    @Volatile private var last: HomeFeed? = null
    @Volatile private var lastAt = 0L

    /** The most recent feed, if it's still fresh (Home and Android Auto share it). */
    fun cached(maxAgeMs: Long = 3L * 3600 * 1000): HomeFeed? =
        last?.takeIf { System.currentTimeMillis() - lastAt < maxAgeMs }

    /** After hiding an artist: take them out of the feed we already have. */
    fun dropHidden() {
        val f = last ?: return
        last = f.copy(
            forYou = f.forYou.withoutHidden(),
            vibe = f.vibe.withoutHidden(),
            because = f.because.map { it.copy(tracks = it.tracks.withoutHidden()) }.filter { it.tracks.size >= 4 },
            suggested = f.suggested.filterNot { Library.isHiddenName(it.name) }
        )
    }

    suspend fun feed(): HomeFeed = build().also {
        if (it.vibe.isNotEmpty() || it.forYou.isNotEmpty() || it.mixes.isNotEmpty()) {
            last = it
            lastAt = System.currentTimeMillis()
        }
    }

    private suspend fun build(): HomeFeed = coroutineScope {
        val lib = Library.value
        val now = System.currentTimeMillis()

        // Your taste: artists weighted by plays (recent ones count double) and likes
        val taste = LinkedHashMap<String, Taste>()
        val hidden = Library.hiddenKeys()
        fun add(t: Track, w: Double) {
            val k = Stations.artistKey(t.artist)
            if (k.isEmpty() || k in hidden) return
            val e = taste.getOrPut(k) { Taste(t.artist, t, 0.0) }
            e.score += w
        }
        lib.history.take(500).forEach { p ->
            val recent = now - p.lastPlayed < 14L * 24 * 3600 * 1000
            add(p.track, p.plays * (if (recent) 2.0 else 1.0))
        }
        lib.liked.take(400).forEach { add(it, 2.0) }
        if (taste.isEmpty()) return@coroutineScope HomeFeed()

        val top = taste.values.sortedByDescending { it.score }.take(8)
        val known = taste.keys.toHashSet()
        val heard = (lib.history.map { it.track.videoId } + lib.liked.map { it.videoId }).toHashSet()

        // Related artists of your top 6, in parallel
        val rel = top.take(6).map { t -> async { t to Stations.relatedArtists(t.name) } }.awaitAll()

        // Artists you might like: high in several related lists, and not already yours
        val votes = LinkedHashMap<String, Pair<RelArtist, Double>>()
        rel.forEachIndexed { rank, (_, list) ->
            list.take(20).forEachIndexed { i, a ->
                val k = Stations.artistKey(a.name)
                if (k.isEmpty() || k in known || k in hidden) return@forEachIndexed
                val w = (20 - i) / 20.0 * (1.0 - rank * 0.08)
                val old = votes[k]
                votes[k] = (old?.first ?: a) to ((old?.second ?: 0.0) + w)
            }
        }
        val suggested = votes.values.sortedByDescending { it.second }.map { it.first }.take(14)

        // Tracks we think you'd like: popular songs by those artists that you haven't heard
        val forYouArtists = suggested.take(10)
        val forYouSongs = forYouArtists.map { a ->
            async { Stations.topSongs(a.name).filter { it.videoId !in heard }.withoutHidden().take(6).shuffled().take(3) }
        }.awaitAll()
        val forYou = spread(interleave(forYouSongs), gap = 3).take(24)

        // Daily mixes: your top 4 artists, each with the related artists that'll play around them
        val mixes = rel.take(4).mapIndexed { i, (t, list) ->
            DailyMix(i + 1, t.name, t.track, listOf(t.name) + list.take(3).map { it.name }, t.track.thumbnail)
        }

        // "Because you like …" for your top 2 artists (songs from the artists around them)
        val because = rel.take(2).map { (t, list) ->
            async {
                val songs = list.take(10).shuffled().take(5).map { a ->
                    async { Stations.topSongs(a.name).filter { it.videoId !in heard }.withoutHidden().take(5).shuffled().take(2) }
                }.awaitAll()
                Because(t.name, spread(interleave(songs), gap = 2).take(12))
            }
        }.awaitAll().filter { it.tracks.size >= 4 }

        // Today's vibe: songs you played around this time of day, mixed with new ones like them
        val cal = Calendar.getInstance()
        val b = bucket(cal.get(Calendar.HOUR_OF_DAY))
        val dayRandom = Random(cal.get(Calendar.YEAR) * 1000 + cal.get(Calendar.DAY_OF_YEAR) * 10 + b)
        val atThisHour = lib.history.filter {
            bucket(Calendar.getInstance().apply { timeInMillis = it.lastPlayed }.get(Calendar.HOUR_OF_DAY)) == b
        }.map { it.track }
        val yours = (atThisHour.ifEmpty { lib.history.take(60).map { it.track } } + lib.liked.take(80))
            .withoutHidden().distinctBy { it.videoId }.shuffled(dayRandom).take(14)
        val seeds = yours.take(2)
        val similar = seeds.map { s -> async { Stations.radio(s) } }.awaitAll().flatten()
            .filter { it.videoId !in heard }.withoutHidden().distinctBy { it.videoId }.shuffled(dayRandom).take(10)
        val newOnes = (similar + forYou.drop(12).shuffled(dayRandom).take(6)).distinctBy { it.videoId }
        val vibe = spread(interleave(listOf(yours, newOnes)), gap = 3).take(30)
        val (vt, vs) = vibeNames[b]

        HomeFeed(
            forYou = forYou,
            vibeTitle = vt,
            vibeSubtitle = vs,
            vibe = if (vibe.size >= 8) vibe else emptyList(),
            mixes = mixes,
            because = because,
            suggested = suggested
        )
    }

    /**
     * The weekly mix: about 70% songs you haven't heard (from artists around your taste) and 30%
     * songs you know, 30 in all. Songs from last week's mix are left out when there's enough else.
     */
    suspend fun weekly(): List<Track> = coroutineScope {
        val lib = Library.value
        val heard = (lib.history.map { it.track.videoId } + lib.liked.map { it.videoId }).toHashSet()
        val prev = Library.playlist(WeeklyMix.ID)?.tracks?.map { it.videoId }?.toHashSet() ?: hashSetOf<String>()
        val f = cached(24L * 3600 * 1000) ?: feed()

        val perArtist = f.suggested.filterNot { Library.isHiddenName(it.name) }.take(16).map { a ->
            async {
                val unheard = Stations.topSongs(a.name).filter { it.videoId !in heard }.withoutHidden()
                unheard.filter { it.videoId !in prev }.ifEmpty { unheard }.shuffled().take(4)
            }
        }.awaitAll()
        var fresh = spread(interleave(perArtist), gap = 3)

        if (fresh.size < 12) {
            // Little related-artist data: fall back to what YouTube Music's radio says is similar
            val seeds = Library.topPlayed(4).ifEmpty { lib.liked.take(4) }
            val have = fresh.map { it.videoId }.toHashSet()
            val extra = seeds.map { s -> async { Stations.radio(s) } }.awaitAll().flatten()
                .filter { it.videoId !in heard && it.videoId !in have }.withoutHidden()
            fresh = spread(interleave(listOf(fresh, extra)), gap = 3)
        }

        val newOnes = fresh.take(21)
        val familiar = (Library.topPlayed(40) + lib.liked.take(80)).withoutHidden().distinctBy { it.videoId }
            .shuffled().sortedBy { it.videoId in prev }.take(30 - newOnes.size)
        val half = (newOnes.size + 1) / 2
        spread(interleave(listOf(newOnes.take(half), newOnes.drop(half), familiar)), gap = 3).take(30)
    }

    /** Round-robin through several lists. */
    private fun interleave(lists: List<List<Track>>): List<Track> {
        val out = ArrayList<Track>()
        val its = lists.map { it.iterator() }
        var any = true
        while (any) {
            any = false
            for (iter in its) if (iter.hasNext()) {
                out += iter.next()
                any = true
            }
        }
        return out.distinctBy { it.videoId }
    }

    /** Reorders so the same artist doesn't play twice within [gap] songs (when possible). */
    private fun spread(list: List<Track>, gap: Int): List<Track> {
        val left = list.toMutableList()
        val out = ArrayList<Track>()
        while (left.isNotEmpty()) {
            val recent = out.takeLast(gap).map { Stations.artistKey(it.artist) }
            val i = left.indexOfFirst { Stations.artistKey(it.artist) !in recent }.let { if (it < 0) 0 else it }
            out += left.removeAt(i)
        }
        return out
    }
}
