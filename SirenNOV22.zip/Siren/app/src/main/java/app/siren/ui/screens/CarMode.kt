package app.siren.ui.screens

import app.siren.ui.components.SirenLoader
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.speech.RecognizerIntent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import app.siren.core.Track
import app.siren.data.Library
import app.siren.data.Settings
import app.siren.player.PlayerController
import app.siren.ui.LocalActions
import app.siren.ui.components.Artwork
import app.siren.ui.components.HoldNextButton
import app.siren.ui.theme.Sc
import kotlinx.coroutines.delay

private val Tile = Color(0xFF181818)

/** Bluetooth audio devices connected right now, by name (for picking your car). */
fun connectedBluetoothNames(ctx: Context): List<String> {
    val am = ctx.getSystemService(AudioManager::class.java) ?: return emptyList()
    return try {
        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .filter { isBluetooth(it) }
            .map { it.productName?.toString().orEmpty().trim() }
            .filter { it.isNotEmpty() }
            .distinct()
    } catch (_: Exception) {
        emptyList()
    }
}

fun isBluetooth(d: AudioDeviceInfo): Boolean = when (d.type) {
    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> true
    else -> android.os.Build.VERSION.SDK_INT >= 31 && (d.type == AudioDeviceInfo.TYPE_BLE_HEADSET || d.type == AudioDeviceInfo.TYPE_BLE_SPEAKER)
}

/**
 * Car mode: everything big, nothing to scroll, screen stays on. Hold Next (or tap
 * "Hide artist") to skip an artist for good. Works in portrait and landscape.
 */
@UnstableApi
@Composable
fun CarMode(onClose: () -> Unit) {
    val actions = LocalActions.current
    val ctx = LocalContext.current
    val view = LocalView.current
    val track by PlayerController.current.collectAsState()
    val playing by PlayerController.isPlaying.collectAsState()
    val buffering by PlayerController.buffering.collectAsState()
    val lib by Library.data.collectAsState()
    val settings by Settings.state.collectAsState()
    var progress by remember { mutableFloatStateOf(0f) }

    BackHandler(onBack = onClose)
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    LaunchedEffect(track?.videoId) {
        while (true) {
            val p = PlayerController.player
            val d = p.duration
            progress = if (d != C.TIME_UNSET && d > 0) (p.currentPosition.toFloat() / d).coerceIn(0f, 1f) else 0f
            delay(500)
        }
    }

    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.trim()
        if (!text.isNullOrBlank()) {
            PlayerController.playVoice(text, "", "", "")
            actions.message("Playing \"$text\"")
        }
    }
    val listen = {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "What do you want to hear?")
        try {
            voice.launch(i)
        } catch (_: ActivityNotFoundException) {
            actions.message("No voice input on this phone")
        }
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(enabled = false) {}
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        val landscape = maxWidth > maxHeight
        Column(Modifier.fillMaxSize()) {
            // Top: close, label, mic
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                RoundButton(Icons.Rounded.Close, "Leave car mode", 56, Tile, Color.White) { onClose() }
                Text(
                    "Car mode", color = Color.White.copy(alpha = 0.6f), fontSize = 16.sp, fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                )
                RoundButton(Icons.Rounded.Mic, "Say what to play", 64, Sc.Accent, Color.White) { listen() }
            }
            Spacer(Modifier.height(12.dp))

            val t = track
            if (t == null) {
                NothingPlaying(
                    onShuffleLiked = {
                        if (lib.liked.isEmpty()) actions.message("No liked songs yet")
                        else actions.playAll(lib.liked, shuffle = true, source = "Liked songs")
                    },
                    onMic = { listen() }
                )
            } else if (landscape) {
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    Artwork(t.thumbnail, Modifier.fillMaxHeight().aspectRatio(1f), corner = 16.dp, big = true)
                    Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                        SongText(t, progress)
                        Controls(t, playing, buffering, lib.liked.any { it.videoId == t.videoId }, settings.holdToHide, compact = true)
                    }
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Artwork(t.thumbnail, Modifier.aspectRatio(1f), corner = 16.dp, big = true)
                    }
                    Spacer(Modifier.height(16.dp))
                    SongText(t, progress)
                    Spacer(Modifier.height(16.dp))
                    Controls(t, playing, buffering, lib.liked.any { it.videoId == t.videoId }, settings.holdToHide, compact = false)
                }
            }
        }
    }
}

@Composable
private fun SongText(t: Track, progress: Float) {
    Column(Modifier.fillMaxWidth()) {
        Text(t.title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(t.artist, color = Color.White.copy(alpha = 0.65f), fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(5.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color.White.copy(alpha = 0.18f))
        ) {
            Box(Modifier.fillMaxWidth(progress).height(5.dp).background(Color.White))
        }
    }
}

@UnstableApi
@Composable
private fun Controls(t: Track, playing: Boolean, buffering: Boolean, liked: Boolean, holdToHide: Boolean, compact: Boolean) {
    val actions = LocalActions.current
    val big = if (compact) 92 else 104
    val small = if (compact) 72 else 84
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TileButton(Icons.Rounded.SkipPrevious, "Previous", null, big) { PlayerController.previous() }
            Box(
                Modifier
                    .weight(1f)
                    .height(big.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color.White)
                    .clickable { PlayerController.togglePlay() },
                contentAlignment = Alignment.Center
            ) {
                if (buffering && !playing) SirenLoader(size = 60.dp, color = Color.Black)
                else Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (playing) "Pause" else "Play", tint = Color.Black, modifier = Modifier.size(64.dp))
            }
            Box(
                Modifier
                    .weight(1f)
                    .height(big.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Tile),
                contentAlignment = Alignment.Center
            ) {
                HoldNextButton(
                    size = (big - 8).dp,
                    iconSize = 60.dp,
                    onNext = { PlayerController.next() },
                    onHold = if (holdToHide) ({ actions.hideArtist(t) }) else null,
                    tint = Color.White
                )
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TileButton(
                if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                if (liked) "Liked" else "Like", if (liked) "Liked" else "Like", small,
                tint = if (liked) Sc.Accent else Color.White
            ) { Library.toggleLike(t) }
            TileButton(Icons.Rounded.VisibilityOff, "Skip and hide this artist", "Hide artist", small) { actions.hideArtist(t) }
        }
    }
}

@Composable
private fun RowScope.TileButton(icon: ImageVector, desc: String, label: String?, height: Int, tint: Color = Color.White, onClick: () -> Unit) {
    Row(
        Modifier
            .weight(1f)
            .height(height.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Tile)
            .clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size(if (label == null) 60.dp else 38.dp))
        if (label != null) {
            Spacer(Modifier.width(12.dp))
            Text(label, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun RoundButton(icon: ImageVector, desc: String, size: Int, bg: Color, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(bg)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size((size * 0.5f).dp))
    }
}

@Composable
private fun ColumnScope.NothingPlaying(onShuffleLiked: () -> Unit, onMic: () -> Unit) {
    Column(
        Modifier.weight(1f).fillMaxWidth(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Nothing playing", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TileButton(Icons.Rounded.Shuffle, "Shuffle liked songs", "Liked songs", 104) { onShuffleLiked() }
            TileButton(Icons.Rounded.Mic, "Say what to play", "Say it", 104, tint = Sc.Accent) { onMic() }
        }
    }
}
