package app.siren.core

import app.siren.data.LocalMusic
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CoroutineScope
import app.siren.data.Settings
import app.siren.data.Explicit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.ListExtractor
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.StreamingService
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabs
import org.schabi.newpipe.extractor.feed.FeedInfo
import org.schabi.newpipe.extractor.kiosk.KioskInfo
import org.schabi.newpipe.extractor.linkhandler.ListLinkHandler
import org.schabi.newpipe.extractor.linkhandler.SearchQueryHandler
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.Collections
import java.util.Locale

/** A page of results plus whatever is needed to fetch the next one. */
data class Paged<T>(val items: List<T>, val next: Page?)

data class CollectionHeader(
    val ref: CollectionRef,
    val description: String
)

data class ArtistPage(
    val ref: ArtistRef,
    val banner: String,
    val description: String,
    val tabs: Map<String, ListLinkHandler>
)

/** Every YouTube Music call goes through here. All functions are main-safe. */
object Music {
    private val yt: StreamingService get() = ServiceList.YouTube

    const val SONGS = "music_songs"
    const val VIDEOS = "music_videos"
    const val ALBUMS = "music_albums"
    const val ARTISTS = "music_artists"
    const val PLAYLISTS = "music_playlists"

    val filters = listOf(SONGS to "Songs", VIDEOS to "Videos", ALBUMS to "Albums", ARTISTS to "Artists", PLAYLISTS to "Playlists")

    fun init() {
        val locale = Locale.getDefault()
        val loc = try {
            Localization.fromLocale(locale)
        } catch (e: Exception) {
            Localization.DEFAULT
        }
        val country = locale.country.takeIf { it.length == 2 }?.let { ContentCountry(it) }
            ?: ContentCountry.DEFAULT
        NewPipe.init(SirenDownloader(), loc, country)
    }

    // ---------------- Stream info cache (shared by the player, lyrics and downloads) ----------------

    private val infoCache: MutableMap<String, Pair<Long, StreamInfo>> =
        Collections.synchronizedMap(object : LinkedHashMap<String, Pair<Long, StreamInfo>>(64, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<Long, StreamInfo>>?): Boolean = size > 60
        })

    /** Blocking. Fetches (or reuses, for 2 hours) everything about one song. */
    fun streamBlocking(videoId: String, fresh: Boolean = false): StreamInfo {
        val now = System.currentTimeMillis()
        if (!fresh) {
            val hit = infoCache[videoId]
            if (hit != null && now - hit.first < 2 * 60 * 60 * 1000L) return hit.second
        }
        val info = StreamInfo.getInfo(yt, watchUrl(videoId))
        infoCache[videoId] = now to info
        return info
    }

    suspend fun stream(videoId: String, fresh: Boolean = false): StreamInfo =
        withContext(Dispatchers.IO) { streamBlocking(videoId, fresh) }

    fun cachedInfo(videoId: String): StreamInfo? = infoCache[videoId]?.second

    suspend fun track(url: String): Track {
        val id = videoIdFromUrl(url) ?: throw IllegalArgumentException("Not a song link")
        return stream(id).toTrack()
    }

    // ---------------- Search ----------------

    private fun query(q: String, filter: String): SearchQueryHandler =
        yt.searchQHFactory.fromQuery(q, listOf(filter), "")

    suspend fun suggestions(q: String): List<String> = withContext(Dispatchers.IO) {
        if (q.isBlank()) emptyList() else try {
            yt.suggestionExtractor.suggestionList(q)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun search(q: String, filter: String): Paged<Entry> = withContext(Dispatchers.IO) {
        // Songs: ask YouTube Music for its explicit badges at the same time (runs on its own,
        // so a slow answer never holds up results)
        val badges = if (filter == SONGS && Settings.current.preferExplicit) bg.async { Explicit.searchSongs(q) } else null
        val info = SearchInfo.getInfo(yt, query(q, filter))
        val albums = filter == ALBUMS
        var entries = info.relatedItems.mapNotNull { it.toEntry(albums) }
        if (badges != null) {
            withTimeoutOrNull(1500) { badges.await() }
            val keep = Explicit.preferExplicit(entries.filterIsInstance<Entry.Song>().map { it.track }).map { it.videoId }.toHashSet()
            entries = entries.filter { it !is Entry.Song || it.track.videoId in keep }
            Explicit.save()
        }
        Paged(entries, info.nextPage)
    }

    /** Background work that shouldn't hold up the caller (explicit badge lookups). */
    private val bg = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun searchMore(q: String, filter: String, page: Page): Paged<Entry> =
        withContext(Dispatchers.IO) {
            val p = SearchInfo.getMoreItems(yt, query(q, filter), page)
            val albums = filter == ALBUMS
            Paged(p.items.mapNotNull { it.toEntry(albums) }, p.nextPage)
        }

    /** Best single song match for "title artist" text (used by playlist import). */
    suspend fun bestMatch(text: String): Track? = withContext(Dispatchers.IO) {
        try {
            val info = SearchInfo.getInfo(yt, query(text, SONGS))
            info.relatedItems.filterIsInstance<StreamInfoItem>().firstOrNull()?.toTrack()
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- Radio (endless "similar songs") ----------------

    /** YouTube Music's own radio for a song, with the related list as a fallback. */
    suspend fun radio(seed0: Track): List<Track> = withContext(Dispatchers.IO) {
        // A song from the phone's own files: radio starts from the same song on YouTube Music
        val seed = if (LocalMusic.isLocal(seed0)) bestMatch("${seed0.title} ${seed0.artist}".trim()) ?: return@withContext emptyList() else seed0
        val id = seed.videoId
        val fromMix = try {
            val info = PlaylistInfo.getInfo(yt, "https://www.youtube.com/watch?v=$id&list=RDAMVM$id")
            info.relatedItems.map { it.toTrack() }
        } catch (e: Exception) {
            emptyList()
        }
        val list = fromMix.ifEmpty {
            try {
                streamBlocking(id).relatedItems.filterIsInstance<StreamInfoItem>()
                    .filter { it.duration in 1..900 }
                    .map { it.toTrack() }
            } catch (e: Exception) {
                emptyList()
            }
        }
        list.filter { it.videoId != id }.distinctBy { it.videoId }
    }

    // ---------------- Albums & playlists ----------------

    suspend fun collection(url: String): Pair<CollectionHeader, Paged<Track>> = withContext(Dispatchers.IO) {
        val info = PlaylistInfo.getInfo(yt, url)
        val tracks = info.relatedItems.map { it.toTrack() }
        val desc = try {
            info.description?.content ?: ""
        } catch (e: Exception) {
            ""
        }
        val thumb = info.thumbnails.bestUrl().ifBlank { tracks.firstOrNull()?.thumbnail ?: "" }
        val header = CollectionHeader(
            ref = CollectionRef(
                url = info.url ?: url,
                name = info.name ?: "",
                thumbnail = thumb,
                author = cleanArtist(info.uploaderName ?: ""),
                count = info.streamCount,
                isAlbum = url.contains("list=OLAK5uy_")
            ),
            description = desc
        )
        header to Paged(tracks, info.nextPage)
    }

    suspend fun collectionMore(url: String, page: Page): Paged<Track> = withContext(Dispatchers.IO) {
        val p = PlaylistInfo.getMoreItems(yt, url, page)
        Paged(p.items.map { it.toTrack() }, p.nextPage)
    }

    /** Every track of a playlist, following pages. */
    suspend fun allTracks(url: String, cap: Int = Int.MAX_VALUE): Pair<CollectionHeader, List<Track>> {
        val (header, first) = collection(url)
        val out = first.items.toMutableList()
        var next = first.next
        while (next != null && out.size < cap) {
            val p = collectionMore(url, next)
            out += p.items
            next = p.next
        }
        return header to out.distinctBy { it.videoId }
    }

    // ---------------- Artists ----------------

    suspend fun artist(url: String): ArtistPage = withContext(Dispatchers.IO) {
        val info = ChannelInfo.getInfo(yt, normalizeChannelUrl(url))
        val tabs = LinkedHashMap<String, ListLinkHandler>()
        for (t in info.tabs) {
            val name = t.contentFilters.firstOrNull() ?: continue
            if (name == ChannelTabs.VIDEOS || name == ChannelTabs.ALBUMS || name == ChannelTabs.PLAYLISTS) {
                tabs[name] = t
            }
        }
        ArtistPage(
            ref = ArtistRef(
                url = normalizeChannelUrl(info.url ?: url),
                name = cleanArtist(info.name ?: ""),
                avatar = info.avatars.bestUrl(480),
                subscribers = info.subscriberCount
            ),
            banner = info.banners.bestUrl(1080),
            description = info.description ?: "",
            tabs = tabs
        )
    }

    suspend fun artistTab(handler: ListLinkHandler): Paged<Entry> = withContext(Dispatchers.IO) {
        val info = ChannelTabInfo.getInfo(yt, handler)
        val albums = handler.contentFilters.firstOrNull() == ChannelTabs.ALBUMS
        Paged(info.relatedItems.mapNotNull { it.toEntry(albums) }, info.nextPage)
    }

    suspend fun artistTabMore(handler: ListLinkHandler, page: Page): Paged<Entry> = withContext(Dispatchers.IO) {
        val p: ListExtractor.InfoItemsPage<InfoItem> = ChannelTabInfo.getMoreItems(yt, handler, page)
        val albums = handler.contentFilters.firstOrNull() == ChannelTabs.ALBUMS
        Paged(p.items.mapNotNull { it.toEntry(albums) }, p.nextPage)
    }

    // ---------------- Artist music via YouTube Music search ----------------
    //
    // Many YouTube Music artist channels (especially auto-generated "Topic" ones) have no
    // usable Videos / Releases tabs on the YouTube side, so the artist page came up empty.
    // YouTube Music search always knows an artist's songs, albums and videos, so it fills
    // the page: songs come back roughly in popularity order, like a "Popular" list.

    private fun channelKey(url: String): String = url.trimEnd('/').substringAfterLast('/').substringBefore('?')

    private fun normName(s: String): String = s.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    /** Whether something credited to [creditName] / [creditUrl] belongs to the artist [name] / [url]. */
    fun byArtist(creditName: String, creditUrl: String, name: String, url: String): Boolean {
        val key = channelKey(url)
        if (key.startsWith("UC") && creditUrl.isNotBlank() && channelKey(creditUrl) == key) return true
        val n = normName(name)
        val a = normName(cleanArtist(creditName))
        if (n.isBlank() || a.isBlank()) return false
        return a == n || a.startsWith("$n ") || a.endsWith(" $n") || a.contains(" $n ")
    }

    /** The artist's songs, most popular first. */
    suspend fun artistSongs(name: String, url: String, limit: Int = 40): List<Track> = withContext(Dispatchers.IO) {
        val out = ArrayList<Track>()
        try {
            var page = search(name, SONGS)
            out += page.items.filterIsInstance<Entry.Song>().map { it.track }.filter { byArtist(it.artist, it.artistUrl, name, url) }
            var extra = 0
            while (out.size < 15 && extra < 2) {
                val next = page.next ?: break
                page = searchMore(name, SONGS, next)
                out += page.items.filterIsInstance<Entry.Song>().map { it.track }.filter { byArtist(it.artist, it.artistUrl, name, url) }
                extra++
            }
        } catch (e: Exception) {
        }
        out.distinctBy { it.videoId }
            .map { it.copy(artist = it.artist.ifBlank { name }, artistUrl = it.artistUrl.ifBlank { url }) }
            .take(limit)
    }

    /** Albums, EPs and singles by the artist. */
    suspend fun artistAlbums(name: String, url: String): List<CollectionRef> = withContext(Dispatchers.IO) {
        try {
            search(name, ALBUMS).items.filterIsInstance<Entry.Collection>().map { it.collection }
                .filter { byArtist(it.author, it.authorUrl, name, url) }
                .distinctBy { it.url }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** The artist's music videos. */
    suspend fun artistVideos(name: String, url: String): List<Track> = withContext(Dispatchers.IO) {
        try {
            search(name, VIDEOS).items.filterIsInstance<Entry.Song>().map { it.track }
                .filter { byArtist(it.artist, it.artistUrl, name, url) }
                .distinctBy { it.videoId }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Latest uploads from the artists you follow, newest first (uses the light RSS feeds). */
    suspend fun newReleases(artists: List<ArtistRef>, limit: Int = 30): List<Track> = coroutineScope {
        val gate = Semaphore(6)
        val results = artists.take(25).map { a ->
            async(Dispatchers.IO) {
                gate.withPermit {
                    try {
                        FeedInfo.getInfo(yt, a.url).relatedItems.take(6).map { item ->
                            val epoch = try {
                                item.uploadDate?.offsetDateTime()?.toInstant()?.toEpochMilli() ?: 0L
                            } catch (e: Exception) {
                                0L
                            }
                            val t = item.toTrack()
                            epoch to t.copy(artist = t.artist.ifBlank { a.name }, artistUrl = t.artistUrl.ifBlank { a.url })
                        }
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
            }
        }.awaitAll().flatten()
        results.filter { !it.second.url.contains("/shorts/") }
            .sortedByDescending { it.first }
            .map { it.second }
            .distinctBy { it.videoId }
            .take(limit)
    }

    // ---------------- Charts ----------------

    private fun kioskUrl(id: String): String =
        yt.kioskList.getListLinkHandlerFactoryByType(id).fromId(id).url

    suspend fun trending(): List<Track> = withContext(Dispatchers.IO) {
        val info = KioskInfo.getInfo(yt, kioskUrl("trending_music"))
        info.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toTrack() }
    }

    // ---------------- Links ----------------

    enum class LinkKind { SONG, ARTIST, COLLECTION, NONE }

    fun linkKind(url: String): LinkKind = try {
        when (yt.getLinkTypeByUrl(url)) {
            StreamingService.LinkType.STREAM -> LinkKind.SONG
            StreamingService.LinkType.CHANNEL -> LinkKind.ARTIST
            StreamingService.LinkType.PLAYLIST -> LinkKind.COLLECTION
            else -> LinkKind.NONE
        }
    } catch (e: Exception) {
        LinkKind.NONE
    }

    /** Pulls the first link out of shared text. */
    fun extractUrl(text: String?): String? {
        if (text.isNullOrBlank()) return null
        val m = Regex("https?://\\S+").find(text.trim()) ?: return null
        return m.value.trimEnd('.', ',', ')', ']', '"', '\'')
    }

    fun friendlyError(e: Throwable): String {
        val name = e.javaClass.simpleName
        val msg = e.message ?: ""
        return when {
            name.contains("ReCaptcha") -> "YouTube is rate limiting you. Try again in a bit."
            name.contains("AgeRestricted") -> "This song is age restricted."
            name.contains("Geographic") -> "This song isn't available in your country."
            name.contains("Private") -> "This is private."
            name.contains("Paid") || name.contains("Members") -> "This is for paying members only."
            name.contains("ContentNotAvailable") -> "This isn't available."
            e is java.net.UnknownHostException || e is java.net.SocketTimeoutException ->
                "No connection. Check your internet."
            msg.isNotBlank() -> msg.take(160)
            else -> "Something went wrong ($name)"
        }
    }
}
