package app.siren.core

import java.util.Locale

object Fmt {
    fun count(n: Long): String {
        if (n < 0) return ""
        return when {
            n >= 1_000_000_000 -> trim(n / 1_000_000_000.0) + "B"
            n >= 1_000_000 -> trim(n / 1_000_000.0) + "M"
            n >= 1_000 -> trim(n / 1_000.0) + "K"
            else -> n.toString()
        }
    }

    private fun trim(v: Double): String {
        val s = if (v >= 100) String.format(Locale.US, "%.0f", v) else String.format(Locale.US, "%.1f", v)
        return s.removeSuffix(".0")
    }

    fun duration(seconds: Long): String {
        if (seconds < 0) return ""
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    fun ms(ms: Long): String = duration((ms / 1000).coerceAtLeast(0))

    fun totalMinutes(tracks: List<Track>): String {
        val secs = tracks.sumOf { it.duration.coerceAtLeast(0) }
        if (secs <= 0) return ""
        val h = secs / 3600
        val m = (secs % 3600) / 60
        return if (h > 0) "$h hr $m min" else "$m min"
    }

    fun songs(n: Int): String = if (n == 1) "1 song" else "$n songs"

    fun bytes(b: Long): String {
        if (b <= 0) return ""
        val mb = b / 1024.0 / 1024.0
        return if (mb >= 1024) String.format(Locale.US, "%.2f GB", mb / 1024)
        else if (mb >= 1) String.format(Locale.US, "%.1f MB", mb)
        else String.format(Locale.US, "%.0f KB", b / 1024.0)
    }

    fun subtitle(t: Track): String =
        listOf(t.artist, if (t.duration > 0) duration(t.duration) else "").filter { it.isNotBlank() }.joinToString(" • ")
}
