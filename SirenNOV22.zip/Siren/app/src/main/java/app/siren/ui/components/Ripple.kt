package app.siren.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.siren.data.Settings
import app.siren.ui.theme.Sc
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/*
 * Siren's ripples. A button that "ripples" makes the whole screen bend in a shockwave from where
 * it sits (see Wave.kt). One RippleState per button:
 *  - put [waveSource] on a wrapper around the button, so the state knows where the button is,
 *  - call fire() when something happens.
 * They all switch off together with Settings > Appearance > Ripple effects.
 */
@Stable
class RippleState {
    /** Drives the Follow pill's color flood. */
    internal val progress = Animatable(0f)

    var trigger by mutableIntStateOf(0)
        private set

    /** Overrides the flood color for this one firing. */
    internal var tint: Color = Color.Unspecified

    /** Where the finger went down, in the button's own pixels (for the flood). */
    var origin: Offset = Offset.Unspecified

    /** Where the button is on screen (window pixels), kept up to date by [waveSource]. */
    internal var center: Offset = Offset.Unspecified

    /**
     * [strength] is how hard the wave bends (a pause is quieter than a play). [inward] makes the
     * wave close in on the button instead of spreading out from it.
     */
    fun fire(strength: Float = 1f, inward: Boolean = false, tint: Color = Color.Unspecified) {
        if (!Settings.current.rippleEffects) return
        this.tint = tint
        trigger++
        Wave.fire(center, strength, inward)
    }
}

@Composable
fun rememberRippleState(durationMs: Int = 560): RippleState {
    val s = remember { RippleState() }
    LaunchedEffect(s.trigger) {
        if (s.trigger > 0) {
            s.progress.snapTo(0f)
            s.progress.animateTo(1f, tween(durationMs, easing = LinearEasing))
            s.progress.snapTo(0f)
        }
    }
    return s
}

/** Tells the ripple where this button is on screen. Put it on the wrapper around the button. */
fun Modifier.waveSource(state: RippleState): Modifier =
    onGloballyPositioned { state.center = it.boundsInWindow().center }

/**
 * A color that grows from where you tapped until it covers the shape, then fades. Use on a
 * clipped pill (Follow).
 */
fun Modifier.rippleFlood(state: RippleState, color: Color = Sc.Accent): Modifier = drawBehind {
    val p = state.progress.value
    if (p <= 0.001f || p >= 0.999f) return@drawBehind
    val c = if (state.tint != Color.Unspecified) state.tint else color
    val o = if (state.origin != Offset.Unspecified) state.origin else Offset(size.width / 2f, size.height / 2f)
    val far = hypot(max(o.x, size.width - o.x), max(o.y, size.height - o.y))
    val grow = min(p / 0.6f, 1f)
    val eased = 1f - (1f - grow) * (1f - grow) * (1f - grow)
    val a = 0.42f * (1f - ((p - 0.45f) / 0.55f).coerceIn(0f, 1f))
    drawCircle(c.copy(alpha = c.alpha * a), radius = far * eased, center = o)
}

/** An IconButton with rings spreading out from it when tapped. */
@Composable
fun RippleIconButton(
    onClick: () -> Unit,
    from: Dp,
    to: Dp,
    modifier: Modifier = Modifier,
    buttonModifier: Modifier = Modifier,
    strength: Float = 1f,
    durationMs: Int = 480,
    color: Color = Sc.Accent,
    content: @Composable () -> Unit
) {
    val rp = rememberRippleState(durationMs)
    Box(modifier.waveSource(rp), contentAlignment = Alignment.Center) {
        IconButton(onClick = { rp.fire(strength); onClick() }, modifier = buttonModifier, content = content)
    }
}

/** The like button: the add / check icon with a pop, and rings when you add. */
@Composable
fun LikeButton(liked: Boolean, size: Dp, idleTint: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val rp = rememberRippleState(620)
    Box(modifier.waveSource(rp), contentAlignment = Alignment.Center) {
        IconButton(onClick = {
            if (!liked) rp.fire()
            onClick()
        }) { LikeIcon(liked, size, idleTint) }
    }
}

/**
 * Follow / Following pill. Following floods out from your finger in the accent color, unfollowing
 * in grey, and the outline eases between the two.
 */
@Composable
fun FollowButton(following: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val rp = rememberRippleState(520)
    val src = remember { MutableInteractionSource() }
    LaunchedEffect(src) {
        src.interactions.collect { if (it is PressInteraction.Press) rp.origin = it.pressPosition }
    }
    val border by animateColorAsState(if (following) Sc.Text else Sc.TextFaint, tween(300), label = "followBorder")
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .waveSource(rp)
            .height(34.dp)
            .clip(shape)
            .rippleFlood(rp)
            .border(1.dp, border, shape)
            .clickable(interactionSource = src, indication = null) {
                rp.fire(tint = if (!following) Sc.Accent else Sc.TextFaint)
                onClick()
            }
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Text(if (following) "Following" else "Follow", color = Sc.Text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

/**
 * A ripple that fires when something finishes: [running] was true and [done] just became true.
 * [key] says which item this is, so switching to another already-finished item doesn't fire.
 */
@Composable
fun rememberCompletionRipple(key: Any?, running: Boolean, done: Boolean): RippleState {
    val rp = rememberRippleState(720)
    var wasRunning by remember(key) { mutableStateOf(running) }
    LaunchedEffect(key, running, done) {
        if (wasRunning && done) rp.fire(inward = true)
        wasRunning = running
    }
    return rp
}
