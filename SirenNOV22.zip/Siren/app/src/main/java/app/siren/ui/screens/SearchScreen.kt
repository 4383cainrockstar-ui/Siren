package app.siren.ui.screens

import app.siren.ui.components.SkeletonRows
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import app.siren.player.Station
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Radio
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Celebration
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Landscape
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Nightlife
import androidx.compose.material.icons.rounded.NorthWest
import androidx.compose.material.icons.rounded.Piano
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import app.siren.core.Entry
import app.siren.core.Music
import app.siren.core.Paged
import app.siren.core.Track
import app.siren.data.Library
import app.siren.data.RecentPick
import app.siren.player.PlayerController
import app.siren.ui.LocalActions
import app.siren.ui.components.ArtistRow
import app.siren.ui.components.Artwork
import app.siren.ui.components.fastScroll
import app.siren.ui.components.Avatar
import app.siren.ui.components.Chip
import app.siren.ui.components.CollectionRow
import app.siren.ui.components.EmptyState
import app.siren.ui.components.EndReached
import app.siren.ui.components.ErrorBox
import app.siren.ui.components.Loading
import app.siren.ui.components.PagerVm
import app.siren.ui.components.PlayFab
import app.siren.ui.components.SelectionOverlay
import app.siren.ui.components.rememberSongSelection
import app.siren.ui.components.TrackActionsSheet
import app.siren.ui.components.TrackRow
import app.siren.ui.UiState
import app.siren.ui.theme.Sc
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.Page

class SearchVm : PagerVm<Entry>() {
    var query by mutableStateOf("")
        private set
    var filter by mutableStateOf(Music.SONGS)
        private set
    var suggestions by mutableStateOf<List<String>>(emptyList())
        private set
    private var suggestJob: Job? = null

    override suspend fun first(): Paged<Entry> = Music.search(query, filter)
    override suspend fun more(page: Page): Paged<Entry> = Music.searchMore(query, filter, page)
    override fun keyOf(item: Entry): Any = item.key

    fun submit(q: String, withFilter: String? = null) {
        val t = q.trim()
        if (t.isEmpty()) return
        query = t
        if (withFilter != null) filter = withFilter
        suggestions = emptyList()
        // Typed text isn't saved: only what you open from the results ends up in Recent searches
        reload()
    }

    fun changeFilter(f: String) {
        if (f == filter) return
        filter = f
        if (query.isNotBlank()) reload()
    }

    fun suggest(text: String) {
        suggestJob?.cancel()
        if (text.isBlank()) {
            suggestions = emptyList()
            return
        }
        suggestJob = viewModelScope.launch {
            delay(220)
            suggestions = Music.suggestions(text).take(8)
        }
    }
}

private class Mood(val name: String, val icon: ImageVector)

private val moods = listOf(
    Mood("Chill", Icons.Rounded.Spa),
    Mood("Workout", Icons.Rounded.FitnessCenter),
    Mood("Focus", Icons.Rounded.Psychology),
    Mood("Party", Icons.Rounded.Celebration),
    Mood("Sleep", Icons.Rounded.Bedtime),
    Mood("Feel good", Icons.Rounded.WbSunny),
    Mood("Throwbacks", Icons.Rounded.History),
    Mood("Hip hop", Icons.Rounded.Mic),
    Mood("Lo-fi", Icons.Rounded.Headphones),
    Mood("Rock", Icons.Rounded.Bolt),
    Mood("Pop", Icons.Rounded.Star),
    Mood("R&B", Icons.Rounded.Favorite),
    Mood("Latin", Icons.Rounded.Nightlife),
    Mood("K-pop", Icons.Rounded.AutoAwesome),
    Mood("Jazz", Icons.Rounded.Piano),
    Mood("Country", Icons.Rounded.Landscape),
    Mood("Electronic", Icons.Rounded.GraphicEq),
    Mood("Indie", Icons.Rounded.Album),
    Mood("Drill", Icons.Rounded.LocalFireDepartment),
    Mood("Soul", Icons.Rounded.Favorite)
)

@UnstableApi
@Composable
fun SearchScreen() {
    val actions = LocalActions.current
    val vm: SearchVm = viewModel()
    val lib by Library.data.collectAsState()
    val current by PlayerController.current.collectAsState()
    val playing by PlayerController.isPlaying.collectAsState()
    var text by rememberSaveable { mutableStateOf(vm.query) }
    var editing by rememberSaveable { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    val listState = rememberLazyListState()
    var menuFor by remember { mutableStateOf<Track?>(null) }
    EndReached(listState) { vm.loadMore() }

    fun go(q: String, filter: String? = null) {
        val clean = q.trim()
        if (clean.isEmpty()) return
        val url = Music.extractUrl(clean)
        if (url != null && Music.linkKind(url) != Music.LinkKind.NONE) {
            actions.link(url)
            return
        }
        text = clean
        editing = false
        focusManager.clearFocus()
        vm.submit(clean, filter)
    }

    val preset by UiState.searchFor.collectAsState()
    LaunchedEffect(preset) {
        val q = preset ?: return@LaunchedEffect
        UiState.searchFor.value = null
        go(q)
    }

    val showResults = !editing && vm.query.isNotBlank() && text.isNotBlank()
    // A new search starts at the top (so the radio card is never scrolled out of view)
    LaunchedEffect(vm.query, vm.filter) { listState.scrollToItem(0) }
    val sel = rememberSongSelection()
    LaunchedEffect(vm.query, vm.filter, showResults) { sel.clear() }
    val resultSongs = vm.items.filterIsInstance<Entry.Song>().map { it.track }

    fun openPick(p: RecentPick) {
        Library.addPick(p)
        when (p.kind) {
            RecentPick.SONG -> p.track?.let { actions.play(it, "Search") }
            RecentPick.ARTIST -> actions.artist(p.url)
            else -> actions.collection(p.url)
        }
    }

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize()) {
        Text(
            "Search",
            color = Sc.Text,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.5).sp,
            modifier = Modifier
                .statusBarsPadding()
                .padding(start = 16.dp, top = 14.dp, bottom = 12.dp)
        )
        SearchField(
            text = text,
            onText = {
                text = it
                editing = true
                vm.suggest(it)
            },
            onSearch = { go(text) },
            onClear = {
                text = ""
                editing = true
                vm.suggest("")
            },
            onFocus = { if (it) editing = true }
        )

        if (!showResults) {
            LazyColumn(Modifier.fillMaxSize()) {
                if (text.isBlank()) {
                    val recents = lib.recentPicks.take(10)
                    if (recents.isNotEmpty()) {
                        item(key = "recent-h") {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(start = 16.dp, end = 4.dp, top = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Recent searches", color = Sc.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                TextButton(onClick = { Library.clearSearches() }) {
                                    Text("Clear all", color = Sc.TextDim, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        items(recents, key = { "r:" + it.url }) { p ->
                            RecentRow(p, onClick = { openPick(p) }, onRemove = { Library.removePick(p.url) })
                        }
                    }
                    item(key = "stations-h") {
                        Text(
                            "Radio stations", color = Sc.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 10.dp)
                        )
                    }
                    item(key = "stations") {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(moods, key = { "st:" + it.name }) { m ->
                                StationTile(m) {
                                    PlayerController.playStation(Station.genre(m.name))
                                    actions.openPlayer()
                                }
                            }
                        }
                    }
                    item {
                        Text(
                            "Browse all", color = Sc.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 12.dp)
                        )
                    }
                    items(moods.chunked(2), key = { "m:" + it.first().name }) { pair ->
                        Row(
                            Modifier.padding(horizontal = 16.dp, vertical = 5.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            pair.forEach { m ->
                                MoodTile(m, Modifier.weight(1f)) { go("${m.name} playlist", Music.PLAYLISTS) }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                } else {
                    // Typing "___ radio": the station card pops up right away
                    val typed = text.trim()
                    if (Regex("(?i)\\b(radio|station)\\b").containsMatchIn(typed)) item(key = "station-typing") {
                        val name = typed.replace(Regex("(?i)\\b(radio|station)\\b"), " ").replace(Regex("\\s+"), " ").trim()
                        if (name.isNotEmpty()) StationCard(name) {
                            focusManager.clearFocus()
                            PlayerController.playStationFor(typed)
                            actions.openPlayer()
                        }
                    }
                    // Things you opened before that match what you're typing
                    val q = text.trim()
                    val matches = lib.recentPicks.filter { it.title.contains(q, ignoreCase = true) || it.subtitle.contains(q, ignoreCase = true) }.take(3)
                    items(matches, key = { "r:" + it.url }) { p ->
                        RecentRow(p, onClick = { openPick(p) }, onRemove = { Library.removePick(p.url) })
                    }
                    items(vm.suggestions, key = { "s:$it" }) { s ->
                        SuggestionRow(s, history = false, onClick = { go(s) }, onFill = { text = s; vm.suggest(s) }, onRemove = null)
                    }
                }
                item { Spacer(Modifier.height(28.dp)) }
            }
        } else {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(Music.filters) { (key, label) -> Chip(label, vm.filter == key, { vm.changeFilter(key) }) }
            }
            val err = vm.error
            val radioQuery = Regex("(?i)\\b(radio|station)\\b").containsMatchIn(vm.query)
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize().fastScroll(listState)) {
                if (radioQuery) item(key = "station") {
                    val name = vm.query.replace(Regex("(?i)\\b(radio|station)\\b"), " ").replace(Regex("\\s+"), " ").trim()
                    StationCard(name.ifBlank { "Hits" }) {
                        PlayerController.playStationFor(vm.query)
                        actions.openPlayer()
                    }
                }
                when {
                    vm.loading && vm.items.isEmpty() -> item { SkeletonRows(10) }
                    err != null && vm.items.isEmpty() -> item { ErrorBox(err, onRetry = { vm.reload() }) }
                    vm.items.isEmpty() && vm.started -> item {
                        EmptyState(Icons.Rounded.Search, "Couldn't find \"${vm.query}\"", "Check the spelling, or try another tab.")
                    }
                    else -> {
                        val songs = vm.items.filterIsInstance<Entry.Song>().map { it.track }
                        val top = (vm.items.firstOrNull() as? Entry.Song)?.track?.takeIf { vm.filter == Music.SONGS }
                        if (top != null) {
                            item(key = "top") {
                                TopResult(
                                    top,
                                    isCurrent = current?.videoId == top.videoId,
                                    isPlaying = playing,
                                    onPlay = {
                                        if (current?.videoId == top.videoId) PlayerController.togglePlay()
                                        else {
                                            Library.addPick(RecentPick.song(top))
                                            actions.play(top, "Search: ${vm.query}")
                                        }
                                    },
                                    onMore = { menuFor = top }
                                )
                            }
                            item(key = "songsh") {
                                Text("Songs", color = Sc.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 6.dp))
                            }
                        }
                        items(if (top != null) vm.items.drop(1) else vm.items, key = { it.key }) { e -> Box(Modifier.animateItem()) {
                            when (e) {
                                is Entry.Song -> TrackRow(
                                    track = e.track,
                                    playing = current?.videoId == e.track.videoId,
                                    isPlaying = playing,
                                    downloaded = Library.downloadedUri(e.track) != null,
                                    onClick = {
                                        if (sel.active) sel.toggle(e.track)
                                        else {
                                            Library.addPick(RecentPick.song(e.track))
                                            if (vm.filter == Music.SONGS || vm.filter == Music.VIDEOS) actions.play(e.track, "Search: ${vm.query}")
                                            else actions.playAll(songs, songs.indexOf(e.track).coerceAtLeast(0))
                                        }
                                    },
                                    onMore = if (sel.active) null else ({ menuFor = e.track }),
                                    onLongClick = { sel.toggle(e.track) },
                                    selected = if (sel.active) sel.isSelected(e.track) else null,
                                    showHidden = true
                                )
                                is Entry.Artist -> ArtistRow(e.artist, showHidden = true, onClick = {
                                    Library.addPick(RecentPick.artist(e.artist))
                                    actions.artist(e.artist.url)
                                })
                                is Entry.Collection -> CollectionRow(e.collection, onClick = {
                                    Library.addPick(RecentPick.collection(e.collection))
                                    actions.collection(e.collection.url)
                                })
                            }
                         }}
                    }
                }
                if (vm.loadingMore) item { Loading() }
                item { Spacer(Modifier.height(28.dp)) }
            }
        }
    }
    if (showResults) SelectionOverlay(sel, resultSongs)
    }

    menuFor?.let { t -> TrackActionsSheet(t, onDismiss = { menuFor = null }) }
}

/** White search box with black text, the way Spotify does it. */
@Composable
private fun SearchField(
    text: String,
    onText: (String) -> Unit,
    onSearch: () -> Unit,
    onClear: () -> Unit,
    onFocus: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(48.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color.White)
            .padding(start = 12.dp, end = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = Color.Black, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (text.isEmpty()) {
                Text("What do you want to listen to?", color = Color(0xFF535353), fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            }
            BasicTextField(
                value = text,
                onValueChange = onText,
                singleLine = true,
                textStyle = TextStyle(color = Color.Black, fontSize = 15.sp, fontWeight = FontWeight.Medium),
                cursorBrush = SolidColor(Sc.Accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                modifier = Modifier
                    .fillMaxWidth()
                    .onFocusChanged { onFocus(it.isFocused) }
            )
        }
        if (text.isNotEmpty()) {
            IconButton(onClick = onClear) { Icon(Icons.Rounded.Close, "Clear", tint = Color.Black) }
        }
    }
}

/** A genre / mood radio station on the Search page. */
@Composable
private fun StationTile(m: Mood, onClick: () -> Unit) {
    Row(
        Modifier
            .width(168.dp)
            .height(64.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Sc.tile(m.name))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Radio, null, tint = Color.White, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(m.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Radio", color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp)
        }
    }
}

/** "soulja boy radio" in Search: start a real station instead of digging through playlists. */
@Composable
private fun StationCard(name: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.horizontalGradient(listOf(Sc.AccentDeep, Sc.SurfaceHigh)))
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Radio, null, tint = Color.White, modifier = Modifier.size(28.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Start $name Radio", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("A station that keeps going with $name and music like it", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Rounded.PlayArrow, "Start", tint = Color.White, modifier = Modifier.size(30.dp))
    }
}

@Composable
private fun MoodTile(m: Mood, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(96.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Sc.tile(m.name))
            .clickable(onClick = onClick)
    ) {
        Text(
            m.name,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            modifier = Modifier.padding(12.dp)
        )
        Icon(
            m.icon, null,
            tint = Color.White.copy(alpha = 0.28f),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .offset(x = 10.dp, y = 8.dp)
                .rotate(25f)
                .size(64.dp)
        )
    }
}

@Composable
private fun TopResult(t: Track, isCurrent: Boolean, isPlaying: Boolean, onPlay: () -> Unit, onMore: () -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp)) {
        Text("Top result", color = Sc.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Sc.Surface)
                .clickable(onClick = onPlay)
                .padding(16.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Column(Modifier.weight(1f)) {
                Artwork(t.thumbnail, Modifier.size(92.dp))
                Spacer(Modifier.height(14.dp))
                Text(t.title, color = if (isCurrent) Sc.Accent else Sc.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 28.sp)
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Song", color = Sc.TextDim, fontSize = 13.sp)
                    Text("  •  ", color = Sc.TextDim, fontSize = 13.sp)
                    Text(t.artist, color = Sc.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                IconButton(onClick = onMore) { Icon(Icons.Rounded.MoreVert, "More", tint = Sc.TextDim) }
                Spacer(Modifier.height(16.dp))
                PlayFab(isCurrent && isPlaying, onPlay, size = 48.dp)
            }
        }
    }
}

/** A song / artist / album you opened before, with its art. */
@Composable
private fun RecentRow(p: RecentPick, onClick: () -> Unit, onRemove: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (p.kind == RecentPick.ARTIST) {
            Avatar(p.thumbnail, 48.dp)
        } else {
            Artwork(
                p.thumbnail, Modifier.size(48.dp),
                icon = if (p.kind == RecentPick.SONG) Icons.Rounded.MusicNote else Icons.Rounded.Album
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.title, color = Sc.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val kind = when (p.kind) {
                RecentPick.SONG -> "Song"
                RecentPick.ARTIST -> "Artist"
                else -> if (p.isAlbum) "Album" else "Playlist"
            }
            val sub = if (p.kind == RecentPick.ARTIST || p.subtitle.isBlank()) kind else "$kind • ${p.subtitle}"
            Text(sub, color = Sc.TextDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onRemove) { Icon(Icons.Rounded.Close, "Remove", tint = Sc.TextFaint, modifier = Modifier.size(20.dp)) }
    }
}

@Composable
private fun SuggestionRow(
    text: String,
    history: Boolean,
    onClick: () -> Unit,
    onFill: () -> Unit,
    onRemove: (() -> Unit)?
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Sc.SurfaceHigh),
            contentAlignment = Alignment.Center
        ) {
            Icon(if (history) Icons.Rounded.History else Icons.Rounded.Search, null, tint = Sc.TextDim, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(14.dp))
        Text(text, color = Sc.Text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        if (onRemove != null) {
            IconButton(onClick = onRemove) { Icon(Icons.Rounded.Close, "Remove", tint = Sc.TextFaint, modifier = Modifier.size(20.dp)) }
        } else {
            IconButton(onClick = onFill) { Icon(Icons.Rounded.NorthWest, "Fill", tint = Sc.TextFaint, modifier = Modifier.size(18.dp)) }
        }
    }
}
