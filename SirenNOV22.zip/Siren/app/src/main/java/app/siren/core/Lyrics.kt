package app.siren.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs

data class LyricLine(val timeMs: Long, val text: String)

data class Lyrics(
    val synced: List<LyricLine>,
    val plain: String,
    val instrumental: Boolean
) {
    val isEmpty: Boolean get() = synced.isEmpty() && plain.isBlank() && !instrumental
}

/** Lyrics from LRCLIB (free, open, no key), synced when available. */
object LyricsApi {
    private const val UA = "Siren 2.0 (Android music player)"
    private val cache = ConcurrentHashMap<String, Lyrics>()

    private fun get(url: String): String? = try {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        Net.client.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.string() else null }
    } catch (e: Exception) {
        null
    }

    private fun parse(o: JSONObject): Lyrics {
        val synced = o.optString("syncedLyrics", "").takeIf { it != "null" } ?: ""
        val plain = o.optString("plainLyrics", "").takeIf { it != "null" } ?: ""
        return Lyrics(parseLrc(synced), plain.trim(), o.optBoolean("instrumental", false))
    }

    fun parseLrc(lrc: String): List<LyricLine> {
        if (lrc.isBlank()) return emptyList()
        val tag = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?]")
        val out = mutableListOf<LyricLine>()
        for (raw in lrc.lines()) {
            val matches = tag.findAll(raw).toList()
            if (matches.isEmpty()) continue
            val text = raw.substring(matches.last().range.last + 1).trim()
            for (m in matches) {
                val min = m.groupValues[1].toLongOrNull() ?: 0
                val sec = m.groupValues[2].toLongOrNull() ?: 0
                val fracStr = m.groupValues[3]
                val frac = when (fracStr.length) {
                    0 -> 0L
                    1 -> fracStr.toLong() * 100
                    2 -> fracStr.toLong() * 10
                    else -> fracStr.take(3).toLong()
                }
                out += LyricLine(min * 60_000 + sec * 1000 + frac, text)
            }
        }
        return out.sortedBy { it.timeMs }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    suspend fun fetch(track: Track): Lyrics? = withContext(Dispatchers.IO) {
        val key = track.videoId
        cache[key]?.let { return@withContext it }
        val title = cleanTitle(track.title)
            .replace(Regex("\\s*[(\\[](feat|ft)\\.?[^)\\]]*[)\\]]", RegexOption.IGNORE_CASE), "")
            .trim()
        val artist = track.artist.substringBefore(",").substringBefore(" & ").substringBefore(" x ").trim()
        val dur = track.duration

        var result: Lyrics? = null
        if (artist.isNotBlank()) {
            val url = "https://lrclib.net/api/get?track_name=${enc(title)}&artist_name=${enc(artist)}" +
                if (dur > 0) "&duration=$dur" else ""
            result = get(url)?.let { runCatching { parse(JSONObject(it)) }.getOrNull() }
        }
        if (result == null || result.isEmpty) {
            val q = (title + " " + artist).trim()
            val body = get("https://lrclib.net/api/search?q=${enc(q)}")
            if (body != null) {
                val arr = runCatching { JSONArray(body) }.getOrNull()
                if (arr != null && arr.length() > 0) {
                    var best: JSONObject? = null
                    var bestScore = Double.MAX_VALUE
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val d = o.optDouble("duration", 0.0)
                        val hasSynced = !o.optString("syncedLyrics", "").let { it.isBlank() || it == "null" }
                        val score = (if (dur > 0 && d > 0) abs(d - dur) else 30.0) - (if (hasSynced) 5 else 0)
                        if (score < bestScore) {
                            bestScore = score
                            best = o
                        }
                    }
                    if (best != null && bestScore < 25) result = parse(best)
                }
            }
        }
        result?.let { if (!it.isEmpty) cache[key] = it }
        result
    }
}

data class Segment(val startMs: Long, val endMs: Long)

/** SponsorBlock's "non-music section" category: skips talking intros/outros in music videos. */
object NonMusic {
    private val cache = ConcurrentHashMap<String, List<Segment>>()

    private fun sha256(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    suspend fun segments(videoId: String): List<Segment> = withContext(Dispatchers.IO) {
        cache[videoId]?.let { return@withContext it }
        val out = mutableListOf<Segment>()
        try {
            val prefix = sha256(videoId).take(4)
            val url = "https://sponsor.ajay.app/api/skipSegments/$prefix?categories=" + enc("[\"music_offtopic\"]")
            val body = Net.getText(url)
            if (body != null) {
                val arr = JSONArray(body)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (o.optString("videoID") != videoId) continue
                    val segs = o.optJSONArray("segments") ?: continue
                    for (j in 0 until segs.length()) {
                        val s = segs.getJSONObject(j)
                        val pair = s.optJSONArray("segment") ?: continue
                        val a = (pair.optDouble(0, 0.0) * 1000).toLong()
                        val b = (pair.optDouble(1, 0.0) * 1000).toLong()
                        if (b > a) out += Segment(a, b)
                    }
                }
            }
        } catch (_: Exception) {
        }
        val sorted = out.sortedBy { it.startMs }
        cache[videoId] = sorted
        sorted
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}

