package app.siren.ui

import kotlinx.coroutines.flow.MutableStateFlow

/** Small bits of app-wide UI state shared between the Activity and Compose. */
object UiState {
    /** Whether the full-screen Now Playing view is open. */
    val playerOpen = MutableStateFlow(false)

    /** A navigation request coming from outside Compose (links, notifications). */
    val pending = MutableStateFlow<Pending?>(null)

    /** Car mode (big buttons, screen stays on) is showing. */
    val carMode = MutableStateFlow(false)

    /** Car mode already opened itself for the Bluetooth device that's connected now. */
    @Volatile var carAutoOpened = false

    /** Something to share on the share screen. */
    val share = MutableStateFlow<app.siren.ui.screens.ShareItem?>(null)

    /** Text for the Search tab to look up as soon as it opens. */
    val searchFor = MutableStateFlow<String?>(null)

    sealed interface Pending {
        data class Link(val url: String) : Pending
        data object OpenPlayer : Pending
        data object OpenDownloads : Pending
        data class OpenPlaylist(val id: String) : Pending
        /** "Hey Google, play ___ on Siren" */
        data class Voice(val query: String, val focus: String, val artist: String, val playlist: String) : Pending
    }
}
