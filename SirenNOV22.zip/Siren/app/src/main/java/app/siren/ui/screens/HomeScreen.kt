package app.siren.ui.screens

import app.siren.ui.components.pressClick
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import app.siren.ui.components.DropRefreshIndicator
import app.siren.ui.components.SkeletonShelf
import app.siren.ui.components.SkeletonCard
import app.siren.ui.components.SkeletonRows
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.ArrowCircleDown
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import app.siren.core.ArtistRef
import app.siren.core.Music
import app.siren.core.Track
import app.siren.data.DownloadRecord
import app.siren.data.Library
import app.siren.player.PlayerController
import androidx.compose.ui.graphics.Brush
import app.siren.ui.components.rememberArtColor
import app.siren.ui.components.PlayFab
import app.siren.player.Station
import app.siren.player.HomeFeed
import app.siren.player.Discover
import app.siren.ui.LocalActions
import app.siren.ui.Routes
import app.siren.ui.components.ArtistCircle
import app.siren.ui.components.Artwork
import app.siren.ui.components.BrandCover
import app.siren.ui.components.EmptyState
import app.siren.ui.components.Loading
import app.siren.ui.components.MixCard
import app.siren.ui.components.PlayingBars
import app.siren.ui.components.PrimaryButton
import app.siren.ui.components.SectionHeader
import app.siren.ui.components.SquareCard
import app.siren.ui.components.TrackActionsSheet
import app.siren.ui.components.shelf
import app.siren.ui.theme.Sc
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.util.Calendar

class HomeVm : ViewModel() {
    var trending by mutableStateOf<List<Track>>(emptyList())
        private set
    var releases by mutableStateOf<List<Track>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var feed by mutableStateOf(HomeFeed())
        private set
    var feedLoading by mutableStateOf(false)
        private set
    private var loadedFor: List<String> = listOf("-")
    private var feedAt = 0L

    /** "Made for you" sections. Rebuilt every few hours, on pull to refresh, or the first time you have history. */
    fun loadFeed(force: Boolean = false) {
        val stale = System.currentTimeMillis() - feedAt > 3 * 60 * 60 * 1000L
        if (!force && !stale && feed.forYou.isNotEmpty()) return
        feedAt = System.currentTimeMillis()
        viewModelScope.launch {
            feedLoading = true
            val f = runCatching { Discover.feed() }.getOrNull()
            feedLoading = false
            if (f == null) return@launch
            if (f.forYou.isNotEmpty() || f.mixes.isNotEmpty() || feed.forYou.isEmpty()) feed = f
        }
    }

    fun load(artists: List<ArtistRef>, force: Boolean = false) {
        val key = artists.map { it.url }
        if (!force && key == loadedFor) return
        loadedFor = key
        viewModelScope.launch {
            loading = true
            val t = async { runCatching { Music.trending() }.getOrDefault(emptyList()) }
            val r = async { if (artists.isEmpty()) emptyList() else runCatching { Music.newReleases(artists) }.getOrDefault(emptyList()) }
            val tr = t.await()
            if (tr.isNotEmpty() || trending.isEmpty()) trending = tr
            releases = r.await()
            loading = false
        }
    }
}

private fun greeting(): String = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
    in 5..11 -> "Good morning"
    in 12..17 -> "Good afternoon"
    in 18..22 -> "Good evening"
    else -> "Late night"
}

/** One tile in the 2-column shortcut grid at the top of Home. */
private class Shortcut(
    val key: String,
    val title: String,
    val source: String,
    val image: String = "",
    val cover: (@Composable () -> Unit)? = null,
    val onClick: () -> Unit
)

@UnstableApi
@Composable
fun HomeScreen() {
    val actions = LocalActions.current
    val vm: HomeVm = viewModel()
    val lib by Library.data.collectAsState()
    val current by PlayerController.current.collectAsState()
    val playing by PlayerController.isPlaying.collectAsState()
    val source by PlayerController.source.collectAsState()
    var menuFor by remember { mutableStateOf<Track?>(null) }

    LaunchedEffect(lib.artists) { vm.load(lib.artists) }
    val hasTaste = lib.history.isNotEmpty() || lib.liked.isNotEmpty()
    LaunchedEffect(hasTaste) { if (hasTaste) vm.loadFeed() }
    val feed = vm.feed

    val quick = remember(lib.history) { Library.topPlayed(20) }
    val recent = remember(lib.history) { lib.history.take(16).map { it.track } }
    val mixes = remember(lib.history) { Library.topArtists(6) }
    val fresh = lib.history.isEmpty() && lib.liked.isEmpty()
    val downloaded = lib.downloads.count { it.status == DownloadRecord.STATUS_DONE }

    val shortcuts = buildList {
        add(Shortcut("liked", "Liked songs", "Liked songs", cover = { BrandCover(Icons.Rounded.Favorite, Sc.likedCover, Modifier.fillMaxSize(), corner = 0.dp) }) {
            actions.open(Routes.LIKED)
        })
        if (downloaded > 0) add(Shortcut("downloads", "Downloads", "Downloads", cover = { BrandCover(Icons.Rounded.ArrowCircleDown, Sc.downloadsCover, Modifier.fillMaxSize(), corner = 0.dp) }) {
            actions.open(Routes.DOWNLOADS)
        })
        lib.playlists.sortedByDescending { it.updatedAt }.take(4).forEach { p ->
            add(Shortcut("p:" + p.id, p.name, p.name, image = p.tracks.firstOrNull()?.thumbnail ?: "") { actions.local(p.id) })
        }
        lib.saved.take(4).forEach { c ->
            add(Shortcut("c:" + c.url, c.name, c.name, image = c.thumbnail) { actions.collection(c.url) })
        }
        mixes.forEach { (artist, seed) ->
            add(Shortcut("m:$artist", "$artist Mix", "$artist Mix", image = seed.thumbnail) {
                PlayerController.playRadio(seed, "$artist Mix")
            })
        }
    }.distinctBy { it.key }.take(8)

    val pullState = rememberPullToRefreshState()
    val refreshing = vm.loading || vm.feedLoading
    PullToRefreshBox(
        isRefreshing = refreshing,
        onRefresh = {
            vm.load(lib.artists, force = true)
            vm.loadFeed(force = true)
        },
        state = pullState,
        modifier = Modifier.fillMaxSize(),
        indicator = {
            // Siren's drop instead of the arrow: the dot comes down as you pull, rings ripple while it loads
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 6.dp)
                    .graphicsLayer {
                        val f = if (refreshing) 1f else pullState.distanceFraction.coerceIn(0f, 1.3f)
                        translationY = f * 56.dp.toPx() - 28.dp.toPx()
                        alpha = if (refreshing) 1f else (pullState.distanceFraction * 2f).coerceIn(0f, 1f)
                    }
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(Sc.SurfaceHigh),
                contentAlignment = Alignment.Center
            ) {
                DropRefreshIndicator(pullState.distanceFraction, refreshing, size = 36.dp)
            }
        }
    ) {
        LazyColumn(Modifier.fillMaxSize()) {
            item(key = "header") {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(start = 16.dp, end = 4.dp, top = 12.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(greeting(), color = Sc.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = { actions.open(Routes.HISTORY) }) { Icon(Icons.Rounded.History, "Recently played", tint = Sc.Text) }
                    IconButton(onClick = { actions.open(Routes.SETTINGS) }) { Icon(Icons.Rounded.Settings, "Settings", tint = Sc.Text) }
                }
            }

            item(key = "shortcuts") {
                Column(
                    Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    shortcuts.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { s ->
                                ShortcutTile(s, playingHere = source == s.source && current != null, isPlaying = playing, modifier = Modifier.weight(1f))
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            if (fresh) {
                item(key = "welcome") {
                    EmptyState(
                        Icons.Rounded.Search,
                        "Welcome to Siren",
                        "No ads, no account. Find a song and Siren keeps the music going with similar tracks. Bring your Spotify playlists over from Your Library.",
                        action = { PrimaryButton("Find music", { actions.tab(Routes.SEARCH) }) }
                    )
                }
            }

            if (vm.feedLoading && feed.vibe.isEmpty() && feed.forYou.isEmpty() && hasTaste) {
                item(key = "feedSkeleton") {
                    Column {
                        SkeletonCard()
                        SkeletonShelf()
                    }
                }
            }

            if (feed.vibe.isNotEmpty()) {
                item(key = "vibe") {
                    VibeCard(feed.vibeTitle, feed.vibeSubtitle, feed.vibe, playingHere = source == "Today's vibe" && current != null, isPlaying = playing) {
                        if (source == "Today's vibe" && current != null) PlayerController.togglePlay()
                        else actions.playAll(feed.vibe, source = "Today's vibe")
                    }
                }
            }

            shelf("Jump back in", recent, key = { it.videoId }) { t ->
                SquareCard(
                    title = t.title, subtitle = t.artist, image = t.thumbnail,
                    onClick = { actions.play(t, "Recently played") },
                    onLongClick = { menuFor = t }
                )
            }

            if (feed.forYou.isNotEmpty()) {
                item(key = "fyh") {
                    SectionHeader("Tracks we think you'd like", action = "Play all", onAction = { actions.playAll(feed.forYou, source = "Picked for you") })
                }
                item(key = "fy") {
                    TrackColumns(feed.forYou, current?.videoId, playing, onPlay = { i -> actions.playAll(feed.forYou, i, source = "Picked for you") }, onMore = { menuFor = it })
                }
            }

            if (feed.mixes.isNotEmpty()) {
                shelf("Your daily mixes", feed.mixes, key = { "dm" + it.number }) { m ->
                    MixCard(
                        artist = "Daily Mix ${m.number}",
                        subtitle = m.names.joinToString(", ") + " and more",
                        image = m.image,
                        onClick = {
                            PlayerController.playStation(Station.artist(m.anchor, m.anchorTrack.artistUrl, m.image))
                            actions.openPlayer()
                        }
                    )
                }
            } else {
                shelf("Your mixes", mixes, key = { it.first }) { (artist, seed) ->
                    MixCard(
                        artist = artist,
                        subtitle = "$artist and more, picked from what you play",
                        image = seed.thumbnail,
                        onClick = { PlayerController.playRadio(seed, "$artist Mix"); actions.openPlayer() }
                    )
                }
            }

            feed.because.forEachIndexed { bi, b ->
                shelf("Because you like ${b.artist}", b.tracks, key = { "b$bi" + it.videoId }) { t ->
                    SquareCard(
                        title = t.title, subtitle = t.artist, image = t.thumbnail,
                        onClick = { actions.playAll(b.tracks, b.tracks.indexOf(t).coerceAtLeast(0), source = "Because you like ${b.artist}") },
                        onLongClick = { menuFor = t }
                    )
                }
            }

            shelf("Artists you might like", feed.suggested, key = { "sa:" + it.name }) { a ->
                ArtistCircle(ArtistRef(url = "", name = a.name, avatar = a.picture), onClick = { actions.artistNamed(a.name) })
            }

            if (quick.isNotEmpty()) {
                item(key = "qh") { SectionHeader("On repeat", action = "Play all", onAction = { actions.playAll(quick, source = "On repeat") }) }
                item(key = "q") {
                    TrackColumns(quick, current?.videoId, playing, onPlay = { i -> actions.playAll(quick, i, source = "On repeat") }, onMore = { menuFor = it })
                }
            }

            shelf("New releases for you", vm.releases, key = { it.videoId }) { t ->
                SquareCard(
                    title = t.title, subtitle = t.artist, image = t.thumbnail,
                    onClick = { actions.play(t, "New releases") },
                    onLongClick = { menuFor = t }
                )
            }

            shelf("Your albums & playlists", lib.saved.take(16), key = { it.url }) { c ->
                SquareCard(
                    title = c.name, subtitle = c.author, image = c.thumbnail,
                    icon = Icons.Rounded.Album, onClick = { actions.collection(c.url) }
                )
            }

            shelf("Artists you follow", lib.artists, key = { it.url }) { a ->
                ArtistCircle(a, onClick = { actions.artist(a.url) })
            }

            if (vm.trending.isNotEmpty()) {
                item(key = "th") {
                    SectionHeader("Trending now", action = "Play all", onAction = { actions.playAll(vm.trending, source = "Trending") })
                }
                item(key = "t") {
                    TrackColumns(vm.trending.take(24), current?.videoId, playing, onPlay = { i -> actions.playAll(vm.trending, i, source = "Trending") }, onMore = { menuFor = it })
                }
            } else if (vm.loading) {
                item(key = "tl") { SkeletonRows(6) }
            }

            item(key = "end") { Spacer(Modifier.height(28.dp)) }
        }
    }

    menuFor?.let { t -> TrackActionsSheet(t, onDismiss = { menuFor = null }) }
}

/** Big "Today's vibe" card: a mosaic of what's in it, the time-of-day name, and a play button. */
@Composable
private fun VibeCard(title: String, subtitle: String, tracks: List<Track>, playingHere: Boolean, isPlaying: Boolean, onPlay: () -> Unit) {
    val arts = tracks.map { it.thumbnail }.filter { it.isNotBlank() }.distinct().take(4)
    val tint = rememberArtColor(arts.firstOrNull() ?: "", Sc.AccentDeep)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .pressClick(scale = 0.98f, onClick = onPlay)
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.horizontalGradient(listOf(tint, Sc.SurfaceHigh)))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(96.dp).clip(RoundedCornerShape(6.dp))) {
            if (arts.size >= 4) {
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.weight(1f)) {
                        Artwork(arts[0], Modifier.weight(1f), corner = 0.dp)
                        Artwork(arts[1], Modifier.weight(1f), corner = 0.dp)
                    }
                    Row(Modifier.weight(1f)) {
                        Artwork(arts[2], Modifier.weight(1f), corner = 0.dp)
                        Artwork(arts[3], Modifier.weight(1f), corner = 0.dp)
                    }
                }
            } else Artwork(arts.firstOrNull() ?: "", Modifier.fillMaxSize(), corner = 0.dp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("TODAY'S VIBE", color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            Text(subtitle, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp, lineHeight = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text("${tracks.size} songs · changes through the day", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
        }
        Spacer(Modifier.width(8.dp))
        PlayFab(playing = playingHere && isPlaying, onClick = onPlay, size = 48.dp)
    }
}

@Composable
private fun ShortcutTile(s: Shortcut, playingHere: Boolean, isPlaying: Boolean, modifier: Modifier) {
    Row(
        modifier
            .pressClick(scale = 0.97f, onClick = s.onClick)
            .height(56.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Sc.SurfaceHigh),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(56.dp)) {
            if (s.cover != null) s.cover.invoke()
            else Artwork(s.image, Modifier.fillMaxSize(), corner = 0.dp)
        }
        Text(
            s.title,
            color = Sc.Text,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 16.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 10.dp)
        )
        if (playingHere) {
            PlayingBars(Modifier.padding(end = 10.dp), playing = isPlaying)
        }
    }
}

/** Columns of 4 compact rows that scroll sideways (quick picks, trending). */
@Composable
private fun TrackColumns(
    tracks: List<Track>,
    currentId: String?,
    playing: Boolean,
    onPlay: (Int) -> Unit,
    onMore: (Track) -> Unit
) {
    val columns = tracks.withIndex().chunked(4)
    LazyRow(contentPadding = PaddingValues(horizontal = 4.dp)) {
        items(columns.size) { c ->
            Column(Modifier.width(310.dp)) {
                columns[c].forEach { (i, t) ->
                    val isCurrent = t.videoId == currentId
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPlay(i) }
                            .padding(start = 12.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(50.dp), contentAlignment = Alignment.Center) {
                            Artwork(t.thumbnail, Modifier.fillMaxSize())
                            if (isCurrent) {
                                Box(
                                    Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.55f)),
                                    contentAlignment = Alignment.Center
                                ) { PlayingBars(playing = playing) }
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                t.title,
                                color = if (isCurrent) Sc.Accent else Sc.Text,
                                fontSize = 15.sp, fontWeight = FontWeight.Medium,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(t.artist, color = Sc.TextDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { onMore(t) }) {
                            Icon(Icons.Rounded.MoreVert, "More", tint = Sc.TextDim)
                        }
                    }
                }
            }
        }
    }
}
