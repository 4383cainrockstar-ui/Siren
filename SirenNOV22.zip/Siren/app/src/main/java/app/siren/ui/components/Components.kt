package app.siren.ui.components

import app.siren.data.Library
import app.siren.data.Explicit
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.ArrowCircleDown
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.ArrowCircleDown
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.siren.core.ArtistRef
import app.siren.core.CollectionRef
import app.siren.core.Fmt
import app.siren.core.Track
import app.siren.core.hiRes
import app.siren.ui.theme.Sc
import coil.compose.AsyncImage

// =============================================================================================
// Brand
// =============================================================================================

// =============================================================================================
// Artwork
// =============================================================================================

/** Square artwork with a quiet placeholder. Video thumbnails get center-cropped. */
@Composable
fun Artwork(
    url: String,
    modifier: Modifier = Modifier,
    corner: Dp = 4.dp,
    icon: ImageVector = Icons.Rounded.MusicNote,
    big: Boolean = false
) {
    Box(
        modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(corner))
            .background(Sc.SurfaceHighest),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = Sc.TextFaint, modifier = Modifier.fillMaxSize(0.36f))
        if (url.isNotBlank()) {
            AsyncImage(
                model = if (big) hiRes(url, 720) else hiRes(url, 300),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

/** Cover for Liked songs / Downloads. */
@Composable
fun BrandCover(icon: ImageVector, brush: Brush, modifier: Modifier = Modifier, corner: Dp = 4.dp) {
    Box(
        modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(corner))
            .background(brush),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.fillMaxSize(0.42f))
    }
}

@Composable
fun Avatar(url: String, size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Sc.SurfaceHighest),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.Person, null, tint = Sc.TextFaint, modifier = Modifier.size(size * 0.45f))
        if (url.isNotBlank()) {
            AsyncImage(model = hiRes(url, 400), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
    }
}

/** The little animated equalizer shown next to whatever is playing. */
@Composable
fun PlayingBars(modifier: Modifier = Modifier, playing: Boolean = true, color: Color = Sc.Accent) {
    val t = rememberInfiniteTransition(label = "bars")
    val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(420), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(1f, 0.25f, infiniteRepeatable(tween(530), RepeatMode.Reverse), label = "b")
    val c by t.animateFloat(0.5f, 0.9f, infiniteRepeatable(tween(360), RepeatMode.Reverse), label = "c")
    Row(modifier.size(14.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        listOf(a, b, c).forEach { h ->
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight(if (playing) h else 0.3f)
                    .background(color)
            )
        }
    }
}

// =============================================================================================
// Rows
// =============================================================================================

/** A song row. [selected] is non-null while picking songs: a check replaces the ⋮ menu. */
@Composable
fun TrackRow(
    track: Track,
    onClick: () -> Unit,
    onMore: (() -> Unit)?,
    modifier: Modifier = Modifier,
    playing: Boolean = false,
    isPlaying: Boolean = false,
    downloaded: Boolean = false,
    number: Int? = null,
    subtitle: String? = null,
    onLongClick: (() -> Unit)? = null,
    selected: Boolean? = null,
    /** Show a "Hidden" tag when the artist is hidden (Search uses this). */
    showHidden: Boolean = false,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        modifier
            .fillMaxWidth()
            .background(if (selected == true) Sc.Accent.copy(alpha = 0.14f) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick ?: onMore)
            .padding(start = 16.dp, end = 2.dp, top = 7.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (number != null) {
            Box(Modifier.width(24.dp), contentAlignment = Alignment.Center) {
                if (playing) PlayingBars(playing = isPlaying)
                else Text(number.toString(), color = Sc.TextDim, fontSize = 15.sp)
            }
            Spacer(Modifier.width(14.dp))
        } else {
            Box(Modifier.size(50.dp)) {
                Artwork(track.thumbnail, Modifier.fillMaxSize())
                if (playing) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.55f)),
                        contentAlignment = Alignment.Center
                    ) { PlayingBars(playing = isPlaying) }
                }
            }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                track.title,
                color = if (playing) Sc.Accent else Sc.Text,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (showHidden && Library.isHidden(track)) {
                    Tag("Hidden")
                    Spacer(Modifier.width(5.dp))
                }
                if (Explicit.isExplicit(track.videoId)) {
                    ExplicitBadge()
                    Spacer(Modifier.width(5.dp))
                }
                if (downloaded) {
                    Icon(Icons.Rounded.ArrowCircleDown, "Downloaded", tint = Sc.Accent, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(5.dp))
                }
                Text(
                    subtitle ?: Fmt.subtitle(track),
                    color = Sc.TextDim,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (selected != null) {
            Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                Icon(
                    if (selected) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                    if (selected) "Selected" else "Not selected",
                    tint = if (selected) Sc.Accent else Sc.TextDim,
                    modifier = Modifier.size(24.dp)
                )
            }
        } else {
            trailing?.invoke()
            if (onMore != null) {
                IconButton(onClick = onMore) { Icon(Icons.Rounded.MoreVert, "More", tint = Sc.TextDim) }
            }
        }
    }
}

/** A row in Your Library: playlists, albums, artists, Liked songs. */
@Composable
fun LibraryRow(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    image: String = "",
    circle: Boolean = false,
    pinned: Boolean = false,
    playing: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    cover: (@Composable () -> Unit)? = null
) {
    Row(
        modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(64.dp)) {
            when {
                cover != null -> cover()
                circle -> Avatar(image, 64.dp)
                else -> Artwork(image, Modifier.fillMaxSize(), icon = Icons.Rounded.Album)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                color = if (playing) Sc.Accent else Sc.Text,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (pinned) {
                    Icon(Icons.Rounded.PushPin, "Pinned", tint = Sc.Accent, modifier = Modifier.size(13.dp))
                    Spacer(Modifier.width(5.dp))
                }
                Text(subtitle, color = Sc.TextDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (playing) {
            Spacer(Modifier.width(8.dp))
            PlayingBars()
        }
    }
}

@Composable
fun ArtistRow(artist: ArtistRef, onClick: () -> Unit, modifier: Modifier = Modifier, showHidden: Boolean = false, trailing: (@Composable () -> Unit)? = null) {
    Row(
        modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(artist.avatar, 56.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(artist.name, color = Sc.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val subs = if (artist.subscribers > 0) "Artist • " + Fmt.count(artist.subscribers) + " subscribers" else "Artist"
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (showHidden && Library.isHiddenName(artist.name)) {
                    Tag("Hidden")
                    Spacer(Modifier.width(5.dp))
                }
                Text(subs, color = Sc.TextDim, fontSize = 13.sp)
            }
        }
        trailing?.invoke()
    }
}

@Composable
fun CollectionRow(c: CollectionRef, onClick: () -> Unit, modifier: Modifier = Modifier, onLongClick: (() -> Unit)? = null) {
    val parts = listOf(
        if (c.isAlbum) "Album" else "Playlist",
        c.author,
        if (c.count > 0) Fmt.songs(c.count.toInt()) else ""
    ).filter { it.isNotBlank() }
    LibraryRow(c.name, parts.joinToString(" • "), onClick, modifier, image = c.thumbnail, onLongClick = onLongClick)
}

// =============================================================================================
// Cards for shelves
// =============================================================================================

@Composable
fun SquareCard(
    title: String,
    subtitle: String,
    image: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    width: Dp = 148.dp,
    icon: ImageVector = Icons.Rounded.MusicNote,
    onLongClick: (() -> Unit)? = null
) {
    Column(
        modifier
            .width(width)
            .pressClick(onLongClick = onLongClick, onClick = onClick)
    ) {
        Artwork(image, Modifier.fillMaxWidth(), icon = icon)
        Spacer(Modifier.height(8.dp))
        Text(title, color = Sc.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 17.sp)
        if (subtitle.isNotBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(subtitle, color = Sc.TextDim, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 16.sp)
        }
    }
}

/** An artist mix: their art full-bleed with the name set on a colored band, like a daily mix. */
@Composable
fun MixCard(artist: String, subtitle: String, image: String, onClick: () -> Unit, modifier: Modifier = Modifier, width: Dp = 148.dp) {
    val band = rememberArtColor(image, Sc.tile(artist))
    Column(
        modifier
            .width(width)
            .pressClick(onClick = onClick)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(4.dp))
                .background(Sc.SurfaceHighest)
        ) {
            if (image.isNotBlank()) {
                AsyncImage(
                    model = hiRes(image, 300), contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            SirenMark(Modifier.align(Alignment.TopStart).padding(8.dp), size = 18.dp, color = Color.White)
            Box(
                Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomStart)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))))
                    .padding(start = 10.dp, end = 10.dp, top = 20.dp, bottom = 12.dp)
            ) {
                Text(artist, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .align(Alignment.BottomStart)
                    .background(band)
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(subtitle, color = Sc.TextDim, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 16.sp)
    }
}

@Composable
fun ArtistCircle(artist: ArtistRef, onClick: () -> Unit, modifier: Modifier = Modifier, size: Dp = 120.dp) {
    Column(
        modifier
            .width(size)
            .pressClick(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Avatar(artist.avatar, size)
        Spacer(Modifier.height(8.dp))
        Text(artist.name, color = Sc.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        Text("Artist", color = Sc.TextDim, fontSize = 12.sp)
    }
}

// =============================================================================================
// Chips, bars, headers
// =============================================================================================

/** Filter chip: grey pill, accent when selected. */
@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .height(32.dp)
            .clip(RoundedCornerShape(50))
            .background(if (selected) Sc.Accent else Sc.SurfaceHighest)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
    }
}

/** The round "x" in front of a selected chip that clears the filter. */
@Composable
fun ClearChip(onClick: () -> Unit) {
    Box(
        Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(Sc.SurfaceHighest)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.Close, "Clear filter", tint = Sc.Text, modifier = Modifier.size(18.dp))
    }
}

@Composable
fun TopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(56.dp)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Sc.Text) }
        } else Spacer(Modifier.width(12.dp))
        Text(
            title,
            color = Sc.Text,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        actions()
    }
}

@Composable
fun SectionHeader(text: String, modifier: Modifier = Modifier, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 8.dp, top = 28.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = Sc.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.3).sp, modifier = Modifier.weight(1f))
        if (action != null && onAction != null) {
            Text(
                action,
                color = Sc.TextDim,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable(onClick = onAction)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            )
        }
    }
}

/** A horizontal row of cards inside a LazyColumn. */
fun <T> LazyListScope.shelf(
    title: String,
    list: List<T>,
    key: (T) -> Any,
    action: String? = null,
    onAction: (() -> Unit)? = null,
    content: @Composable (T) -> Unit
) {
    if (list.isEmpty()) return
    item(key = "h:$title") { SectionHeader(title, action = action, onAction = onAction) }
    item(key = "r:$title") {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(list.size, key = { i -> key(list[i]) }) { i -> content(list[i]) }
        }
    }
}

// =============================================================================================
// Buttons
// =============================================================================================

/** Big round play / pause in the accent color. */
@Composable
fun PlayFab(playing: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier, size: Dp = 56.dp) {
    val rp = rememberRippleState(560)
    // Rings live on the wrapper, so the button's own clip doesn't cut them off
    Box(
        modifier
            .size(size)
            .waveSource(rp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .size(size)
                .clip(CircleShape)
                .background(Sc.Accent)
                .clickable {
                    rp.fire(if (playing) 0.55f else 1f)
                    onClick()
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                if (playing) "Pause" else "Play",
                tint = Color.White,
                modifier = Modifier.size(size * 0.56f)
            )
        }
    }
}

/** White pill with black text, for the one main action on an empty screen. */
@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null) {
    Row(
        modifier
            .height(44.dp)
            .clip(RoundedCornerShape(50))
            .background(Color.White)
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color.Black, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/** Outlined pill: Follow, Edit, secondary actions. */
@Composable
fun OutlineButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, active: Boolean = false) {
    Row(
        modifier
            .height(34.dp)
            .clip(RoundedCornerShape(50))
            .border(1.dp, if (active) Sc.Text else Sc.TextFaint, RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Sc.Text, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, color = Sc.Text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

/** Download state of a whole list, shown as one round button like Spotify's. */
enum class DlState { NONE, RUNNING, DONE }

@Composable
fun DownloadToggle(state: DlState, progress: Float, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val done = rememberCompletionRipple(null, state == DlState.RUNNING, state == DlState.DONE)
    // Rings on a wrapper so the button's round clip doesn't cut them off
    Box(modifier.waveSource(done), contentAlignment = Alignment.Center) {
        IconButton(onClick = onClick) {
            when (state) {
                DlState.NONE -> Icon(Icons.Outlined.ArrowCircleDown, "Download all", tint = Sc.TextDim, modifier = Modifier.size(30.dp))
                DlState.DONE -> Icon(Icons.Rounded.ArrowCircleDown, "Downloaded", tint = Sc.Accent, modifier = Modifier.size(30.dp))
                DlState.RUNNING -> Box(contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        progress = { progress.coerceIn(0.02f, 1f) },
                        color = Sc.Accent,
                        trackColor = Sc.SurfaceHighest,
                        strokeWidth = 2.5.dp,
                        modifier = Modifier.size(26.dp)
                    )
                    Box(Modifier.size(8.dp).background(Sc.Accent))
                }
            }
        }
    }
}

// =============================================================================================
// States
// =============================================================================================

@Composable
fun Loading(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        SirenLoader(size = 44.dp)
    }
}

@Composable
fun ErrorBox(message: String, onRetry: (() -> Unit)?, modifier: Modifier = Modifier) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.ErrorOutline, null, tint = Sc.TextDim, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(12.dp))
        Text(message, color = Sc.TextDim, textAlign = TextAlign.Center)
        if (onRetry != null) {
            Spacer(Modifier.height(16.dp))
            OutlineButton("Try again", onRetry, icon = Icons.Rounded.Refresh)
        }
    }
}

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    body: String,
    modifier: Modifier = Modifier,
    action: (@Composable () -> Unit)? = null
) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = Sc.TextDim, modifier = Modifier.size(44.dp))
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, color = Sc.Text, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(body, color = Sc.TextDim, textAlign = TextAlign.Center, fontSize = 14.sp)
        if (action != null) {
            Spacer(Modifier.height(22.dp))
            action()
        }
    }
}

/** Small gray tag next to a subtitle ("Hidden"). */
@Composable
fun Tag(text: String) {
    Text(
        text,
        color = Sc.Bg,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(Sc.TextDim)
            .padding(horizontal = 4.dp, vertical = 1.dp)
    )
}

/** The "E" next to explicit songs. */
@Composable
fun ExplicitBadge() {
    Box(
        Modifier
            .size(15.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(Sc.TextDim),
        contentAlignment = Alignment.Center
    ) {
        Text("E", color = Sc.Bg, fontSize = 10.sp, fontWeight = FontWeight.Black, lineHeight = 10.sp)
    }
}
