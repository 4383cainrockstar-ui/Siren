package app.siren.player

import app.siren.data.Explicit
import android.net.Uri
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.ResolvingDataSource
import app.siren.core.Music
import app.siren.data.Settings
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.AudioTrackType
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/**
 * The queue holds lightweight `siren://yt?v=<id>` URIs. Right before ExoPlayer opens one,
 * this turns it into a fresh googlevideo audio URL. That means a 500 song queue costs
 * nothing up front, and URLs never go stale while they wait in the queue.
 */
@UnstableApi
object StreamResolver : ResolvingDataSource.Resolver {
    const val SCHEME = "siren"

    private data class Resolved(val url: String, val key: String, val expiresAt: Long)

    private val resolved = ConcurrentHashMap<String, Resolved>()
    private val needsFresh: MutableSet<String> = ConcurrentHashMap.newKeySet()

    fun uriFor(videoId: String): Uri =
        Uri.Builder().scheme(SCHEME).authority("yt").appendQueryParameter("v", videoId).build()

    fun idOf(uri: Uri?): String? =
        if (uri?.scheme == SCHEME) uri.getQueryParameter("v") else null

    override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
        val id = idOf(dataSpec.uri) ?: return dataSpec
        val r = resolve(id)
        return dataSpec.buildUpon()
            .setUri(Uri.parse(r.url))
            .setKey(r.key)
            .build()
    }

    /** Throws away the cached URL for a song (after a 403, or when quality changes). */
    fun invalidate(videoId: String? = null) {
        if (videoId == null) {
            resolved.clear()
        } else {
            resolved.remove(videoId)
            needsFresh.add(videoId)
        }
    }

    private val locks = ConcurrentHashMap<String, Any>()
    private val inFlight: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val prefetchPool = java.util.concurrent.Executors.newFixedThreadPool(2) { r ->
        Thread(r, "siren-prefetch").apply { isDaemon = true }
    }

    /** Looks up stream links for songs coming up, so they start instantly when their turn comes. */
    fun prefetch(ids: List<String>) {
        for (id in ids) {
            val r = resolved[id]
            if (r != null && r.expiresAt - System.currentTimeMillis() > 10 * 60_000) continue
            if (!inFlight.add(id)) continue
            try {
                prefetchPool.execute {
                    try {
                        val r = resolve(id)
                        bufferAudio(id, r)
                    } catch (_: Throwable) {
                    } finally {
                        inFlight.remove(id)
                    }
                }
            } catch (_: Throwable) {
                inFlight.remove(id)
            }
        }
    }

    /** The player's audio cache. Set by PlayerController, so pre-buffered audio is what playback reads. */
    @Volatile var audioCache: androidx.media3.datasource.DataSource.Factory? = null

    private const val PREBUFFER_BYTES = 8L * 1024 * 1024
    private val buffered: MutableSet<String> = ConcurrentHashMap.newKeySet()

    /** Downloads the start of a coming song into the cache, so it plays the moment it's its turn. */
    private fun bufferAudio(id: String, r: Resolved) {
        val factory = audioCache ?: return
        if (!buffered.add(id)) return
        try {
            val spec = DataSpec.Builder()
                .setUri(Uri.parse(r.url))
                .setKey(r.key)
                .setPosition(0)
                .setLength(PREBUFFER_BYTES)
                .build()
            val src = factory.createDataSource()
            try {
                src.open(spec)
                val buf = ByteArray(64 * 1024)
                var total = 0L
                while (total < PREBUFFER_BYTES) {
                    val n = src.read(buf, 0, buf.size)
                    if (n == -1) break
                    total += n
                }
            } finally {
                src.close()
            }
        } catch (_: Throwable) {
            buffered.remove(id) // try again next time it comes up
        }
    }

    private fun resolve(id: String): Resolved {
        val now0 = System.currentTimeMillis()
        resolved[id]?.let { if (it.expiresAt - now0 > 60_000) return it }
        // One lookup per song at a time: if a prefetch is running, playback waits for it
        // instead of starting a second one
        synchronized(locks.getOrPut(id) { Any() }) {
            return resolveLocked(id)
        }
    }

    private fun resolveLocked(id: String): Resolved {
        val now = System.currentTimeMillis()
        resolved[id]?.let { if (it.expiresAt - now > 60_000) return it }
        val fresh = needsFresh.remove(id) || resolved.containsKey(id)
        // Clean version with an explicit twin? Play the explicit audio (same song, same queue entry)
        val target = Explicit.playableId(id)
        val info = try {
            Music.streamBlocking(target, fresh = fresh)
        } catch (e: Exception) {
            throw IOException(Music.friendlyError(e), e)
        }
        val audio = pickAudio(info, Settings.current.highQuality)
            ?: throw IOException("No playable audio for this song")
        val url = audio.content
        val expire = Uri.parse(url).getQueryParameter("expire")?.toLongOrNull()?.times(1000)
            ?: (now + 5 * 60 * 60 * 1000L)
        val r = Resolved(url, "$id-${audio.itag}", expire)
        resolved[id] = r
        return r
    }

    private fun usable(s: AudioStream): Boolean =
        s.isUrl && s.content.isNotBlank() && s.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP

    fun pickAudio(info: StreamInfo, high: Boolean): AudioStream? {
        val all = info.audioStreams.filter { usable(it) }
        if (all.isEmpty()) return null
        val original = all.filter { it.audioTrackType == null || it.audioTrackType == AudioTrackType.ORIGINAL }
        val pool = original.ifEmpty { all }
        return if (high) pool.maxByOrNull { it.averageBitrate }
        else pool.minByOrNull { if (it.averageBitrate > 0) it.averageBitrate else Int.MAX_VALUE }
    }

    /** Best AAC/M4A stream, which every phone and car stereo can play (used for downloads). */
    fun pickM4a(info: StreamInfo): AudioStream? {
        val all = info.audioStreams.filter { usable(it) && it.format == MediaFormat.M4A }
        val original = all.filter { it.audioTrackType == null || it.audioTrackType == AudioTrackType.ORIGINAL }
        return original.ifEmpty { all }.maxByOrNull { it.averageBitrate }
    }
}
