package app.siren.ui.components

import app.siren.data.LocalMusic
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.DownloadDone
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Radio
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.siren.core.Fmt
import app.siren.core.Track
import app.siren.data.DownloadRecord
import app.siren.data.Library
import app.siren.player.PlayerController
import app.siren.ui.LocalActions
import app.siren.ui.theme.Sc

@Composable
fun SheetRow(icon: ImageVector, text: String, tint: Color = Sc.Text, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (tint == Sc.Text) Sc.TextDim else tint, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(20.dp))
        Text(text, color = tint, fontSize = 16.sp)
    }
}

/** Long-press / ⋮ menu for any song. */
@Composable
fun TrackActionsSheet(
    track: Track,
    onDismiss: () -> Unit,
    // Overrides Play next; the queue moves its own copy instead of adding another
    onPlayNext: (() -> Unit)? = null,
    extra: @Composable (close: () -> Unit) -> Unit = {}
) {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    val liked = lib.liked.any { it.videoId == track.videoId }
    val download = lib.downloads.firstOrNull { it.track.videoId == track.videoId }
    var addTo by remember { mutableStateOf(false) }

    if (addTo) {
        AddToPlaylistDialog(listOf(track), onDone = { addTo = false; onDismiss() })
        return
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Sc.Sheet
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(bottom = 12.dp)
        ) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Artwork(track.thumbnail, Modifier.size(52.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(track.title, color = Sc.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(Fmt.subtitle(track), color = Sc.TextDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            HorizontalDivider(color = Sc.Outline, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
            SheetRow(Icons.Rounded.SkipNext, "Play next") {
                if (onPlayNext != null) onPlayNext() else PlayerController.playNext(listOf(track))
                onDismiss()
            }
            SheetRow(Icons.AutoMirrored.Rounded.QueueMusic, "Add to queue") { PlayerController.addToQueue(listOf(track)); onDismiss() }
            SheetRow(Icons.Rounded.Radio, "Start radio") { actions.radio(track); onDismiss() }
            SheetRow(
                if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                if (liked) "Remove from Liked songs" else "Add to Liked songs",
                tint = if (liked) Sc.Accent else Sc.Text
            ) {
                Library.toggleLike(track)
                onDismiss()
            }
            SheetRow(Icons.AutoMirrored.Rounded.PlaylistAdd, "Add to playlist") { addTo = true }
            SheetRow(Icons.Rounded.Share, "Share") { actions.share(track); onDismiss() }
            when {
                LocalMusic.isLocal(track) -> SheetRow(Icons.Rounded.DownloadDone, "On this device", tint = Sc.Accent) { onDismiss() }
                else -> when (download?.status) {
                DownloadRecord.STATUS_DONE -> SheetRow(Icons.Rounded.DownloadDone, "Downloaded", tint = Sc.Accent) { onDismiss() }
                DownloadRecord.STATUS_RUNNING, DownloadRecord.STATUS_QUEUED -> SheetRow(Icons.Rounded.Download, "Downloading…") { onDismiss() }
                else -> SheetRow(Icons.Rounded.Download, "Download") { actions.download(listOf(track)); onDismiss() }
                }
            }
            if (track.artistUrl.isNotBlank()) {
                SheetRow(Icons.Rounded.Person, "Go to artist") { onDismiss(); actions.artist(track.artistUrl) }
            }
            extra(onDismiss)
        }
    }
}

@Composable
fun RemoveFromHistoryRow(track: Track, close: () -> Unit) {
    SheetRow(Icons.Rounded.History, "Remove from history", tint = Sc.Error) {
        Library.removeFromHistory(track)
        close()
    }
}

@Composable
fun DeleteRow(text: String, close: () -> Unit, onClick: () -> Unit) {
    SheetRow(Icons.Rounded.Delete, text, tint = Sc.Error) {
        onClick()
        close()
    }
}

@Composable
fun AddToPlaylistDialog(tracks: List<Track>, onDone: () -> Unit) {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    var creating by remember { mutableStateOf(false) }

    if (creating) {
        NameDialog("New playlist", "", onDismiss = onDone) { name ->
            Library.createPlaylist(name, tracks)
            actions.message("Saved to $name")
            onDone()
        }
        return
    }

    AlertDialog(
        onDismissRequest = onDone,
        containerColor = Sc.Sheet,
        title = { Text("Add to playlist", color = Sc.Text, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                item {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { creating = true }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Add, null, tint = Sc.Text)
                        Spacer(Modifier.width(14.dp))
                        Text("New playlist", color = Sc.Text, fontWeight = FontWeight.Bold)
                    }
                }
                items(lib.playlists, key = { it.id }) { p ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                val n = Library.addToPlaylist(p.id, tracks)
                                actions.message(if (n == 0) "Already in ${p.name}" else "Added to ${p.name}")
                                onDone()
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Artwork(p.tracks.firstOrNull()?.thumbnail ?: "", Modifier.size(44.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(p.name, color = Sc.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(Fmt.songs(p.tracks.size), color = Sc.TextDim, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDone) { Text("Cancel", color = Sc.TextDim) } }
    )
}

@Composable
fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Sc.Sheet,
        title = { Text(title, color = Sc.Text, fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                placeholder = { Text("Name") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Sc.Text,
                    unfocusedBorderColor = Sc.Outline,
                    focusedTextColor = Sc.Text,
                    unfocusedTextColor = Sc.Text,
                    cursorColor = Sc.Accent
                ),
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onSave(text.trim()) }) { Text("Save", color = Sc.Accent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Sc.TextDim) } }
    )
}

@Composable
fun ConfirmDialog(title: String, body: String, confirm: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Sc.Sheet,
        title = { Text(title, color = Sc.Text, fontWeight = FontWeight.Bold) },
        text = { Text(body, color = Sc.TextDim) },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { Text(confirm, color = Sc.Accent, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Sc.TextDim) } }
    )
}
