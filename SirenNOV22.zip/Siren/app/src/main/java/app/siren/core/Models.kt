package app.siren.core

import kotlinx.serialization.Serializable
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.channel.ChannelInfoItem
import org.schabi.newpipe.extractor.playlist.PlaylistInfoItem
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

/** A playable song (any YouTube / YouTube Music video). */
@Serializable
data class Track(
    val url: String,
    val title: String,
    val artist: String = "",
    val artistUrl: String = "",
    val thumbnail: String = "",
    val duration: Long = -1,
    val album: String = ""
) {
    /**
     * The 11 character video id, used for caching, lyrics, SponsorBlock. Worked out once per
     * track (it's compared constantly: likes, downloads, queue), and not saved to disk.
     */
    val videoId: String by lazy(LazyThreadSafetyMode.PUBLICATION) { videoIdFromUrl(url) ?: url }
}

@Serializable
data class ArtistRef(
    val url: String,
    val name: String,
    val avatar: String = "",
    val subscribers: Long = -1
)

/** An album or a playlist on YouTube / YouTube Music. */
@Serializable
data class CollectionRef(
    val url: String,
    val name: String,
    val thumbnail: String = "",
    val author: String = "",
    val count: Long = -1,
    val isAlbum: Boolean = false,
    val authorUrl: String = ""
)

/** One row in a mixed list (search results, artist tabs). */
sealed interface Entry {
    val key: String

    data class Song(val track: Track) : Entry {
        override val key: String get() = "s:" + track.url
    }

    data class Artist(val artist: ArtistRef) : Entry {
        override val key: String get() = "a:" + artist.url
    }

    data class Collection(val collection: CollectionRef) : Entry {
        override val key: String get() = "c:" + collection.url
    }
}

// ---------------------------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------------------------

fun List<Image>?.bestUrl(maxHeight: Int = 720): String {
    if (this.isNullOrEmpty()) return ""
    val usable = this.filter { !it.url.isNullOrBlank() }
    if (usable.isEmpty()) return ""
    val known = usable.filter { it.height > 0 }
    if (known.isEmpty()) return if (maxHeight >= 480) usable.last().url else usable.first().url
    val fitting = known.filter { it.height <= maxHeight }.maxByOrNull { it.height }
    val chosen = fitting ?: known.minByOrNull { it.height }
    return chosen?.url ?: usable.last().url
}

// Compiled once: this runs for every song comparison
private val videoIdPatterns = listOf(
    Regex("[?&]v=([A-Za-z0-9_-]{11})"),
    Regex("youtu\\.be/([A-Za-z0-9_-]{11})"),
    Regex("/shorts/([A-Za-z0-9_-]{11})"),
    Regex("/embed/([A-Za-z0-9_-]{11})")
)

fun videoIdFromUrl(url: String): String? {
    for (p in videoIdPatterns) {
        val m = p.find(url)
        if (m != null) return m.groupValues[1]
    }
    return null
}

fun watchUrl(videoId: String) = "https://www.youtube.com/watch?v=$videoId"

/** Bigger artwork: Google image URLs carry their size in the URL, YouTube thumbs have fixed names. */
fun hiRes(url: String, size: Int = 544): String {
    if (url.isBlank()) return url
    if (url.contains("googleusercontent.com") || url.contains("ggpht.com")) {
        val r = Regex("=w\\d+-h\\d+[^&?/]*")
        if (r.containsMatchIn(url)) return url.replace(r, "=w$size-h$size-l90-rj")
        val s = Regex("=s\\d+[^&?/]*")
        if (s.containsMatchIn(url)) return url.replace(s, "=s$size")
        return url
    }
    if (url.contains("i.ytimg.com/vi/")) {
        return url.replace(Regex("/(default|mqdefault|sddefault|hq720|hqdefault)(_live)?\\.jpg.*$"), "/hqdefault.jpg")
    }
    return url
}

fun fallbackThumb(url: String): String =
    videoIdFromUrl(url)?.let { "https://i.ytimg.com/vi/$it/hqdefault.jpg" } ?: ""

/** "Daft Punk - Topic" / "DaftPunkVEVO" -> "Daft Punk" */
fun cleanArtist(name: String): String {
    var n = name.trim()
    n = n.removeSuffix(" - Topic").trim()
    if (n.endsWith("VEVO") && n.length > 4) {
        n = n.removeSuffix("VEVO").trim()
        // "DaftPunk" -> "Daft Punk"
        if (!n.contains(' ')) n = n.replace(Regex("(?<=[a-z])(?=[A-Z])"), " ")
    }
    if (n.endsWith(" Official", ignoreCase = true)) n = n.dropLast(9).trim()
    return n
}

private val noise = Regex(
    "\\s*[(\\[](official\\s*(music\\s*)?(video|audio|visuali[sz]er|lyric\\s*video|hd\\s*video)?|" +
        "lyrics?(\\s*video)?|audio|visuali[sz]er|hd|hq|4k|mv|m/v|video\\s*oficial|clip\\s*officiel)[)\\]]",
    RegexOption.IGNORE_CASE
)

fun cleanTitle(title: String): String = title.replace(noise, "").replace(Regex("\\s{2,}"), " ").trim()

/**
 * Builds a track from raw YouTube data, splitting "Artist - Song" titles that come from
 * music videos so lists and lyrics lookups show the real song name.
 */
fun makeTrack(url: String, rawTitle: String, rawArtist: String, artistUrl: String, thumb: String, duration: Long): Track {
    var title = cleanTitle(rawTitle)
    var artist = cleanArtist(rawArtist)
    val dash = title.indexOf(" - ")
    if (dash > 0) {
        val left = title.substring(0, dash).trim()
        val right = title.substring(dash + 3).trim()
        val sameArtist = artist.isBlank() ||
            left.contains(artist, ignoreCase = true) || artist.contains(left, ignoreCase = true) ||
            rawArtist.endsWith("VEVO")
        if (sameArtist && right.isNotBlank()) {
            if (artist.isBlank() || rawArtist.endsWith("VEVO")) artist = left
            title = right
        }
    }
    return Track(
        url = url,
        title = title.ifBlank { rawTitle },
        artist = artist,
        artistUrl = normalizeChannelUrl(artistUrl),
        thumbnail = thumb.ifBlank { fallbackThumb(url) },
        duration = duration
    )
}

fun normalizeChannelUrl(url: String): String =
    url.replace("://music.youtube.com/", "://www.youtube.com/")

fun StreamInfoItem.toTrack(): Track = makeTrack(
    url = url ?: "",
    rawTitle = name ?: "",
    rawArtist = uploaderName ?: "",
    artistUrl = uploaderUrl ?: "",
    thumb = thumbnails.bestUrl(),
    duration = duration
)

fun StreamInfo.toTrack(): Track = makeTrack(
    url = url ?: "",
    rawTitle = name ?: "",
    rawArtist = uploaderName ?: "",
    artistUrl = uploaderUrl ?: "",
    thumb = thumbnails.bestUrl(),
    duration = duration
)

fun ChannelInfoItem.toArtist(): ArtistRef = ArtistRef(
    url = normalizeChannelUrl(url ?: ""),
    name = cleanArtist(name ?: ""),
    avatar = thumbnails.bestUrl(240),
    subscribers = subscriberCount
)

fun PlaylistInfoItem.toCollection(forceAlbum: Boolean = false): CollectionRef {
    val u = url ?: ""
    return CollectionRef(
        url = u,
        name = name ?: "",
        thumbnail = thumbnails.bestUrl(),
        author = cleanArtist(uploaderName ?: ""),
        count = streamCount,
        isAlbum = forceAlbum || u.contains("list=OLAK5uy_"),
        authorUrl = normalizeChannelUrl(uploaderUrl ?: "")
    )
}

fun InfoItem.toEntry(albums: Boolean = false): Entry? {
    val item: InfoItem = this
    return when (item) {
        is StreamInfoItem -> Entry.Song(item.toTrack())
        is ChannelInfoItem -> Entry.Artist(item.toArtist())
        is PlaylistInfoItem -> Entry.Collection(item.toCollection(albums))
        else -> null
    }
}
