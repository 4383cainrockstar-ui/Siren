package app.siren.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.PlaylistPlay
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import app.siren.core.Track
import app.siren.data.Library
import app.siren.player.PlayerController
import app.siren.ui.LocalActions
import app.siren.ui.theme.Sc

/** Songs picked with long-press. Empty = not selecting. */
@Stable
class SongSelection {
    var ids by mutableStateOf<Set<String>>(emptySet())
        private set

    val active: Boolean get() = ids.isNotEmpty()
    val count: Int get() = ids.size

    fun isSelected(t: Track) = t.videoId in ids
    fun toggle(t: Track) {
        ids = if (t.videoId in ids) ids - t.videoId else ids + t.videoId
    }

    fun selectAll(tracks: List<Track>) {
        ids = tracks.map { it.videoId }.toSet()
    }

    fun clear() {
        ids = emptySet()
    }

    /** The picked songs, in list order. */
    fun picked(from: List<Track>): List<Track> = from.filter { it.videoId in ids }.distinctBy { it.videoId }
}

@Composable
fun rememberSongSelection(): SongSelection = remember { SongSelection() }

/**
 * Top bar ("3 selected · Select all") and bottom actions (play next, queue, like, playlist,
 * download) while songs are picked. [all] is what "Select all" picks and what the
 * selection is resolved against.
 */
@UnstableApi
@Composable
fun BoxScope.SelectionOverlay(sel: SongSelection, all: List<Track>) {
    val actions = LocalActions.current
    val lib by Library.data.collectAsState()
    var addTo by remember { mutableStateOf<List<Track>?>(null) }
    BackHandler(enabled = sel.active) { sel.clear() }

    AnimatedVisibility(
        visible = sel.active,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = Modifier.align(Alignment.TopCenter)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(Sc.SurfaceHigh)
                .statusBarsPadding()
                .height(56.dp)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { sel.clear() }) { Icon(Icons.Rounded.Close, "Done selecting", tint = Sc.Text) }
            Text(
                if (sel.count == 1) "1 song selected" else "${sel.count} songs selected",
                color = Sc.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            val everything = all.isNotEmpty() && all.all { sel.isSelected(it) }
            TextButton(onClick = { if (everything) sel.clear() else sel.selectAll(all) }) {
                Text(if (everything) "Clear" else "Select all", color = Sc.Accent, fontWeight = FontWeight.Bold)
            }
        }
    }

    AnimatedVisibility(
        visible = sel.active,
        enter = slideInVertically { it } + fadeIn(),
        exit = slideOutVertically { it } + fadeOut(),
        modifier = Modifier.align(Alignment.BottomCenter)
    ) {
        val picked = sel.picked(all)
        val likedIds = remember(lib.liked) { lib.liked.map { it.videoId }.toHashSet() }
        val allLiked = picked.isNotEmpty() && picked.all { it.videoId in likedIds }
        Row(
            Modifier
                .padding(horizontal = 8.dp, vertical = 8.dp)
                .fillMaxWidth()
                .shadow(12.dp, RoundedCornerShape(12.dp))
                .clip(RoundedCornerShape(12.dp))
                .background(Sc.SurfaceHighest)
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            SelAction(Icons.AutoMirrored.Rounded.PlaylistPlay, "Play next") {
                PlayerController.playNext(picked)
                sel.clear()
            }
            SelAction(Icons.AutoMirrored.Rounded.QueueMusic, "Add to queue") {
                PlayerController.addToQueue(picked)
                sel.clear()
            }
            SelAction(if (allLiked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, if (allLiked) "Unlike" else "Like") {
                if (allLiked) {
                    Library.unlikeAll(picked)
                    actions.message(if (picked.size == 1) "Removed from Liked songs" else "Removed ${picked.size} songs from Liked songs")
                } else {
                    val n = Library.likeAll(picked)
                    actions.message(if (n == 1) "Added to Liked songs" else "Added $n songs to Liked songs")
                }
                sel.clear()
            }
            SelAction(Icons.AutoMirrored.Rounded.PlaylistAdd, "Playlist") { addTo = picked }
            SelAction(Icons.Rounded.Download, "Download") {
                actions.download(picked)
                sel.clear()
            }
        }
    }

    addTo?.let { list ->
        AddToPlaylistDialog(list, onDone = {
            addTo = null
            sel.clear()
        })
    }
}

@Composable
private fun SelAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = Sc.Text, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(3.dp))
        Text(label, color = Sc.Text, fontSize = 11.sp, maxLines = 1)
    }
}
