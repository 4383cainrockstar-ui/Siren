package app.siren.data

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.media3.common.util.UnstableApi
import app.siren.MainActivity
import app.siren.R
import app.siren.SirenApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Runs playlist imports with a progress notification, so you can close Siren or lock the phone.
 * If Android kills it, the next start (or opening Siren) carries on from the last saved batch.
 */
@UnstableApi
class ImportService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var worker: Job? = null
    private val nm by lazy { NotificationManagerCompat.from(this) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Importer.stopAll()
            return START_NOT_STICKY
        }
        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, progress("Getting your import ready…", "", 0, 0),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
            )
        } catch (e: Exception) {
            // Android wouldn't let it start right now (app in the background): resumes on next open
            stopSelf()
            return START_NOT_STICKY
        }
        if (worker?.isActive != true) worker = scope.launch { work() }
        return START_STICKY
    }

    private suspend fun work() {
        while (true) {
            val job = Importer.nextRunning() ?: break
            showProgress(job, waiting = false)
            when (Importer.runBatch(job.id)) {
                Importer.Step.MORE -> {}
                Importer.Step.WAIT -> {
                    showProgress(job, waiting = true)
                    delay(15_000)
                }
                Importer.Step.FINISHED -> Importer.job(job.id)?.let { done(it) }
            }
        }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun showProgress(job: ImportJob, waiting: Boolean) {
        val others = Importer.runningCount() - 1
        val title = "Importing ${job.name}" + if (others > 0) " (+$others more)" else ""
        val text = if (waiting) "Waiting for a connection… ${job.next} / ${job.total}" else "${job.next} / ${job.total} songs"
        nm.notifySafe(NOTIF_ID, progress(title, text, job.next, job.total))
    }

    private fun done(job: ImportJob) {
        if (job.status == ImportJob.STOPPED) return
        val text = buildString {
            append("${job.matched} of ${job.total} songs added")
            if (job.needsLook > 0) append(". ${job.needsLook} need a look")
        }
        val n = NotificationCompat.Builder(this, SirenApp.CHANNEL_IMPORTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("${job.name} imported")
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openPlaylist(job.playlistId))
            .build()
        nm.notifySafe(NOTIF_DONE_BASE + (job.id.hashCode() and 0xFFF), n)
    }

    private fun openPlaylist(playlistId: String): PendingIntent {
        val i = Intent(this, MainActivity::class.java)
            .setAction(MainActivity.ACTION_OPEN_PLAYLIST)
            .putExtra(MainActivity.EXTRA_PLAYLIST, playlistId)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(this, playlistId.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun progress(title: String, text: String, done: Int, total: Int): Notification {
        val stop = PendingIntent.getService(
            this, 7, Intent(this, ImportService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(this, SirenApp.CHANNEL_IMPORTS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setProgress(total.coerceAtLeast(0), done.coerceAtLeast(0), total <= 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Stop", stop)
        Importer.nextRunning()?.let { b.setContentIntent(openPlaylist(it.playlistId)) }
        return b.build()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "app.siren.IMPORT_STOP"
        private const val NOTIF_ID = 6250
        private const val NOTIF_DONE_BASE = 7000
    }
}

@SuppressLint("MissingPermission")
private fun NotificationManagerCompat.notifySafe(id: Int, n: Notification) {
    try {
        if (areNotificationsEnabled()) notify(id, n)
    } catch (_: SecurityException) {
    }
}
