# Siren

An ad-free music player for Android, powered by YouTube Music. No account, no ads, no tracking. Everything lives on your phone.

Built with Kotlin, Jetpack Compose and Media3, on the same extraction engine as NewPipe. Siren is the new name for Pulse: it installs right over Pulse and keeps your library.

## Features

**Listening**
- The whole YouTube Music catalog: songs, music videos, albums, artists, playlists
- Background playback with notification, lockscreen, headphone and Bluetooth controls, plus a Like button next to the controls
- Autoplay: play any song and Siren queues similar tracks (YouTube Music's own radio). Skipping past the last song keeps going instead of stopping
- Shuffle, repeat all / one, swipe the cover (or the mini player) to skip, playback speed, sleep timer
- Smart shuffle: tap shuffle twice and a song picked for your taste slips in every few songs (every 2nd to 5th, your call). It follows your recent listening, skips artists you just heard, branches out through similar artists, and has a Familiar ↔ Adventurous slider. Picks show "Because you played …" and can be removed with one tap
- Home screen widgets: a 4x1 mini player and a 4x2 player with big cover art and a like button, tinted to the cover
- Synced lyrics that follow the song (tap a line to jump to it), from LRCLIB
- Skips the talking intros and outros in music videos (SponsorBlock "non-music" segments)
- Song cache, so replays don't hit the network
- Picks up where you left off: the queue and position come back when you open the app
- Built-in equalizer (Settings → Equalizer): drag the curve, pick a preset (Bass boost, Vocal, Rock, Late night…), bass boost. Your phone's own equalizer and EQ apps like Wavelet still work too
- Long-press any song to pick several (or Select all), then Play next, Add to queue, Like, add to a playlist or download them in one go
- Drag the handles in the queue to put songs in any order (works with shuffle on too)
- Crossfade (Settings → Playback): songs fade out and the next fades in, 1 to 12 seconds. Off by default
- Normalize volume (Settings → Playback, Android 9+): evens out loud and quiet songs. Gentle, Balanced or Strong
- Save the queue as a playlist from the queue sheet
- Share any song, album, artist or playlist from its menu

**Android Auto**
- Proper skip buttons in the car (no more "10 seconds back / forward")
- Song title and artist on the car's now playing screen
- Home in the car: Today's vibe, Tracks we think you'd like, Daily Mixes (play as stations), Genres & moods, Recently played
- Long lists (Liked, Downloads, playlists) open short: Shuffle all, By artist, the newest 25, then pages of 25
- Voice: "play ___", "play ___ radio", "play hip hop", "play my liked songs" or a playlist name, on Siren
- Settings → Android Auto: list or big-cover grid for each tab, an "Art-first" preset, and which buttons sit next to skip (like, shuffle / smart shuffle, repeat)
- Siren's own tile with Home (your mixes + recently played), Liked, Playlists and Downloads
- Search in the car and "Hey Google, play … on Siren"
- Resumes your last queue when the car connects

**Home**
- Shortcut grid: Liked songs, Downloads, your latest playlists, albums and mixes
- Jump back in, Your mixes (a radio per favorite artist), Quick picks, New releases from artists you follow, Trending

**2.8: new look**
- New logo (the drop): app icon on black, themed icon, notification, widgets, and the launch screen animates the drop in
- Every loading spinner is now the drop (the dot falls, the rings spread), including pull-to-refresh on Home; pages show gray placeholders while they load
- Pages slide in, lists animate when songs move or disappear, covers and tiles shrink a touch when pressed, liking pops, and playlist covers shrink and fade as you scroll

**Explicit by default**
- When a song has an explicit and a clean version, the explicit one plays (and downloads). Clean only when there's no explicit version. Search hides the clean duplicate, and explicit songs show an E. Switch: Settings → Playback → Explicit versions

**Local files**
- Settings → Local files (or + in Your Library): pick folders on your phone and their songs show up as "On this device", with covers and tags. They play offline, work in playlists, the queue, shuffle and Android Auto

**More**
- Lyric cards: in the lyrics, long-press a line, pick up to 4, then Share
- Shuffle is a real shuffle everywhere (Android Auto and voice too), reshuffles after a break, plays songs you haven't heard lately first, and spreads artists out
- Android Auto: covers Siren draws (Today's vibe, weekly mix, Daily Mixes, genres, Shuffle all), sections on Home, tab icons, download and E badges
- Shared links open YouTube Music; the keyboard no longer covers search results; "Rebuild weekly mix" says when it's done; hidden artists are tagged in Search

**Car mode**
- Big-button screen for driving: huge play/pause, skip, like and Hide artist, a mic to say what to play, screen stays on, works sideways too
- Opens by itself when your car's Bluetooth connects (Settings → Car mode → add your car)

**Hide artists**
- Hold Next for 3 seconds (a ring fills, the phone buzzes): the song skips and that artist stays out of radio, autoplay, smart shuffle, mixes and suggestions. Undo right there
- Also "Hide this artist" in the player's ⋮ menu, and Settings → Made for you → Hidden artists to unhide

**Sharing**
- Spotify-style share screen: a card made from the cover (swipe for Color, Gradient, Blur or Dark), then Copy link, WhatsApp, Messages, Instagram, Discord and more (only apps you have)

**Settings**
- Grouped into pages (Playback, Sound, Track Streaming, Made for you, Car mode, Appearance, Downloads & storage, Android Auto, Privacy & backup) with a search box
- Keep playing during calls now also tries to get past phones that mute music during calls (Discord, WhatsApp, phone)

**Made for you**
- Your weekly mix: one playlist, about 70% songs you haven't heard and 30% you know. It replaces itself every Monday, so you never pile up old ones. Turn it off in Settings → Made for you (the current one stays)
- Artist pages split Albums and Singles & EPs, with a Fans also like shelf
- Playlist folders, a collage cover, and "Remove duplicate songs"
- Pure OLED (Settings → Appearance): true black everywhere

**Search**
- Top result, then Songs / Videos / Albums / Artists / Playlists tabs, live suggestions
- Recent searches only keep what you actually opened (songs, artists, albums, playlists, with their art), never what you typed. Search starts fresh whenever you switch tabs
- Browse all: moods and genres
- Paste any YouTube or YouTube Music link (or share one to Siren) and it opens

**Your Library**
- Filters (Playlists, Albums, Artists, Downloaded), Recents / Alphabetical, list or grid, search
- Liked songs, your own playlists (reorder, rename, export to CSV), saved albums and playlists, followed artists, listening history
- Find in playlist and Sort on every song list
- Download all on every playlist, album and Liked songs (tap again to remove the downloads). Big lists queue instantly
- Downloads are M4A (AAC) files in `Music/Siren`: they play offline in Siren and in any other player
- Download on Wi-Fi only, and automatically download songs you like
- Home made for you: Today's vibe (your songs for this time of day mixed with new ones), Tracks we think you'd like (unheard songs from artists related to yours), Daily Mixes, "Because you like …" and Artists you might like
- Radio that actually branches out: stations are built from related artists (Deezer's public similar-artists data), with the artist you started from only every 5th to 15th song and nobody twice within 6 songs. Works for artists ("Soulja Boy Radio"), genres / moods and songs. The radio card pops up as you type "___ radio", and thumbs up / down steer it
- Song menus (⋮) everywhere have Play next and Add to queue; the queue has its own ⋮ per song (Play next moves it up, Remove)
- Loads the next few songs early so new songs start fast (Settings → Playback)
- Draggable scroll bar on long lists
- Distortion wave (Android 13+): when you add a song to Liked, follow an artist, skip, play or pause, add to the queue, finish a download or let go of the seek bar, a shockwave bends the whole screen outward from that button, with a slight color split on the crest. Skipping also nudges the cover. Turn it off in Settings → Appearance
- Downloads: "Cancel all" on the Downloads screen, or Stop on the download notification. Saved songs stay.
- The next song is pre-buffered in the audio cache (up to 8 MB), so it starts right away when its turn comes
- "Hey Google, play ___ on Siren" (and "play ___ radio on Siren"), on the phone and in Android Auto
- Keep playing during calls (Settings → Playback): music keeps going, turned down, through phone and app calls
- Import playlists in the background (with buttons that open Exportify and Google Takeout for you), any size, with a progress notification: Google Takeout (YouTube Music) zip or CSV with exact matches, Exportify (Spotify) CSV or Export All zip with strict matching, any YouTube Music playlist link, or a text list. Unsure matches and songs it couldn't find are listed so you can fix them. Picks up where it stopped if the app is closed
- Full backup and restore (Pulse backups restore too)

## Build it on GitHub (no PC needed)

1. Upload `Siren.zip` to your repo as-is. Don't extract it. (Your Pulse repo works: the newest zip wins.)
2. Put the contents of `build.yml` in `.github/workflows/build.yml` (replace the old one).
3. Commit. The **Actions** tab starts the build. It takes about 6 to 10 minutes.
4. When the build is green, open **Releases → Siren - latest build** and download `Siren.apk`.
   It's also attached to the workflow run as the `Siren-apk` artifact.

Every build is signed with the same key Pulse used (`app/siren-release.jks`), so Siren installs over Pulse and keeps your likes, playlists and downloads.

## Android Auto setup

Android Auto hides apps that weren't installed from the Play Store until you allow them once:
1. Phone Settings → Connected devices → Android Auto.
2. Scroll down and tap **Version** about 10 times to turn on developer mode.
3. ⋮ menu → **Developer settings** → turn on **Unknown sources**.
4. Back in Android Auto settings → **Customize launcher**, make sure Siren is ticked.

## Notes

- Siren plays YouTube's public streams the same way NewPipe does. It isn't affiliated with YouTube or Spotify, and it's meant for sideloading. It won't be accepted on the Play Store.
- If YouTube changes something and playback breaks, update the NewPipe Extractor commit in `app/build.gradle.kts` and in the workflow's warm-up step to the commit the latest NewPipe release uses.
